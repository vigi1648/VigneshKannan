package com.zsl.patientscron.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.zsl.patientscron.util.BouncyCastleEngine;
import com.zsl.patientscron.util.CommonUtil;

@DynamoDBTable(tableName="PATIENTS_INFO")
public class Data
{
    private String medicalRecordNumber;

    private String unitDesc;

    private String lastName;

    private String languageDesc;

    private String floorDesc;

    private String bedId;

    private String facId;

    private String patientExternalId;

    private String patientStatus;

    private String ethnicityDesc;

    private String orgId;

    private String waitingList;

    private String patientId;

    private String roomDesc;

    private String languageCode;

    private String hasPhoto;

    private String gender;

    private String bedDesc;

    private String firstName;
    
    private String admissionDate;
    
    private String dischargeDate;
    
    private String birthDate;
    
    private String floorId;
    
    private String outpatient; 
    
    @DynamoDBAttribute(attributeName="SENDINGFACILITY")
	private String sendingFacility;
	@DynamoDBAttribute(attributeName="RECEIVINGFACILITY")
	private String receivingFacility;
	@DynamoDBAttribute(attributeName="SENDINGAPPLICATION")
	private String sendingApplication;
	@DynamoDBAttribute(attributeName="RECEIVINGAPPLICATION")
	private String receivingApplication;

    public String getMedicalRecordNumber ()
    {
        return medicalRecordNumber;
    }

    public void setMedicalRecordNumber (String medicalRecordNumber)
    {
        this.medicalRecordNumber = medicalRecordNumber;
    }

    public String getUnitDesc ()
    {
        return unitDesc;
    }

    public void setUnitDesc (String unitDesc)
    {
        this.unitDesc = unitDesc;
    }

    public String getLastName ()
    {
        return lastName;
    }

    public void setLastName (String lastName)
    {
        this.lastName = lastName;
//        String dataKey = null;
//		String decodedValue = null;
//		try {
//			dataKey = CommonUtil.getInstance().getDataKey();
//			
//			this.lastName = BouncyCastleEngine.AESEncryption(lastName, dataKey);
//		} catch(Exception e){
//			throw new RuntimeException(e.getMessage(), e);
//		}
//		finally {
//			decodedValue = null;
//			dataKey = null;
//		}
    }

    public String getLanguageDesc ()
    {
        return languageDesc;
    }

    public void setLanguageDesc (String languageDesc)
    {
        this.languageDesc = languageDesc;
    }

    public String getFloorDesc ()
    {
        return floorDesc;
    }

    public void setFloorDesc (String floorDesc)
    {
        this.floorDesc = floorDesc;
    }

    public String getBedId ()
    {
        return bedId;
    }

    public void setBedId (String bedId)
    {
        this.bedId = bedId;
    }

    public String getFacId ()
    {
        return facId;
    }

    public void setFacId (String facId)
    {
        this.facId = facId;
    }

    public String getPatientExternalId ()
    {
        return patientExternalId;
    }

    public void setPatientExternalId (String patientExternalId)
    {
        this.patientExternalId = patientExternalId;
    }

    public String getPatientStatus ()
    {
        return patientStatus;
    }

    public void setPatientStatus (String patientStatus)
    {
        this.patientStatus = patientStatus;
    }

    public String getEthnicityDesc ()
    {
        return ethnicityDesc;
    }

    public void setEthnicityDesc (String ethnicityDesc)
    {
        this.ethnicityDesc = ethnicityDesc;
    }

    public String getOrgId ()
    {
        return orgId;
    }

    public void setOrgId (String orgId)
    {
        this.orgId = orgId;
    }

    public String getWaitingList ()
    {
        return waitingList;
    }

    public void setWaitingList (String waitingList)
    {
        this.waitingList = waitingList;
    }

    public String getPatientId ()
    {
        return patientId;
    }

    public void setPatientId (String patientId)
    {
        this.patientId = patientId;
//        String dataKey = null;
//		String decodedValue = null;
//		try {
//			dataKey = CommonUtil.getInstance().getDataKey();
//			
//			this.patientId = BouncyCastleEngine.AESEncryption(patientId, dataKey);
//		} catch(Exception e){
//			throw new RuntimeException(e.getMessage(), e);
//		}
//		finally {
//			decodedValue = null;
//			dataKey = null;
//		}
    }

    public String getRoomDesc ()
    {
        return roomDesc;
    }

    public void setRoomDesc (String roomDesc)
    {
        this.roomDesc = roomDesc;
    }

    public String getLanguageCode ()
    {
        return languageCode;
    }

    public void setLanguageCode (String languageCode)
    {
        this.languageCode = languageCode;
    }

    public String getHasPhoto ()
    {
        return hasPhoto;
    }

    public void setHasPhoto (String hasPhoto)
    {
        this.hasPhoto = hasPhoto;
    }

    public String getGender ()
    {
        return gender;
    }

    public void setGender (String gender)
    {
        this.gender = gender;
    }

    public String getBedDesc ()
    {
        return bedDesc;
    }

    public void setBedDesc (String bedDesc)
    {
        this.bedDesc = bedDesc;
    }

    public String getFirstName ()
    {
        return firstName;
        
    }

    public void setFirstName (String firstName)
    {
        this.firstName = firstName;
//    	String dataKey = null;
//		String decodedValue = null;
//		try {
//			dataKey = CommonUtil.getInstance().getDataKey();
//			
//			this.firstName = BouncyCastleEngine.AESEncryption(firstName, dataKey);
//		} catch(Exception e){
//			throw new RuntimeException(e.getMessage(), e);
//		}
//		finally {
//			decodedValue = null;
//			dataKey = null;
//		}
    }

	public String getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floorId) {
		this.floorId = floorId;
	}

	public String getOutpatient() {
		return outpatient;
	}

	public void setOutpatient(String outpatient) {
		this.outpatient = outpatient;
	}

	public String getSendingFacility() {
		return sendingFacility;
	}

	public void setSendingFacility(String sendingFacility) {
		this.sendingFacility = sendingFacility;
	}

	public String getReceivingFacility() {
		return receivingFacility;
	}

	public void setReceivingFacility(String receivingFacility) {
		this.receivingFacility = receivingFacility;
	}

	public String getSendingApplication() {
		return sendingApplication;
	}

	public void setSendingApplication(String sendingApplication) {
		this.sendingApplication = sendingApplication;
	}

	public String getReceivingApplication() {
		return receivingApplication;
	}

	public void setReceivingApplication(String receivingApplication) {
		this.receivingApplication = receivingApplication;
	}
	
	
	

//    @Override
//    public String toString()
//    {
//        return "ClassPojo [medicalRecordNumber = "+medicalRecordNumber+", unitDesc = "+unitDesc+", lastName = "+lastName+", languageDesc = "+languageDesc+", floorDesc = "+floorDesc+", bedId = "+bedId+", facId = "+facId+", patientExternalId = "+patientExternalId+", patientStatus = "+patientStatus+", ethnicityDesc = "+ethnicityDesc+", orgId = "+orgId+", waitingList = "+waitingList+", patientId = "+patientId+", roomDesc = "+roomDesc+", languageCode = "+languageCode+", hasPhoto = "+hasPhoto+", gender = "+gender+", bedDesc = "+bedDesc+", firstName = "+firstName+"]";
//    }
}