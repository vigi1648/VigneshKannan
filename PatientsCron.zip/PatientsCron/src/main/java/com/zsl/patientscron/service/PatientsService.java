package com.zsl.patientscron.service;

import java.io.IOException;
import java.util.Map;

public interface PatientsService {

	public Object getPatients(Map<String, String> userInfo) throws IOException,InterruptedException;
	
}
