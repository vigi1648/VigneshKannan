package com.zsl.patientscron.dao;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.zsl.patientscron.dto.EMROperatorInfo;
import com.zsl.patientscron.dto.PatientDetails;
import com.zsl.patientscron.dto.Patients;

public interface PatientsDAO {

	public List<FailedBatch> patientDetails(List<PatientDetails> patientDetailsList);
	
	public List<PatientDetails> getPatient(String sendingFacility, String sendingApplication);
	
	public List<EMROperatorInfo> getfacility(String emrOperator);
	
	public String updateEmrInfo(EMROperatorInfo emrIn);
		
	public EMROperatorInfo getEMRInfo(String facility1,String emroperator1);
	
	public void saveupdatedfacility(EMROperatorInfo emrList);
	
	 public void deletePatients(List<PatientDetails> patientlist);
}
