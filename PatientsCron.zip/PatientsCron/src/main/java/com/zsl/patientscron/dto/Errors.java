package com.zsl.patientscron.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.zsl.patientscron.util.BouncyCastleEngine;
import com.zsl.patientscron.util.CommonUtil;

@DynamoDBTable(tableName="PCCDEVELOPER")
public class Errors
{
    private String status;

    private String title;

    private String detail;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

    
    
    //    @Override
//    public String toString()
//    {
//        return "ClassPojo [medicalRecordNumber = "+medicalRecordNumber+", unitDesc = "+unitDesc+", lastName = "+lastName+", languageDesc = "+languageDesc+", floorDesc = "+floorDesc+", bedId = "+bedId+", facId = "+facId+", patientExternalId = "+patientExternalId+", patientStatus = "+patientStatus+", ethnicityDesc = "+ethnicityDesc+", orgId = "+orgId+", waitingList = "+waitingList+", patientId = "+patientId+", roomDesc = "+roomDesc+", languageCode = "+languageCode+", hasPhoto = "+hasPhoto+", gender = "+gender+", bedDesc = "+bedDesc+", firstName = "+firstName+"]";
//    }
}