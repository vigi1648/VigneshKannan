package com.zsl.patientscron.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.zsl.patientscron.dao.PatientsDAO;
import com.zsl.patientscron.dao.PatientsDAOImpl;
import com.zsl.patientscron.dto.Data;
import com.zsl.patientscron.dto.DateModel;
import com.zsl.patientscron.dto.EMROperatorInfo;
import com.zsl.patientscron.dto.Errors;
import com.zsl.patientscron.dto.Paging;
import com.zsl.patientscron.dto.PatientDetails;
import com.zsl.patientscron.dto.Patients;
import com.zsl.patientscron.dto.PatientsError;
import com.zsl.patientscron.dto.RefereshToken;
import com.zsl.patientscron.util.BouncyCastleEngine;
import com.zsl.patientscron.util.CommonUtil;

public class PatientsServiceImpl implements PatientsService {
	
	static final Logger logger = LogManager.getLogger(PatientsServiceImpl.class);
	
	private String dataKey;
	

//	@SuppressWarnings("unchecked")
	@Override
	
	
public Object getPatients(Map<String, String> userInfo) throws IOException, InterruptedException {
		
		logger.info("Entered into getPatient service");
		
		PatientsDAO patientsDAO = new PatientsDAOImpl();
		Data data = new Data();
		
		Patients patients = new Patients(); 
		
		EMROperatorInfo emrinfo = null;
		StringBuilder response = null;
		/*List<PatientDetails> patientDetailsList = null;*/
		List<PatientDetails> patientDetailsList1 = null;
		List<PatientDetails> patientDetailsList2 = null;
		List<PatientDetails> patientlist = null;
		Map<String, PatientDetails> patientInfo = null;
		Map<String, PatientDetails> pccpatientInfo = null;
		PatientDetails updatePatient = null;
		PatientDetails updatedPatient = null;
		PatientDetails createPatients = null;
		PatientDetails updatePatients = null;
		PatientDetails patientsInactive = null;
		List<PatientDetails> patientDetailsList = null;
        patientDetailsList = new ArrayList<PatientDetails>();

	DateModel dateObject= new DateModel();
		boolean isupdated= false;
		/*patientDetailsList = new ArrayList<PatientDetails>();*/
		patientInfo = new HashMap<String, PatientDetails>();
		pccpatientInfo = new HashMap<String, PatientDetails>();
		PatientsError patientsResponseError = null;
//		PatientsDAO patientsDAO = new PatientsDAOImpl();
//		LoginInfo loginInfo = patientsDAO.getLoginInfo();
		
		String emrOperator = userInfo.get("emrOperator");
		
		List<EMROperatorInfo> emrOperatorList = patientsDAO.getfacility(emrOperator);
		
		for(EMROperatorInfo facilityList : emrOperatorList){
			String[] facilityArray = facilityList.getFacility().split("\\.");
			String nrfacility = facilityList.getFacility();
//          String facility = facilityList.getFacility();
			String facility = facilityArray[0];
            String sendingApplication = facilityList.getEmrOperator();
            String orgId = facilityList.getOrigin();
            String accessToken = facilityList.getAccessToken();
            String accessTokenExpiresIn = facilityList.getAccexpiresIn().replace(".", "");
            long accessTokenExpiresL = Long.parseLong(accessTokenExpiresIn);
            String refereshToken = facilityList.getRefreshToken();
            String refereshTokenExpiresIn = facilityList.getRefexpiresIn().replace(".", "");
            long refereshTokenExpiresL = Long.parseLong(refereshTokenExpiresIn);
            logger.info("Entered into EMROperatorInfo Iterator" + facility);
            
	/*            DateFormat converter = null;
            converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
            converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
            String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
            long currenttime = Long.parseLong(formatedDate);*/
            
            long currenttime=dateObject.getCurrenttime();
            String has = null;
            int page = 0;
           
            
      
       
        if(accessTokenExpiresL >= currenttime)
        {
//long presenttime= dateObject.getCurrenttime();
        	long presenttime;
			        	try
        	{
        	
			do
        	{

        int i = 1 + page;
		HttpURLConnection connection = null;
		System.out.println("Before Calling time of getPatient API:" + dateObject.getCurrenttime());
//    	final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+userInfo.get("orgId")+"/patients?facId="+userInfo.get("facilityId")+"";
		final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients?facId="+facility+"&patientStatus=Current&pageSize=200&page="+i+"";
		System.out.println("PCC getPatient API Call URL" + urlString);
		//presenttime= dateObject.getCurrenttime();
		System.out.println("After Calling time of getPatient API:" + dateObject.getCurrenttime());
		//Thread.sleep(20);
		logger.info("URL String of GetPatient" + urlString);
    	String authorization = "Bearer "+accessToken;
    	try{
    	final URL url = new URL(urlString);
    	connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(HttpMethod.GET);
		connection.setDoOutput(true);
		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
		connection.setRequestProperty("Authorization", authorization);
		
		if (connection.getInputStream() != null) {
			logger.info("Comes to InputStream");
            final InputStream inputStream = connection.getInputStream();
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            try {
                response = new StringBuilder();

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }
                JsonParser jsonParser = new JsonParser();
                String jsonObject = jsonParser.parse(response.toString()).toString();
                Gson gson = new Gson();
                patients = gson.fromJson(jsonObject, Patients.class);
                
                
                patientDetailsList1 = new ArrayList<PatientDetails>();
                
              
                for(Data data1 : patients.getData()){
                	
                	patientDetailsList1.add(addPatientDetails(data1));
                	                     	
                }
                
                
                //patientsDAO.deletePatients(patientlist);
                patientlist = patientsDAO.getPatient(nrfacility,sendingApplication);
                
			    for(PatientDetails patient : patientDetailsList1) {     			    
                    pccpatientInfo.put(patient.getPatientId(), patient);
                    
                    }
			   
			    
			    
			   
			    for(PatientDetails dbPatient : patientlist) {
                    updatedPatient = pccpatientInfo.get(dbPatient.getPatientId());
                    if(updatedPatient == null){
                           patientsInactive = updateInactivePatient(dbPatient);
                           patientDetailsList.add(patientsInactive);
                    }      
                    }
			    
			    for(PatientDetails patient : patientlist) {
					patientInfo.put(patient.getPatientId(), patient);
			    }

                
                for(PatientDetails pccpatientdetails : patientDetailsList1){
    				
                	updatePatient = patientInfo.get(pccpatientdetails.getPatientId());
               	 
    				if(updatePatient != null){
						updatePatients = updatePatientDetails(updatePatient,pccpatientdetails);
						patientDetailsList.add(updatePatients);
					}else {
						createPatients = createPatientDetails(pccpatientdetails);
						patientDetailsList.add(createPatients);
					}
                }
    			
                logger.info("End of GetPatient method");
		
             patientsDAO.patientDetails(patientDetailsList);
                int count=patientDetailsList.size();
                System.out.println(count +"patients updated successfully");
/*                if(!(failedBatchList.size() > 0)) {
                int count=patientDetailsList.size();
    			EMROperatorInfo emrList = updateFacility(facilityList);
				patientsDAO.saveupdatedfacility(emrList);
                
                System.out.println(count +"patients updated successfully");
                }
                else {
					throw new RuntimeException("ERROR OCCURED IN USERS CREATION");
				}*/
                
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
        }

         	

        	}catch (Exception e) {
    	InputStream errorstream = connection.getErrorStream();
    	if(errorstream != null)
    	{
    	BufferedReader br = null;
    	System.out.println("Comes to errorstream while try to get token");
        br = new BufferedReader(new InputStreamReader(errorstream));
        String response1 = "";
        String nachricht;
        while ((nachricht = br.readLine()) != null){
            response1 += nachricht;
        }
        JsonParser jsonParserError = new JsonParser();
        String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
        Gson gsonError = new Gson();
        patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
        String errDetail = null;
        for(Errors errors : patientsResponseError.getErrors()){
        	System.out.println("response1" + errors.getTitle());
        	System.out.println("response2" + errors.getDetail());
        	logger.error(errors.getDetail());
        	errDetail = errors.getDetail();
         	/*if (errDetail!=null)
     		{
     		System.out.println(errDetail);
     		break;
     		}*/
     
        	
        }
    	}
        
        e.printStackTrace();
        connection.disconnect();
    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    
    }
    	Paging paging = patients.getPaging();
    	page = paging.getPage();
         has = paging.getHasMore();
        System.out.println("hasmore flag" + has);
        logger.info("hasmore flag" + has);
/*        DateFormat converter1 = null;
        converter1 = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
        converter1.setTimeZone(TimeZone.getTimeZone("America/New_York"));
        Calendar calendar1 = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        String formatedDate1 = converter.format(calendar1.getTime()).toString().replace(".", "");
         presenttime = Long.parseLong(formatedDate1);*/
         
         presenttime=dateObject.getCurrenttime();
         System.out.println("Current Time" + presenttime);
        } 
        	while (has.equals("true") && accessTokenExpiresL >= presenttime);//&& accessTokenExpiresL >= presenttime
        	}catch (Exception e)
        	{
        		e.printStackTrace();
        	}
        	 logger.info("End of do while");
		}
        else if(refereshTokenExpiresL >= currenttime){
        	 emrinfo = AccessToken(refereshToken,refereshTokenExpiresIn);
             String newaccessToken = emrinfo.getAccess_token();
             String newaccessTokenExpiresIn = emrinfo.getExpires_in().replace(".","");
             long newaccessTokenExpiresL = Long.parseLong(newaccessTokenExpiresIn);
             String newrefereshTokenExpiresIn = emrinfo.getRefresh_expires_in().replace(".", "");
             long newrefereshTokenExpiresL = Long.parseLong(newrefereshTokenExpiresIn);
             
             PatientsDAO patientDAO = new PatientsDAOImpl();
             EMROperatorInfo emrIn = updateemrInfo(emrinfo,facilityList);
           //String updatemmsg=patientDAO.updateEmrInfo(emrIn);
      
             if(newaccessTokenExpiresL >= currenttime){
            	 long presenttime;
            	 try
            	 {
            	 do
             	{
           		 
             int i = 1 + page;
     		HttpURLConnection connection = null;
     		System.out.println("Before Calling time of getPatient API:" + dateObject.getCurrenttime());
//         	final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+userInfo.get("orgId")+"/patients?facId="+userInfo.get("facilityId")+"";
     		final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients?facId="+facility+"&patientStatus=Current&pageSize=200&page="+i+"";
     		System.out.println("PCC getPatient API Call URL" + urlString);
    		System.out.println("After Calling time of API:" + dateObject.getCurrenttime());
    		//Thread.sleep(20);
     		logger.info("URL String of GetPatient" + urlString);
         	String authorization = "Bearer "+newaccessToken;
         	try{
         	final URL url = new URL(urlString);
         	connection = (HttpURLConnection) url.openConnection();
     		connection.setRequestMethod(HttpMethod.GET);
     		connection.setDoOutput(true);
     		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
     		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
     		connection.setRequestProperty("Authorization", authorization);
     		
     		if (connection.getInputStream() != null) {
     			logger.info("Comes to InputStream");
                 final InputStream inputStream = connection.getInputStream();
                 final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                 try {
                     response = new StringBuilder();

                     String line;
                     while ((line = bufferedReader.readLine()) != null) {
                         response.append(line);
                     }
                     JsonParser jsonParser = new JsonParser();
                     String jsonObject = jsonParser.parse(response.toString()).toString();
                     Gson gson = new Gson();
                     patients = gson.fromJson(jsonObject, Patients.class);
                     
                     patientDetailsList1 = new ArrayList<PatientDetails>();
                     
                   
                     for(Data data1 : patients.getData()){
                     	
                     	patientDetailsList1.add(addPatientDetails(data1));
                     	                     	
                     }
                     
                    
                     //patientsDAO.deletePatients(patientlist);
     			    
     			    for(PatientDetails patient : patientDetailsList1) {     			    
                         pccpatientInfo.put(patient.getPatientId(), patient);
                         
                         }
     			   patientlist = patientsDAO.getPatient(nrfacility,sendingApplication);
     			    for(PatientDetails dbPatient : patientlist) {
                         updatedPatient = pccpatientInfo.get(dbPatient.getPatientId());
                         if(updatedPatient == null){
                                patientsInactive = updateInactivePatient(dbPatient);
                                patientDetailsList.add(patientsInactive);
                         }      
                         }
     			    
     			    for(PatientDetails patient : patientlist) {
     					patientInfo.put(patient.getPatientId(), patient);
     			    }
                     
                     for(PatientDetails pccpatientdetails : patientDetailsList1){
         				
                    	 updatePatient = patientInfo.get(pccpatientdetails.getPatientId());
                    	 
         				if(updatePatient != null){
     						updatePatients = updatePatientDetails(updatePatient,pccpatientdetails);
     						patientDetailsList.add(updatePatients);
     					}else {
     						createPatients = createPatientDetails(pccpatientdetails);
     						patientDetailsList.add(createPatients);
     					}
                     }
         			
                     logger.info("End of GetPatient method");
                    patientsDAO.patientDetails(patientDetailsList);
                     int count=patientDetailsList.size();
                     System.out.println(count +"patients updated successfully");
                     /*List<FailedBatch> failedBatchList=patientsDAO.patientDetails(patientDetailsList);
                     if(!(failedBatchList.size() > 0)) {
                     int count=patientDetailsList.size();
         			EMROperatorInfo emrList = updateFacility(facilityList);
					patientsDAO.saveupdatedfacility(emrList);
                     
                     System.out.println(count +"patients updated successfully");
                     }
                     else {
 						throw new RuntimeException("ERROR OCCURED IN USERS CREATION");
 					}*/
                 } finally {
                     if (bufferedReader != null) {
                         bufferedReader.close();
                     }
                 }
             }
         } catch (Exception e) {
         	InputStream errorstream = connection.getErrorStream();
         	if(errorstream != null)
         	{
         	BufferedReader br = null;
         	System.out.println("Comes to errorstream while try to get token");
             br = new BufferedReader(new InputStreamReader(errorstream));
             String response1 = "";
             String nachricht;
             while ((nachricht = br.readLine()) != null){
                 response1 += nachricht;
             }
             JsonParser jsonParserError = new JsonParser();
             String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
             Gson gsonError = new Gson();
             patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
             String errDetail = null;
             for(Errors errors : patientsResponseError.getErrors()){
             	System.out.println("response1" + errors.getTitle());
             	System.out.println("response2" + errors.getDetail());
             	logger.error(errors.getDetail());
             	errDetail = errors.getDetail();
/*             	if (errDetail!=null)
             		{
             		System.out.println(errDetail);
             		break;
             		}*/
             }
             
         	}
             
             e.printStackTrace();
         } finally {
             if (connection != null) {
                 connection.disconnect();
             }
         }
         	Paging paging = patients.getPaging();
         	page = paging.getPage();
              has = paging.getHasMore();
             System.out.println("hasmore flag" + has);
             logger.info("hasmore flag" + has);
/*             DateFormat converter1 = null;
             converter1 = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
             converter1.setTimeZone(TimeZone.getTimeZone("America/New_York"));
             Calendar calendar1 = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
             String formatedDate1 = converter.format(calendar1.getTime()).toString().replace(".", "");*/
              presenttime = dateObject.getCurrenttime();
              System.out.println("Current Time" +presenttime );
            // }
             } while (has.equals("true") && newaccessTokenExpiresL >= presenttime); 	
            	 
            	 }
            	 catch (Exception e)
             	{
             		e.printStackTrace();
             	}
            	 logger.info("End of do while");
     		} 
            
             else {
            	 logger.error("New Access token Expired");
             }
             
        }  
		       
        else {
      			logger.error("Referesh token Expired");
      		}
           
                
        
		
		}
       
    return  patients;

	}
	

	private PatientDetails addPatientDetails(Data data1) {
		// TODO Auto-generated method stub
		dataKey = CommonUtil.getInstance().getDataKey();
		PatientDetails patientdetails = new PatientDetails();
//		patientdetails.setPatientId(data1.getPatientId() != null && data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
		patientdetails.setPatientId(data1.getPatientId() != null && !data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
		if(data1.getPatientStatus().equals("Current") && data1.getOutpatient().equals("false"))
		{
			patientdetails.setPatientStatus("ACTIVE");
			patientdetails.setOutpatient("false");
			//patientdetails.setHasPhoto(data1.getHasPhoto());
		}
		else
		{
			patientdetails.setPatientStatus("INACTIVE");
			patientdetails.setOutpatient("true");
			//patientdetails.setHasPhoto(data1.getHasPhoto());
		}
		 // Else part meant for making patients
		patientdetails.setClientId(data1.getOrgId() != null && !data1.getOrgId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getOrgId(), dataKey) : null);
		patientdetails.setAdministrativeSex(data1.getGender());
		patientdetails.setAssignedPatientLocationBed(data1.getBedId());
		patientdetails.setAdmitDateOrTime(data1.getAdmissionDate());
		patientdetails.setGivenName(data1.getFirstName() != null && !data1.getFirstName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getFirstName(), dataKey) : null);
//		patientdetails.setGivenName(data1.getFirstName());
		patientdetails.setFamilyName(data1.getLastName() != null && !data1.getLastName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getLastName(), dataKey) : null);
//		patientdetails.setFamilyName(data1.getLastName());
		patientdetails.setSendingFacility(data1.getFacId()+"."+data1.getOrgId());
		if(data1.getBirthDate() != null)
		{
		String dob = data1.getBirthDate().replaceAll("[^0-9\\+]", "");
		patientdetails.setDob(dob != null && !dob.trim().isEmpty() ? BouncyCastleEngine.AESEncryption(dob, dataKey) : null);
		}
		//patientdetails.setOutpatient(data1.getOutpatient());
		patientdetails.setSendingApplication("PCCApp");
		patientdetails.setBedStatus(data1.getBedDesc());
		patientdetails.setAssignedPatientLocationRoom(data1.getRoomDesc());
		patientdetails.setAssignedPatientLocationFloor(data1.getFloorId());
		patientdetails.setPatientSSNNumber(data1.getMedicalRecordNumber());
/*		if(data1.getHasPhoto().equals("true"))
		{
		patientdetails.setHasPhoto(data1.getHasPhoto());
		}
		else
		{
			patientdetails.setHasPhoto(data1.getHasPhoto());
		}*/
		//patientdetails.setHasPhoto(data1.getHasPhoto());
		patientdetails.setReceivingApplication("NR");
		patientdetails.setReceivingFacility("NURSEROSIE_ADT");
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		patientdetails.setLastModifiedOn(timeStamp);
		//patientdetails.setHasPhoto(data1.getHasPhoto());
		return patientdetails;
	}
	
	private PatientDetails createPatientDetails(PatientDetails pccpatientdetails){
		dataKey = CommonUtil.getInstance().getDataKey();
		try {
		
		    PatientDetails addPatient = new PatientDetails();
		     
		    if(pccpatientdetails.getPatientId() != null && !pccpatientdetails.getPatientId().equals("")) {
//		    	addPatient.setPatientId(data1.getPatientId() != null && data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
		    	addPatient.setPatientId(pccpatientdetails.getPatientId());
			}
		    if(pccpatientdetails.getPatientStatus() != null && !pccpatientdetails.getPatientStatus().equals(""))
		    {
		    	addPatient.setPatientStatus(pccpatientdetails.getPatientStatus());
		    }
		    if(pccpatientdetails.getOutpatient() != null && !pccpatientdetails.getOutpatient().equals(""))
		    {
		    	addPatient.setOutpatient(pccpatientdetails.getOutpatient());
		    }
//		    if(pccpatientdetails.getPatientStatus().equals("Current"))
//			{
//		    	addPatient.setPatientStatus("ACTIVE");
//			}
//			else
//			{
//				addPatient.setPatientStatus("INACTIVE");
//			}
		    if(pccpatientdetails.getClientId() != null && !pccpatientdetails.getClientId().equals("")) {
		    	addPatient.setClientId(pccpatientdetails.getClientId());
			}
		    if(pccpatientdetails.getAdministrativeSex() != null && !pccpatientdetails.getAdministrativeSex().equals("")) {
		    	addPatient.setAdministrativeSex(pccpatientdetails.getAdministrativeSex());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationBed() != null && !pccpatientdetails.getAssignedPatientLocationBed().equals("")) {
		    	addPatient.setBedStatus(pccpatientdetails.getAssignedPatientLocationBed());
		    }
		    if(pccpatientdetails.getAdmitDateOrTime() != null && !pccpatientdetails.getAdmitDateOrTime().equals("")) {
		    	addPatient.setAdmitDateOrTime(pccpatientdetails.getAdmitDateOrTime());
		    }
		    if(pccpatientdetails.getGivenName() != null && !pccpatientdetails.getGivenName().equals("")) {
//		    	addPatient.setGivenName(data1.getFirstName() != null && data1.getFirstName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getFirstName(), dataKey) : null);
		    	addPatient.setGivenName(pccpatientdetails.getGivenName());
		    }
		    if(pccpatientdetails.getFamilyName() != null && !pccpatientdetails.getFamilyName().equals("")) {
//		    	addPatient.setFamilyName(data1.getLastName() != null && data1.getLastName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getLastName(), dataKey) : null);
		    	addPatient.setFamilyName(pccpatientdetails.getFamilyName());
		    }
		    if(pccpatientdetails.getSendingFacility() != null && !pccpatientdetails.getSendingFacility().equals("")) {
		    	addPatient.setSendingFacility(pccpatientdetails.getSendingFacility());
		    }
		    if(pccpatientdetails.getDob() != null && !pccpatientdetails.getDob().equals("")) {
		    	addPatient.setDob(pccpatientdetails.getDob());
		    }
		    addPatient.setSendingApplication("PCCApp");
		    if(pccpatientdetails.getBedStatus() != null && !pccpatientdetails.getBedStatus().equals("")) {
		    	addPatient.setAssignedPatientLocationBed(pccpatientdetails.getBedStatus());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationRoom() != null && !pccpatientdetails.getAssignedPatientLocationRoom().equals("")) {
		    	addPatient.setAssignedPatientLocationRoom(pccpatientdetails.getAssignedPatientLocationRoom());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationFloor() != null && !pccpatientdetails.getAssignedPatientLocationFloor().equals("")) {
		    	addPatient.setPriorPatientLocationFloor(pccpatientdetails.getAssignedPatientLocationFloor());
		    }
		    if(pccpatientdetails.getPatientSSNNumber() != null && !pccpatientdetails.getPatientSSNNumber().equals("")) {
		    	addPatient.setPatientSSNNumber(pccpatientdetails.getPatientSSNNumber());
		    }
/*		    if(pccpatientdetails.getHasPhoto()!=null && !pccpatientdetails.getHasPhoto().equals("") )
		    {
		    	addPatient.setHasPhoto(pccpatientdetails.getHasPhoto());
		    }*/
		    String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		    addPatient.setLastModifiedOn(timeStamp);
		    addPatient.setReceivingApplication("NR");
		    addPatient.setReceivingFacility("NURSEROSIE_ADT");
		
		    return addPatient;
		
		}catch(Exception e){
			System.out.println("e1"+ e.getMessage());
			throw new RuntimeException(e.getMessage(),e);
		}
	}
	
	private PatientDetails updatePatientDetails(PatientDetails updatePatient,PatientDetails pccpatientdetails){
		try {
				
			if(pccpatientdetails.getPatientId() != null && !pccpatientdetails.getPatientId().equals("")) {
//		    	addPatient.setPatientId(data1.getPatientId() != null && data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
				updatePatient.setPatientId(pccpatientdetails.getPatientId());
			}
			if(pccpatientdetails.getPatientStatus() != null && !pccpatientdetails.getPatientStatus().equals(""))
		    {
				updatePatient.setPatientStatus(pccpatientdetails.getPatientStatus());
		    }
//		    if(pccpatientdetails.getPatientStatus().equals("Current"))
//			{
//		    	updatePatient.setPatientStatus("ACTIVE");
//			}
//			else
//			{
//				updatePatient.setPatientStatus("INACTIVE");
//			}
		    if(pccpatientdetails.getClientId() != null && !pccpatientdetails.getClientId().equals("")) {
		    	updatePatient.setClientId(pccpatientdetails.getClientId());
			}
		    if(pccpatientdetails.getAdministrativeSex() != null && !pccpatientdetails.getAdministrativeSex().equals("")) {
		    	updatePatient.setAdministrativeSex(pccpatientdetails.getAdministrativeSex());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationBed() != null && !pccpatientdetails.getAssignedPatientLocationBed().equals("")) {
		    	updatePatient.setBedStatus(pccpatientdetails.getAssignedPatientLocationBed());
		    }
		    if(pccpatientdetails.getAdmitDateOrTime() != null && !pccpatientdetails.getAdmitDateOrTime().equals("")) {
		    	updatePatient.setAdmitDateOrTime(pccpatientdetails.getAdmitDateOrTime());
		    }
		    if(pccpatientdetails.getGivenName() != null && !pccpatientdetails.getGivenName().equals("")) {
//		    	addPatient.setGivenName(data1.getFirstName() != null && data1.getFirstName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getFirstName(), dataKey) : null);
		    	updatePatient.setGivenName(pccpatientdetails.getGivenName());
		    }
		    if(pccpatientdetails.getFamilyName() != null && !pccpatientdetails.getFamilyName().equals("")) {
//		    	addPatient.setFamilyName(data1.getLastName() != null && data1.getLastName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getLastName(), dataKey) : null);
		    	updatePatient.setFamilyName(pccpatientdetails.getFamilyName());
		    }
		    if(pccpatientdetails.getSendingFacility() != null && !pccpatientdetails.getSendingFacility().equals("")) {
		    	updatePatient.setSendingFacility(pccpatientdetails.getSendingFacility());
		    }
		    if(pccpatientdetails.getDob() != null && !pccpatientdetails.getDob().equals("")) {
		    	updatePatient.setDob(pccpatientdetails.getDob());
		    }
		    updatePatient.setSendingApplication("PCCApp");
		    if(pccpatientdetails.getBedStatus() != null && !pccpatientdetails.getBedStatus().equals("")) {
		    	updatePatient.setAssignedPatientLocationBed(pccpatientdetails.getBedStatus());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationRoom() != null && !pccpatientdetails.getAssignedPatientLocationRoom().equals("")) {
		    	updatePatient.setAssignedPatientLocationRoom(pccpatientdetails.getAssignedPatientLocationRoom());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationFloor() != null && !pccpatientdetails.getAssignedPatientLocationFloor().equals("")) {
		    	updatePatient.setPriorPatientLocationFloor(pccpatientdetails.getAssignedPatientLocationFloor());
		    }
		    if(pccpatientdetails.getPatientSSNNumber() != null && !pccpatientdetails.getPatientSSNNumber().equals("")) {
		    	updatePatient.setPatientSSNNumber(pccpatientdetails.getPatientSSNNumber());
		    }
/*		    if(pccpatientdetails.getHasPhoto()!=null && !pccpatientdetails.getHasPhoto().equals(""))
		    {
		    	updatePatient.setHasPhoto(pccpatientdetails.getHasPhoto());
		    }*/
		    String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		    updatePatient.setLastModifiedOn(timeStamp);
		    updatePatient.setReceivingApplication("NR");
		    updatePatient.setReceivingFacility("NURSEROSIE_ADT");
			
//		    if(data1.getPatientId() != null && !data1.getPatientId().equals("")) {
//				updatePatient.setPatientId(data1.getPatientId());
//			}
//			if(data1.getPatientId() != null && !data1.getPatientId().equals("")) {
//				updatePatient.setClientId(data1.getPatientId());
//			}
		//	
//			if(data1.getGender() != null && !data1.getGender().equals("")) {
//				updatePatient.setAdministrativeSex(data1.getGender());
//		    }
//		    if(data1.getAdmissionDate() != null && !data1.getAdmissionDate().equals("")) {
//		    	updatePatient.setAdmitDateOrTime(data1.getAdmissionDate());
//		    }
		//    
//		    if(data1.getPatientStatus() != null && !data1.getPatientStatus().equals("")) {
//		    	updatePatient.setPatientStatus(data1.getPatientStatus());
//		    }
		    
		    
			
			return updatePatient;
		
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
	
	public EMROperatorInfo AccessToken(String refereshToken,String refereshTokenExpiresIn) throws MalformedURLException
	{
		EMROperatorInfo emrOperatorInfo = null;
		StringBuilder response = null;
		HttpURLConnection connection = null;
		
		DateFormat converter = null;
        converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
        converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
        long currenttime = Long.parseLong(formatedDate);
        
		System.out.println("Before Calling newAccessToken API time:"+ currenttime );
	// Demo getAccessToken URL :	
	//	final String URLstr = "https://5zexw2gi20.execute-api.us-east-1.amazonaws.com/poc/pcc-developer/get-token?code=&refresh_token="+refereshToken+"";
	// Prod  getAccessToken URL : 	
		String URLstr = "https://pccdeveloperapi.rosieconnect2.com/api/get-token?code=&refresh_token="+refereshToken+"";
		System.out.println("Calling newAccessToken API"+ URLstr );
		System.out.println("After Calling newAccessToken API time:"+ currenttime );
        try {
        final URL url = new URL(URLstr);
    	connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(HttpMethod.GET);
		connection.setDoOutput(true);
//		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
		
		if (connection.getInputStream() != null) {
			logger.info("Comes to InputStream");
            final InputStream inputStream = connection.getInputStream();
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            try {
                response = new StringBuilder();

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }
                JsonParser jsonParser = new JsonParser();
                String jsonObject = jsonParser.parse(response.toString()).toString();
                Gson gson = new Gson();
                emrOperatorInfo = gson.fromJson(jsonObject, EMROperatorInfo.class);
                
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
		}
    } catch (Exception e) {
    	InputStream errorstream = connection.getErrorStream();
    	if(errorstream != null)
    	{
    	BufferedReader br = null;
    	System.out.println("Comes to errorstream while try to get token");
        br = new BufferedReader(new InputStreamReader(errorstream));
        String response1 = "";
        String nachricht;
        try {
			while ((nachricht = br.readLine()) != null){
			    response1 += nachricht;
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        JsonParser jsonParserError = new JsonParser();
        String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
        Gson gsonError = new Gson();
        PatientsError patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
        String errDetail = null;
        for(Errors errors : patientsResponseError.getErrors()){
        	System.out.println("response1" + errors.getTitle());
        	System.out.println("response2" + errors.getDetail());
        	logger.error(errors.getDetail());
        	errDetail = errors.getDetail();
        	break;
        	
        }
    	}
        
        e.printStackTrace();
    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    }
		
		return emrOperatorInfo;
	}
	
	public EMROperatorInfo updateemrInfo(EMROperatorInfo emrinfo,EMROperatorInfo facilityList){
		
		EMROperatorInfo facility = new EMROperatorInfo();
		
		String facility1 = facilityList.getFacility();
		String emroperator1 = facilityList.getEmrOperator();
		PatientsDAO patientDAO = new PatientsDAOImpl();
		EMROperatorInfo emrinf = patientDAO.getEMRInfo(facility1,emroperator1);
		emrinf.setAccessToken(emrinfo.getAccess_token());
		emrinf.setAccexpiresIn(emrinfo.getExpires_in());
		return emrinf;
	}
	
	private PatientDetails updateInactivePatient(PatientDetails dbPatient)
    {
           dbPatient.setPatientStatus("INACTIVE");
           //dbPatient.setHasPhoto("false");
          String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
           dbPatient.setLastModifiedOn(timeStamp);
           return dbPatient;
    }
	
private EMROperatorInfo updateFacility(EMROperatorInfo emrOperatorList) throws ParseException  {
		

   
	String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
   
        Date mDate = sdf.parse(timeStamp);
        long timeInMilliseconds = mDate.getTime()-((60*5)*1000) ;
        Date date = new Date(timeInMilliseconds);
        DateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String time = formatter.format(date); 
		
		emrOperatorList.setLastUpdatedPatient(time);
		
		
		return emrOperatorList;
		
	}
/*private long dateConversion()
{
	
	DateFormat converter = null;
    converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
    converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
    String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
     long currenttime = Long.parseLong(formatedDate);
     //dateObject.setCurrenttime(currenttime);
    return currenttime;
}*/

}