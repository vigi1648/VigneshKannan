package com.zsl.patientscron.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.patientscron.controller.LambdaFunctionHandler;
import com.zsl.patientscron.service.PatientsService;
import com.zsl.patientscron.service.PatientsServiceImpl;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {
	
	static final Logger logger = LogManager.getLogger(LambdaFunctionHandler.class);
	 @Override
    public Object handleRequest(Object input, Context context) {
    	
    	System.out.println(" Enter Lambda Function Handler method");
    	logger.info("Info Message Logged !!!");
    	PatientsService patientsService = new PatientsServiceImpl();
    	Map<String, String> userInfo = new LinkedHashMap<String, String>();
    	userInfo.put("emrOperator", "PCCApp");
    	
    	try {
			return patientsService.getPatients(userInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
		return userInfo;
    }
    
    
    public static void main(String [] args) throws Exception{
    	
    	System.out.println("Main mathod");
    	PatientsService patientsService = new PatientsServiceImpl();
    	Map<String, String> userInfo = new LinkedHashMap<String, String>();
    	userInfo.put("emrOperator", "PCCApp");
    	//userInfo.put("facility", "48.80072");
    	patientsService.getPatients(userInfo);
    
    }

}
