package com.zsl.cron.dao;

import java.util.List;

import com.zsl.cron.dto.EMROperatorInfo;
import com.zsl.cron.dto.PatientDetails;
import com.zsl.cron.dto.Patients;

public interface PatientsDAO {

	public Patients patientDetails(List<PatientDetails> patientDetailsList);
	
	public List<PatientDetails> getPatient(String sendingFacility, String sendingApplication);
	
	public List<EMROperatorInfo> getfacility(String emrOperator);
	
	public String updateEmrInfo(EMROperatorInfo emrIn);
		
	public EMROperatorInfo getEMRInfo(String facility1,String emroperator1);
}
