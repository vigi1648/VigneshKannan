package com.zsl.cron.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.kms.AWSKMS;
import com.amazonaws.services.kms.AWSKMSClient;
import com.amazonaws.services.kms.model.DecryptRequest;
import com.amazonaws.util.IOUtils;

public class CommonUtil {
	
	private static CommonUtil commonUtil;
	private String dataKey;
	
private CommonUtil(){}
	
	public static CommonUtil getInstance(){
		if(commonUtil == null){
			commonUtil = new CommonUtil();
		}
		return commonUtil;
	}
	
	public static void resetInsatnce(){
		commonUtil = null;
	}

	public HttpURLConnection getHttpURLConnection(){
		URL url = null;
		HttpURLConnection httpURLConnection = null;
		try {
			url = new URL("https://connections.matrixcare.com:2443/services/MDIAchieveAPI_Prod");
		    httpURLConnection = (HttpURLConnection)url.openConnection();
		    
		} catch (MalformedURLException mfue) {
			mfue.getStackTrace();
		} catch(IOException ioe){
			ioe.getStackTrace();
		}
		return httpURLConnection;
	}
	
	public DocumentBuilderFactory getDocumentBuilderFactory(){
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		return docFactory;
	}
	
	public DocumentBuilder getDocumentBuilder(DocumentBuilderFactory docFactory){
		DocumentBuilder docBuilder = null;
		try {
			docBuilder = docFactory.newDocumentBuilder();
		} catch (ParserConfigurationException pce) {
			// TODO: handle exception
		}
		
		return docBuilder;
	}
	
	public static TransformerFactory getTransformerFactory(){
		return TransformerFactory.newInstance();
	}
	
	public static Transformer getTransformer(TransformerFactory transformerFactory){
		Transformer transformer = null;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (TransformerConfigurationException tfce) {
			
		}
	
	return transformer;
}

	public String toEncode(String value){
		String encodedValue = null;
		try {
			encodedValue = Base64.getEncoder().encodeToString(value.getBytes());
		} catch (Exception e){
			
		}
		return encodedValue;
	}
	
	
	public String getDataKey(){
		if(dataKey == null){
		 String dataKeySrc = "2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o";
		//String dataSrc = null;
		 //String decryptStr = null;
		try {
			AWSCredentials awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			AWSKMS awsKms = new AWSKMSClient(awsCredentials);
			//AWSKMS awsKms = new AWSKMSClient();
			InputStream inputStream = Class.forName("com.zsl.cron.util.CommonUtil").getResourceAsStream("encryptkey.txt");
			byte[] bytes = IOUtils.toByteArray(inputStream);
			inputStream.close();
			
		
			DecryptRequest decryptRequest = new DecryptRequest();
		    decryptRequest.setCiphertextBlob(ByteBuffer.wrap(bytes));
		    ByteBuffer plainTextKey = awsKms.decrypt(decryptRequest).getPlaintext();
		    dataKey = decrypt(dataKeySrc, makeKey(plainTextKey));
		} catch (FileNotFoundException fnfe) {
			throw new RuntimeException(fnfe.getMessage(), fnfe);
		} catch (IOException ioe){	
			throw new RuntimeException(ioe.getMessage(), ioe);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		} 
		}
		return dataKey;
	}
	
	private String decrypt(String src, Key key){
		try {
			byte[] decodeBase64src = DatatypeConverter.parseBase64Binary(src);
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, key);
			
			return new String(cipher.doFinal(decodeBase64src));
			
		} catch (NoSuchAlgorithmException nsae) {
			throw new RuntimeException(nsae.getMessage(), nsae);
		} catch (NoSuchPaddingException nspe) {
			throw new RuntimeException(nspe.getMessage(), nspe);
		} catch (InvalidKeyException ike) {
			throw new RuntimeException(ike.getMessage(), ike);
		} catch (IllegalBlockSizeException ibse) {
			throw new RuntimeException(ibse.getMessage(), ibse);
		} catch (BadPaddingException bpe){
			throw new RuntimeException(bpe.getMessage(), bpe);
		}
	}
	
	public Key makeKey(ByteBuffer key) {
		return new SecretKeySpec(getByteArray(key), "AES");
	}

	public String getString(ByteBuffer b) {

		return new String(getByteArray(b));
	}

	public byte[] getByteArray(ByteBuffer b) {
		byte[] byteArray = new byte[b.remaining()];
		b.get(byteArray);
		return byteArray;
	}

	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	
	public String getFirstNameFromFullName(String fullName){
		int firstIndex = fullName.indexOf(" ");
		return fullName.substring(0, firstIndex);
	}
	
	public String getLastNameFromFullName(String fullName){
		int firstIndex = fullName.indexOf(" ");
		return fullName.substring(firstIndex+1, fullName.length());
	}
}
