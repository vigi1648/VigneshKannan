package com.zsl.cron.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="PCCDEVELOPER")
public class PatientsError
{
	
    private Errors[] errors;

	public Errors[] getErrors() {
		return errors;
	}

	public void setErrors(Errors[] errors) {
		this.errors = errors;
	}

//    private Paging paging;

    

//    public Paging getPaging ()
//    {
//        return paging;
//    }
//
//    public void setPaging (Paging paging)
//    {
//        this.paging = paging;
//    }
//
//    @Override
//    public String toString()
//    {
//        return "ClassPojo [data = "+data+", paging = "+paging+"]";
//    }
}