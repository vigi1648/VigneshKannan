package com.zsl.cron.util;

import java.io.UnsupportedEncodingException;

import javax.xml.bind.DatatypeConverter;

import org.bouncycastle.crypto.*;
import org.bouncycastle.crypto.engines.*;
import org.bouncycastle.crypto.paddings.*;
import org.bouncycastle.crypto.params.*;

public class BouncyCastleEngine {

	private BlockCipher _blockCipher;
    private PaddedBufferedBlockCipher _cipher;
    private BlockCipherPadding _padding;
    
    public BouncyCastleEngine(BlockCipher blockCipher)
    {
        _blockCipher = blockCipher;
    }
    
    public void SetPadding(BlockCipherPadding padding)
    {
        if (padding != null)
            _padding = padding;
    }
    
    public String Encrypt(String plain, String key) throws UnsupportedEncodingException, CryptoException
    {
        byte[] result = BouncyCastleCrypto(true, plain.getBytes("UTF-8"), key);
        String encodedString = DatatypeConverter.printBase64Binary(result);
        return encodedString;
    }
    
    private byte[] BouncyCastleCrypto(boolean forEncrypt, byte[] input, String key) throws UnsupportedEncodingException, CryptoException
    {
            _cipher = _padding == null ? new PaddedBufferedBlockCipher(_blockCipher) : new PaddedBufferedBlockCipher(_blockCipher, _padding);
            byte[] keyByte = key.getBytes("UTF-8");
            _cipher.init(forEncrypt, new KeyParameter(keyByte));
            byte[] cipherArray = new byte[_cipher.getOutputSize(input.length)];
            int outputByteCount = _cipher.processBytes(input, 0,
        			input.length, cipherArray, 0);
            
            outputByteCount += _cipher.doFinal(cipherArray, outputByteCount);
        	byte[] result = new byte[outputByteCount];
        	System.arraycopy(cipherArray, 0, result, 0, outputByteCount);
        	return result;
    }
    
    public static String AESEncryption(String plain, String key)
    {
    	BouncyCastleEngine bcEngine = new BouncyCastleEngine(new AESEngine());
        bcEngine.SetPadding(new PKCS7Padding());
        try {
        	return bcEngine.Encrypt(plain, key);
		} catch (UnsupportedEncodingException uee) {
			throw new RuntimeException("Internal Server Error", uee);
		} catch (CryptoException ce) {
			throw new RuntimeException("Internal Server Error", ce);
		}
        
    }
    
}
