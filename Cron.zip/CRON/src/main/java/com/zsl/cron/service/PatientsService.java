package com.zsl.cron.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.zsl.cron.dto.PatientDetails;

public interface PatientsService {

	public Object getPatients(Map<String, String> userInfo) throws IOException,InterruptedException;
	
}
