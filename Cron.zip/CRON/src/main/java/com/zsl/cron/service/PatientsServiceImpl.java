package com.zsl.cron.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.zsl.cron.dao.PatientsDAO;
import com.zsl.cron.dao.PatientsDAOImpl;
import com.zsl.cron.dto.Data;
import com.zsl.cron.dto.EMROperatorInfo;
import com.zsl.cron.dto.Errors;
import com.zsl.cron.dto.Paging;
import com.zsl.cron.dto.PatientDetails;
import com.zsl.cron.dto.Patients;
import com.zsl.cron.dto.PatientsError;
import com.zsl.cron.dto.RefereshToken;
import com.zsl.cron.util.BouncyCastleEngine;
import com.zsl.cron.util.CommonUtil;

public class PatientsServiceImpl implements PatientsService {
	
	static final Logger logger = LogManager.getLogger(PatientsServiceImpl.class);
	
	private String dataKey;

//	@SuppressWarnings("unchecked")
	@Override
	

public Object getPatients(Map<String, String> userInfo) throws IOException, InterruptedException {
		
		logger.info("Entered into getPatient service");
		
		PatientsDAO patientsDAO = new PatientsDAOImpl();
		Data data = new Data();
		
		Patients patients = new Patients(); 
		
		EMROperatorInfo emrinfo = null;
		StringBuilder response = null;
		List<PatientDetails> patientDetailsList = null;
		List<PatientDetails> patientDetailsList1 = null;
		List<PatientDetails> patientlist = null;
		Map<String, PatientDetails> patientInfo = null;
		Map<String, PatientDetails> pccpatientInfo = null;
		PatientDetails updatePatient = null;
		PatientDetails updatedPatient = null;
		PatientDetails createPatients = null;
		PatientDetails updatePatients = null;
		PatientDetails patientsInactive = null;
		patientDetailsList = new ArrayList<PatientDetails>();
		patientInfo = new HashMap<String, PatientDetails>();
		pccpatientInfo = new HashMap<String, PatientDetails>();
		PatientsError patientsResponseError = null;
//		PatientsDAO patientsDAO = new PatientsDAOImpl();
//		LoginInfo loginInfo = patientsDAO.getLoginInfo();
		
		String emrOperator = userInfo.get("emrOperator");
		
		List<EMROperatorInfo> emrOperatorList = patientsDAO.getfacility(emrOperator);
		
		for(EMROperatorInfo facilityList : emrOperatorList){
			String[] facilityArray = facilityList.getFacility().split("\\.");
			String nrfacility = facilityList.getFacility();
//          String facility = facilityList.getFacility();
			String facility = facilityArray[0];
            String sendingApplication = facilityList.getEmrOperator();
            String orgId = facilityList.getOrigin();
            String accessToken = facilityList.getAccessToken();
            String accessTokenExpiresIn = facilityList.getAccexpiresIn().replace(".", "");
            long accessTokenExpiresL = Long.parseLong(accessTokenExpiresIn);
            String refereshToken = facilityList.getRefreshToken();
            String refereshTokenExpiresIn = facilityList.getRefexpiresIn().replace(".", "");
            long refereshTokenExpiresL = Long.parseLong(refereshTokenExpiresIn);
            logger.info("Entered into EMROperatorInfo Iterator" + facility);
            
            DateFormat converter = null;
            converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
            converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
            String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
            long currenttime = Long.parseLong(formatedDate);
      
            String has = null;
            int page = 0;
           
            
      
       
        if(accessTokenExpiresL >= currenttime)
        {
        	do
        	{

        int i = 1 + page;
		HttpURLConnection connection = null;
		System.out.println("Before Calling time of getPatient API:" + currenttime);
//    	final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+userInfo.get("orgId")+"/patients?facId="+userInfo.get("facilityId")+"";
		final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients?facId="+facility+"&patientStatus=Current&pageSize=200&page="+i+"";
		System.out.println("PCC getPatient API Call URL" + urlString);
		System.out.println("After Calling time of getPatient API:" + currenttime);
		//Thread.sleep(20);
		logger.info("URL String of GetPatient" + urlString);
    	String authorization = "Bearer "+accessToken;
    	try{
    	final URL url = new URL(urlString);
    	connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(HttpMethod.GET);
		connection.setDoOutput(true);
		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
		connection.setRequestProperty("Authorization", authorization);
		
		if (connection.getInputStream() != null) {
			logger.info("Comes to InputStream");
            final InputStream inputStream = connection.getInputStream();
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            try {
                response = new StringBuilder();

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }
                JsonParser jsonParser = new JsonParser();
                String jsonObject = jsonParser.parse(response.toString()).toString();
                Gson gson = new Gson();
                patients = gson.fromJson(jsonObject, Patients.class);
                
                patientDetailsList1 = new ArrayList<PatientDetails>();
                
                for(Data data1 : patients.getData()){
                	patientDetailsList1.add(addPatientDetails(data1));
                	
                }
                
                patientlist = patientsDAO.getPatient(nrfacility,sendingApplication);

			    
			    for(PatientDetails patient : patientDetailsList1) {
                    pccpatientInfo.put(patient.getPatientId(), patient);
                    
                    }
			    
			    for(PatientDetails dbPatient : patientlist) {
                    updatedPatient = pccpatientInfo.get(dbPatient.getPatientId());
                    if(updatedPatient == null){
                           patientsInactive = updateInactivePatient(dbPatient);
                           patientDetailsList.add(patientsInactive);
                    }      
                    }
			    
			    for(PatientDetails patient : patientlist) {
					patientInfo.put(patient.getPatientId(), patient);
				}
                
                for(PatientDetails pccpatientdetails : patientDetailsList1){
    				
    				updatePatient = patientInfo.get(pccpatientdetails.getPatientId());
    				if(updatePatient != null){
						updatePatients = updatePatientDetails(updatePatient,pccpatientdetails);
						patientDetailsList.add(updatePatients);
					}else {
						createPatients = createPatientDetails(pccpatientdetails);
						patientDetailsList.add(createPatients);
					}
    			}
                logger.info("End of GetPatient method");
                patientsDAO.patientDetails(patientDetailsList);
                System.out.println("Patients updated successfully");
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
        }
    } catch (Exception e) {
    	InputStream errorstream = connection.getErrorStream();
    	if(errorstream != null)
    	{
    	BufferedReader br = null;
    	System.out.println("Comes to errorstream while try to get token");
        br = new BufferedReader(new InputStreamReader(errorstream));
        String response1 = "";
        String nachricht;
        while ((nachricht = br.readLine()) != null){
            response1 += nachricht;
        }
        JsonParser jsonParserError = new JsonParser();
        String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
        Gson gsonError = new Gson();
        patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
        String errDetail = null;
        for(Errors errors : patientsResponseError.getErrors()){
        	System.out.println("response1" + errors.getTitle());
        	System.out.println("response2" + errors.getDetail());
        	logger.error(errors.getDetail());
        	errDetail = errors.getDetail();
        	 break;
        	
        }
    	}
        
        e.printStackTrace();
    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    }
    	Paging paging = patients.getPaging();
    	page = paging.getPage();
         has = paging.getHasMore();
        System.out.println("hasmore flag" + has);
        logger.info("hasmore flag" + has);
        } while (has.equals("true"));
        		
		}
        else if(refereshTokenExpiresL >= currenttime){
        	 emrinfo = AccessToken(refereshToken,refereshTokenExpiresIn);
             String newaccessToken = emrinfo.getAccess_token();
             String newaccessTokenExpiresIn = emrinfo.getExpires_in().replace(".","");
             long newaccessTokenExpiresL = Long.parseLong(newaccessTokenExpiresIn);
             String newrefereshTokenExpiresIn = emrinfo.getRefresh_expires_in().replace(".", "");
             long newrefereshTokenExpiresL = Long.parseLong(newrefereshTokenExpiresIn);
             EMROperatorInfo emrIn = updateemrInfo(emrinfo,facilityList);
             PatientsDAO patientDAO = new PatientsDAOImpl();
          // String updtdmsg = patientDAO.updateEmrInfo(emrIn);
      
             if(newaccessTokenExpiresL >= currenttime){
            	 do
             	{
            		 
             int i = 1 + page;
     		HttpURLConnection connection = null;
     		System.out.println("Before Calling time of getPatient API:" + currenttime);
//         	final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+userInfo.get("orgId")+"/patients?facId="+userInfo.get("facilityId")+"";
     		final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients?facId="+facility+"&patientStatus=Current&pageSize=200&page="+i+"";
     		System.out.println("PCC getPatient API Call URL" + urlString);
    		System.out.println("After Calling time of API:" + currenttime);
    		//Thread.sleep(20);
     		logger.info("URL String of GetPatient" + urlString);
         	String authorization = "Bearer "+newaccessToken;
         	try{
         	final URL url = new URL(urlString);
         	connection = (HttpURLConnection) url.openConnection();
     		connection.setRequestMethod(HttpMethod.GET);
     		connection.setDoOutput(true);
     		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
     		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
     		connection.setRequestProperty("Authorization", authorization);
     		
     		if (connection.getInputStream() != null) {
     			logger.info("Comes to InputStream");
                 final InputStream inputStream = connection.getInputStream();
                 final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                 try {
                     response = new StringBuilder();

                     String line;
                     while ((line = bufferedReader.readLine()) != null) {
                         response.append(line);
                     }
                     JsonParser jsonParser = new JsonParser();
                     String jsonObject = jsonParser.parse(response.toString()).toString();
                     Gson gson = new Gson();
                     patients = gson.fromJson(jsonObject, Patients.class);
                     
                     patientDetailsList1 = new ArrayList<PatientDetails>();
                     
                     for(Data data1 : patients.getData()){
                     	patientDetailsList1.add(addPatientDetails(data1));
                     	
                     }
                     
                     patientlist = patientsDAO.getPatient(nrfacility,sendingApplication);
     			    
     			    for(PatientDetails patient : patientDetailsList1) {     			    
                         pccpatientInfo.put(patient.getPatientId(), patient);
                         
                         }
     			    
     			    for(PatientDetails dbPatient : patientlist) {
                         updatedPatient = pccpatientInfo.get(dbPatient.getPatientId());
                         if(updatedPatient == null){
                                patientsInactive = updateInactivePatient(dbPatient);
                                patientDetailsList.add(patientsInactive);
                         }      
                         }
     			    
     			    for(PatientDetails patient : patientlist) {
     					patientInfo.put(patient.getPatientId(), patient);
     				}
                     
                     for(PatientDetails pccpatientdetails : patientDetailsList1){
         				
         				updatePatient = patientInfo.get(pccpatientdetails.getPatientId());
         				if(updatePatient != null){
     						updatePatients = updatePatientDetails(updatePatient,pccpatientdetails);
     						patientDetailsList.add(updatePatients);
     					}else {
     						createPatients = createPatientDetails(pccpatientdetails);
     						patientDetailsList.add(createPatients);
     					}
         			}
                     logger.info("End of GetPatient method");       
                     patientsDAO.patientDetails(patientDetailsList);
                     System.out.println("patients updated successfully");
                 } finally {
                     if (bufferedReader != null) {
                         bufferedReader.close();
                     }
                 }
             }
         } catch (Exception e) {
         	InputStream errorstream = connection.getErrorStream();
         	if(errorstream != null)
         	{
         	BufferedReader br = null;
         	System.out.println("Comes to errorstream while try to get token");
             br = new BufferedReader(new InputStreamReader(errorstream));
             String response1 = "";
             String nachricht;
             while ((nachricht = br.readLine()) != null){
                 response1 += nachricht;
             }
             JsonParser jsonParserError = new JsonParser();
             String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
             Gson gsonError = new Gson();
             patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
             String errDetail = null;
             for(Errors errors : patientsResponseError.getErrors()){
             	System.out.println("response1" + errors.getTitle());
             	System.out.println("response2" + errors.getDetail());
             	logger.error(errors.getDetail());
             	errDetail = errors.getDetail();
             	break;
             }
         	}
             
             e.printStackTrace();
         } finally {
             if (connection != null) {
                 connection.disconnect();
             }
         }
         	Paging paging = patients.getPaging();
         	page = paging.getPage();
              has = paging.getHasMore();
             System.out.println("hasmore flag" + has);
             logger.info("hasmore flag" + has);
//             }
             } while (has.equals("true")); 	
             	
     		} 
             
        }     
		       
        else {
      			logger.error("Referesh token Expired");
      		}
             
        
        
        }  
      
        

		
    
	return  patients;
	}

	private PatientDetails addPatientDetails(Data data1) {
		// TODO Auto-generated method stub
		dataKey = CommonUtil.getInstance().getDataKey();
		PatientDetails patientdetails = new PatientDetails();
//		patientdetails.setPatientId(data1.getPatientId() != null && data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
		patientdetails.setPatientId(data1.getPatientId() != null && !data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
		if(data1.getPatientStatus().equals("Current") && data1.getOutpatient().equals("false"))
		{
			patientdetails.setPatientStatus("ACTIVE");
			patientdetails.setOutpatient("false");
		}
		else
		{
			patientdetails.setPatientStatus("INACTIVE");
			patientdetails.setOutpatient("true");
		}
		 // Else part meant for making patients
		patientdetails.setClientId(data1.getOrgId() != null && !data1.getOrgId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getOrgId(), dataKey) : null);
		patientdetails.setAdministrativeSex(data1.getGender());
		patientdetails.setAssignedPatientLocationBed(data1.getBedId());
		patientdetails.setAdmitDateOrTime(data1.getAdmissionDate());
		patientdetails.setGivenName(data1.getFirstName() != null && !data1.getFirstName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getFirstName(), dataKey) : null);
//		patientdetails.setGivenName(data1.getFirstName());
		patientdetails.setFamilyName(data1.getLastName() != null && !data1.getLastName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getLastName(), dataKey) : null);
//		patientdetails.setFamilyName(data1.getLastName());
		patientdetails.setSendingFacility(data1.getFacId()+"."+data1.getOrgId());
		if(data1.getBirthDate() != null)
		{
		String dob = data1.getBirthDate().replaceAll("[^0-9\\+]", "");
		patientdetails.setDob(dob != null && !dob.trim().isEmpty() ? BouncyCastleEngine.AESEncryption(dob, dataKey) : null);
		}
		//patientdetails.setOutpatient(data1.getOutpatient());
		patientdetails.setSendingApplication("PCCApp");
		patientdetails.setBedStatus(data1.getBedDesc());
		patientdetails.setAssignedPatientLocationRoom(data1.getRoomDesc());
		patientdetails.setAssignedPatientLocationFloor(data1.getFloorId());
		patientdetails.setPatientSSNNumber(data1.getMedicalRecordNumber());
		patientdetails.setReceivingApplication("NR");
		patientdetails.setReceivingFacility("NURSEROSIE_ADT");
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		patientdetails.setLastModifiedOn(timeStamp);
		
		return patientdetails;
	}
	
	private PatientDetails createPatientDetails(PatientDetails pccpatientdetails){
		dataKey = CommonUtil.getInstance().getDataKey();
		try {
		
		    PatientDetails addPatient = new PatientDetails();
		     
		    if(pccpatientdetails.getPatientId() != null && !pccpatientdetails.getPatientId().equals("")) {
//		    	addPatient.setPatientId(data1.getPatientId() != null && data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
		    	addPatient.setPatientId(pccpatientdetails.getPatientId());
			}
		    if(pccpatientdetails.getPatientStatus() != null && !pccpatientdetails.getPatientStatus().equals(""))
		    {
		    	addPatient.setPatientStatus(pccpatientdetails.getPatientStatus());
		    }
		    if(pccpatientdetails.getOutpatient() != null && !pccpatientdetails.getOutpatient().equals(""))
		    {
		    	addPatient.setOutpatient(pccpatientdetails.getOutpatient());
		    }
//		    if(pccpatientdetails.getPatientStatus().equals("Current"))
//			{
//		    	addPatient.setPatientStatus("ACTIVE");
//			}
//			else
//			{
//				addPatient.setPatientStatus("INACTIVE");
//			}
		    if(pccpatientdetails.getClientId() != null && !pccpatientdetails.getClientId().equals("")) {
		    	addPatient.setClientId(pccpatientdetails.getClientId());
			}
		    if(pccpatientdetails.getAdministrativeSex() != null && !pccpatientdetails.getAdministrativeSex().equals("")) {
		    	addPatient.setAdministrativeSex(pccpatientdetails.getAdministrativeSex());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationBed() != null && !pccpatientdetails.getAssignedPatientLocationBed().equals("")) {
		    	addPatient.setBedStatus(pccpatientdetails.getAssignedPatientLocationBed());
		    }
		    if(pccpatientdetails.getAdmitDateOrTime() != null && !pccpatientdetails.getAdmitDateOrTime().equals("")) {
		    	addPatient.setAdmitDateOrTime(pccpatientdetails.getAdmitDateOrTime());
		    }
		    if(pccpatientdetails.getGivenName() != null && !pccpatientdetails.getGivenName().equals("")) {
//		    	addPatient.setGivenName(data1.getFirstName() != null && data1.getFirstName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getFirstName(), dataKey) : null);
		    	addPatient.setGivenName(pccpatientdetails.getGivenName());
		    }
		    if(pccpatientdetails.getFamilyName() != null && !pccpatientdetails.getFamilyName().equals("")) {
//		    	addPatient.setFamilyName(data1.getLastName() != null && data1.getLastName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getLastName(), dataKey) : null);
		    	addPatient.setFamilyName(pccpatientdetails.getFamilyName());
		    }
		    if(pccpatientdetails.getSendingFacility() != null && !pccpatientdetails.getSendingFacility().equals("")) {
		    	addPatient.setSendingFacility(pccpatientdetails.getSendingFacility());
		    }
		    if(pccpatientdetails.getDob() != null && !pccpatientdetails.getDob().equals("")) {
		    	addPatient.setDob(pccpatientdetails.getDob());
		    }
		    addPatient.setSendingApplication("PCCApp");
		    if(pccpatientdetails.getBedStatus() != null && !pccpatientdetails.getBedStatus().equals("")) {
		    	addPatient.setAssignedPatientLocationBed(pccpatientdetails.getBedStatus());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationRoom() != null && !pccpatientdetails.getAssignedPatientLocationRoom().equals("")) {
		    	addPatient.setAssignedPatientLocationRoom(pccpatientdetails.getAssignedPatientLocationRoom());
		    }
		    if(pccpatientdetails.getAssignedPatientLocationFloor() != null && !pccpatientdetails.getAssignedPatientLocationFloor().equals("")) {
		    	addPatient.setPriorPatientLocationFloor(pccpatientdetails.getAssignedPatientLocationFloor());
		    }
		    if(pccpatientdetails.getPatientSSNNumber() != null && !pccpatientdetails.getPatientSSNNumber().equals("")) {
		    	addPatient.setPatientSSNNumber(pccpatientdetails.getPatientSSNNumber());
		    }
		    String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		    addPatient.setLastModifiedOn(timeStamp);
		    addPatient.setReceivingApplication("NR");
		    addPatient.setReceivingFacility("NURSEROSIE_ADT");
		
		    return addPatient;
		
		}catch(Exception e){
			System.out.println("e1"+ e.getMessage());
			throw new RuntimeException(e.getMessage(),e);
		}
	}
	
	private PatientDetails updatePatientDetails(PatientDetails updatePatient,PatientDetails pccpatientdetails){
		try {
				
		
		if(pccpatientdetails.getPatientId() != null && !pccpatientdetails.getPatientId().equals("")) {
//	    	addPatient.setPatientId(data1.getPatientId() != null && data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null);
			updatePatient.setPatientId(pccpatientdetails.getPatientId());
		}
		if(pccpatientdetails.getPatientStatus() != null && !pccpatientdetails.getPatientStatus().equals(""))
	    {
			updatePatient.setPatientStatus(pccpatientdetails.getPatientStatus());
	    }
		if(pccpatientdetails.getOutpatient() != null && !pccpatientdetails.getOutpatient().equals(""))
	    {
			updatePatient.setOutpatient(pccpatientdetails.getOutpatient());
	    }
//	    if(pccpatientdetails.getPatientStatus().equals("Current"))
//		{
//	    	updatePatient.setPatientStatus("ACTIVE");
//		}
//		else
//		{
//			updatePatient.setPatientStatus("INACTIVE");
//		}
	    if(pccpatientdetails.getClientId() != null && !pccpatientdetails.getClientId().equals("")) {
	    	updatePatient.setClientId(pccpatientdetails.getClientId());
		}
	    if(pccpatientdetails.getAdministrativeSex() != null && !pccpatientdetails.getAdministrativeSex().equals("")) {
	    	updatePatient.setAdministrativeSex(pccpatientdetails.getAdministrativeSex());
	    }
	    if(pccpatientdetails.getAssignedPatientLocationBed() != null && !pccpatientdetails.getAssignedPatientLocationBed().equals("")) {
	    	updatePatient.setBedStatus(pccpatientdetails.getAssignedPatientLocationBed());
	    }
	    if(pccpatientdetails.getAdmitDateOrTime() != null && !pccpatientdetails.getAdmitDateOrTime().equals("")) {
	    	updatePatient.setAdmitDateOrTime(pccpatientdetails.getAdmitDateOrTime());
	    }
	    if(pccpatientdetails.getGivenName() != null && !pccpatientdetails.getGivenName().equals("")) {
//	    	addPatient.setGivenName(data1.getFirstName() != null && data1.getFirstName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getFirstName(), dataKey) : null);
	    	updatePatient.setGivenName(pccpatientdetails.getGivenName());
	    }
	    if(pccpatientdetails.getFamilyName() != null && !pccpatientdetails.getFamilyName().equals("")) {
//	    	addPatient.setFamilyName(data1.getLastName() != null && data1.getLastName().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getLastName(), dataKey) : null);
	    	updatePatient.setFamilyName(pccpatientdetails.getFamilyName());
	    }
	    if(pccpatientdetails.getSendingFacility() != null && !pccpatientdetails.getSendingFacility().equals("")) {
	    	updatePatient.setSendingFacility(pccpatientdetails.getSendingFacility());
	    }
	    if(pccpatientdetails.getDob() != null && !pccpatientdetails.getDob().equals("")) {
	    	updatePatient.setDob(pccpatientdetails.getDob());
	    }
	    updatePatient.setSendingApplication("PCCApp");
	    if(pccpatientdetails.getBedStatus() != null && !pccpatientdetails.getBedStatus().equals("")) {
	    	updatePatient.setAssignedPatientLocationBed(pccpatientdetails.getBedStatus());
	    }
	    if(pccpatientdetails.getAssignedPatientLocationRoom() != null && !pccpatientdetails.getAssignedPatientLocationRoom().equals("")) {
	    	updatePatient.setAssignedPatientLocationRoom(pccpatientdetails.getAssignedPatientLocationRoom());
	    }
	    if(pccpatientdetails.getAssignedPatientLocationFloor() != null && !pccpatientdetails.getAssignedPatientLocationFloor().equals("")) {
	    	updatePatient.setPriorPatientLocationFloor(pccpatientdetails.getAssignedPatientLocationFloor());
	    }
	    if(pccpatientdetails.getPatientSSNNumber() != null && !pccpatientdetails.getPatientSSNNumber().equals("")) {
	    	updatePatient.setPatientSSNNumber(pccpatientdetails.getPatientSSNNumber());
	    }
	    String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
	    updatePatient.setLastModifiedOn(timeStamp);
	    updatePatient.setReceivingApplication("NR");
	    updatePatient.setReceivingFacility("NURSEROSIE_ADT");
		
//	    if(data1.getPatientId() != null && !data1.getPatientId().equals("")) {
//			updatePatient.setPatientId(data1.getPatientId());
//		}
//		if(data1.getPatientId() != null && !data1.getPatientId().equals("")) {
//			updatePatient.setClientId(data1.getPatientId());
//		}
//		
//		if(data1.getGender() != null && !data1.getGender().equals("")) {
//			updatePatient.setAdministrativeSex(data1.getGender());
//	    }
//	    if(data1.getAdmissionDate() != null && !data1.getAdmissionDate().equals("")) {
//	    	updatePatient.setAdmitDateOrTime(data1.getAdmissionDate());
//	    }
//	    
//	    if(data1.getPatientStatus() != null && !data1.getPatientStatus().equals("")) {
//	    	updatePatient.setPatientStatus(data1.getPatientStatus());
//	    }
	    
	    
		
		return updatePatient;
		
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
	
	public EMROperatorInfo AccessToken(String refereshToken,String refereshTokenExpiresIn) throws MalformedURLException
	{
		EMROperatorInfo emrOperatorInfo = null;
		StringBuilder response = null;
		HttpURLConnection connection = null;
		
		DateFormat converter = null;
        converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
        converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
        long currenttime = Long.parseLong(formatedDate);
        
		System.out.println("Before Calling newAccessToken API time:"+ currenttime );
	// Demo getAccessToken URL :	
	//	final String URLstr = "https://5zexw2gi20.execute-api.us-east-1.amazonaws.com/poc/pcc-developer/get-token?code=&refresh_token="+refereshToken+"";
	// Prod  getAccessToken URL : 	
		String URLstr = "https://pccdeveloperapi.rosieconnect2.com/api/get-token?code=&refresh_token="+refereshToken+"";
		System.out.println("Calling newAccessToken API"+ URLstr );
		System.out.println("After Calling newAccessToken API time:"+ currenttime );
        try {
        final URL url = new URL(URLstr);
    	connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(HttpMethod.GET);
		connection.setDoOutput(true);
//		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
		
		if (connection.getInputStream() != null) {
			logger.info("Comes to InputStream");
            final InputStream inputStream = connection.getInputStream();
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            try {
                response = new StringBuilder();

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }
                JsonParser jsonParser = new JsonParser();
                String jsonObject = jsonParser.parse(response.toString()).toString();
                Gson gson = new Gson();
                emrOperatorInfo = gson.fromJson(jsonObject, EMROperatorInfo.class);
                
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
		}
    } catch (Exception e) {
    	InputStream errorstream = connection.getErrorStream();
    	if(errorstream != null)
    	{
    	BufferedReader br = null;
    	System.out.println("Comes to errorstream while try to get token");
        br = new BufferedReader(new InputStreamReader(errorstream));
        String response1 = "";
        String nachricht;
        try {
			while ((nachricht = br.readLine()) != null){
			    response1 += nachricht;
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        JsonParser jsonParserError = new JsonParser();
        String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
        Gson gsonError = new Gson();
        PatientsError patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
        String errDetail = null;
        for(Errors errors : patientsResponseError.getErrors()){
        	System.out.println("response1" + errors.getTitle());
        	System.out.println("response2" + errors.getDetail());
        	logger.error(errors.getDetail());
        	errDetail = errors.getDetail();
        	break;
        	
        }
    	}
        
        e.printStackTrace();
    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    }
		
		return emrOperatorInfo;
	}
	
	public EMROperatorInfo updateemrInfo(EMROperatorInfo emrinfo,EMROperatorInfo facilityList){
		
		EMROperatorInfo facility = new EMROperatorInfo();
		
		String facility1 = facilityList.getFacility();
		String emroperator1 = facilityList.getEmrOperator();
		PatientsDAO patientDAO = new PatientsDAOImpl();
		EMROperatorInfo emrinf = patientDAO.getEMRInfo(facility1,emroperator1);
		emrinf.setAccessToken(emrinfo.getAccess_token());
		emrinf.setAccexpiresIn(emrinfo.getExpires_in());
		return emrinf;
	}
	
	private PatientDetails updateInactivePatient(PatientDetails dbPatient)
    {
           dbPatient.setPatientStatus("INACTIVE");
           String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
           dbPatient.setLastModifiedOn(timeStamp);
           return dbPatient;
    }
	
}