package com.zsl.cron.dto;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class DateModel {
private long currenttime;

public long getCurrenttime() {
	DateFormat converter = null;
    converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
    converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
    String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
    currenttime = Long.parseLong(formatedDate);
	return currenttime;
}

/*public void setCurrenttime(long currenttime) {
	DateFormat converter = null;
    converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
    converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
    String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
    currenttime = Long.parseLong(formatedDate);
    	this.currenttime = currenttime;
}*/
}
