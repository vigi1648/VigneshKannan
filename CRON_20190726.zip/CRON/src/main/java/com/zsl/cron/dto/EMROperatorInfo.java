package com.zsl.cron.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="EMROPERATOR_INFO")
public class EMROperatorInfo {
@DynamoDBHashKey(attributeName="FACILITY")	
private String facility;
@DynamoDBRangeKey(attributeName="EMROPERATOR")
private String emrOperator;
@DynamoDBAttribute(attributeName="CREATEDON")
private String createdOn;
@DynamoDBAttribute(attributeName="ORGIN")
private String origin;
@DynamoDBAttribute(attributeName="PASSWORD")
private String password;
@DynamoDBAttribute(attributeName="USERNAME")
private String userName;
@DynamoDBAttribute(attributeName="VENDORCODE")
private String vendorCode;
@DynamoDBAttribute(attributeName="CUSTOMER")
private String customer;
@DynamoDBAttribute(attributeName="FACILITYSTATUS")
private String facilityStatus;
@DynamoDBAttribute(attributeName="LASTUPDATEDPATIENT")
private String lastUpdatedPatient;
@DynamoDBAttribute(attributeName = "ORGID")
private String orgId;
@DynamoDBAttribute(attributeName = "ORGUUID")
private String orgUuid;

/*@DynamoDBHashKey(attributeName = "ORGID")
private String orgId;*/
@DynamoDBAttribute(attributeName = "ACCESSTOKEN")
private String accessToken;
@DynamoDBAttribute(attributeName = "REFRESHTOKEN")
private String refreshToken;
@DynamoDBAttribute(attributeName = "ACCEXPIRESIN")
private String accexpiresIn;
@DynamoDBAttribute(attributeName = "REFEXPIRESIN")
private String refexpiresIn;
@DynamoDBAttribute(attributeName = "ISUPDATEDACCESSTOKEN")
private String isupdatedaccessToken;
private String access_token;
private String expires_in;
private String refresh_expires_in;

public String getFacility() {
	return facility;
}
public void setFacility(String facility) {
	this.facility = facility;
}
public String getEmrOperator() {
	return emrOperator;
}
public void setEmrOperator(String emrOperator) {
	this.emrOperator = emrOperator;
}
public String getCreatedOn() {
	return createdOn;
}
public void setCreatedOn(String createdOn) {
	this.createdOn = createdOn;
}
public String getOrigin() {
	return origin;
}
public void setOrigin(String origin) {
	this.origin = origin;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getVendorCode() {
	return vendorCode;
}
public void setVendorCode(String vendorCode) {
	this.vendorCode = vendorCode;
}
public String getCustomer() {
	return customer;
}
public void setCustomer(String customer) {
	this.customer = customer;
}
public String getFacilityStatus() {
	return facilityStatus;
}
public void setFacilityStatus(String facilityStatus) {
	this.facilityStatus = facilityStatus;
}
public String getLastUpdatedPatient() {
	return lastUpdatedPatient;
}
public void setLastUpdatedPatient(String lastUpdatedPatient) {
	this.lastUpdatedPatient = lastUpdatedPatient;
}
public String getOrgId() {
	return orgId;
}
public void setOrgId(String orgId) {
	this.orgId = orgId;
}
public String getAccessToken() {
	return accessToken;
}
public void setAccessToken(String accessToken) {
	this.accessToken = accessToken;
}
public String getRefreshToken() {
	return refreshToken;
}
public void setRefreshToken(String refreshToken) {
	this.refreshToken = refreshToken;
}
public String getAccexpiresIn() {
	return accexpiresIn;
}
public void setAccexpiresIn(String accexpiresIn) {
	this.accexpiresIn = accexpiresIn;
}
public String getRefexpiresIn() {
	return refexpiresIn;
}
public void setRefexpiresIn(String refexpiresIn) {
	this.refexpiresIn = refexpiresIn;
}
public String getIsupdatedaccessToken() {
	return isupdatedaccessToken;
}
public void setIsupdatedaccessToken(String isupdatedaccessToken) {
	this.isupdatedaccessToken = isupdatedaccessToken;
}
public String getAccess_token() {
	return access_token;
}
public void setAccess_token(String access_token) {
	this.access_token = access_token;
}
public String getExpires_in() {
	return expires_in;
}
public void setExpires_in(String expires_in) {
	this.expires_in = expires_in;
}
public String getRefresh_expires_in() {
	return refresh_expires_in;
}
public void setRefresh_expires_in(String refresh_expires_in) {
	this.refresh_expires_in = refresh_expires_in;
}

public String getOrgUuid() {
	return orgUuid;
}
public void setOrgUuid(String orgUuid) {
	this.orgUuid = orgUuid;
}

}
