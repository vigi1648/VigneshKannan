package com.zsl.applewatch.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.zsl.applewatch.dto.FitnessData;

public interface FitnessDataService {

	public String updateFitnessData(List<Object> fitnessDataList) ;

	//public void fitnessData(List<Object> fitnessDataList); 
}
