package com.zsl.applewatch.dto;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
@DynamoDBTable(tableName="SAMPLE")
public class CalorieBurn  {
@DynamoDBAttribute(attributeName="CALORIESBURNED")
private List<CalorieBurn> caloriesBurned;
@DynamoDBAttribute(attributeName="CALORIESTIME")
private List<CalorieBurn> caloriesTime;

public List<CalorieBurn> getCaloriesTime() {
	return caloriesTime;
}

public void setCaloriesTime(List<CalorieBurn> caloriesTime) {
	this.caloriesTime = caloriesTime;
}

public List<CalorieBurn> getCaloriesBurned() {
	return caloriesBurned;
}

public void setCaloriesBurned(List<CalorieBurn> caloriesBurned) {
	this.caloriesBurned = caloriesBurned;
}
}
