package com.zsl.applewatch.util;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;

public class AWSAuthenticationUtil {

	public static AWSCredentials getAWSCredentials(){
        AWSCredentials awsCredentials = null;
        try {
               awsCredentials = new BasicAWSCredentials("AKIAI2RPUWWJPV7WKI3Q", "4MYpKmViMaRcvvFy2OIvzt7Hj+9ktBfqFdFV3ljv");
        } catch (Exception e) {
              
        }

 return awsCredentials;
 }
}
