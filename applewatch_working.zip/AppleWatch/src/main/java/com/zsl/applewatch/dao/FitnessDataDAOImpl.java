package com.zsl.applewatch.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/*import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;*/

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;
//import com.amazonaws.services.opsworks.model.UserProfile;
import com.zsl.applewatch.dao.FitnessDataDAO;
import com.zsl.applewatch.dto.FitnessData;
import com.zsl.applewatch.util.AWSAuthenticationUtil;
import com.zsl.applewatch.util.DynamoDBUtil;

public class FitnessDataDAOImpl implements FitnessDataDAO {

	static final Logger logger = LogManager.getLogger(FitnessDataDAOImpl.class);
	
	AWSCredentials awsCredentials = null;
	AmazonDynamoDBClient amazonDynamoDBClient = null;
	DynamoDB dynamoDB = null;
	/*
	 * This method is used to connect Dynamo DB and save the batch of patient vital stats
	 * @Param vitalStatList, which comes from Android device
	 * @return object, whether return success or fail*/
	@Override
	public String updateFitnessData(List<FitnessData> fitnessDataList) {
		String result = "success";
		try {
			AWSCredentials awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			AmazonDynamoDBClient amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper dynamoDBMapper =  DynamoDBUtil.getDynamoDBMapper(amazonDynamoDBClient);
			List<FailedBatch> failedBatchList = dynamoDBMapper.batchSave(fitnessDataList);
			
			if(failedBatchList.size() > 0){
			result = "error";
				
				for(FailedBatch failedBatch : failedBatchList) {
				logger.error("[ERROR] "+"FAILED TO UPDATE FITNESS DATA "+failedBatch.getException());
				Map<String, List<WriteRequest>> items = failedBatch.getUnprocessedItems();
				
				for(Map.Entry<String,List<WriteRequest>> entry : items.entrySet()){
					String tableName = entry.getKey();
					for(WriteRequest writeRequest : entry.getValue()){
						logger.error("[ERROR] "+"TABLENAME "+tableName+" ITEM "+writeRequest.getPutRequest().getItem());
					}
				}
				
				}
			}
			
		}catch(AmazonServiceException ase) {
			logger.error(ase.getMessage(), ase);
			result = "error";
		}catch(AmazonClientException ace){
			logger.error(ace.getMessage(), ace);
			result = "error";
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			result = "error";
		}
		return result;
	}
	
	

/*	public void updateFitnessData(List<FitnessData> fitnessInfo) {
		try {
			awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper dynamoDBMapper =  DynamoDBUtil.getDynamoDBMapper(amazonDynamoDBClient);
			dynamoDBMapper.save(fitnessInfo);
			//List<FailedBatch> failedBatchList = dynamoDBMapper.batchSave(fitnessInfo);
		} catch (Exception e){
			throw new RuntimeException(e.getMessage());
		} finally {
			amazonDynamoDBClient = null;
			awsCredentials = null;
		}
		
	}*/

	
			public void saveFitnessData(List<FitnessData> fitness){
		try {
			awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			
			DynamoDBMapper mapper = new DynamoDBMapper(amazonDynamoDBClient);
			mapper.batchSave(fitness);
			
				

			} catch (AmazonServiceException ase) {
				throw new RuntimeException("Internal Server Error",ase);
			} catch (AmazonClientException ace){
				throw new RuntimeException("Internal Server Error",ace);
			} catch (Exception e){
				throw new RuntimeException(e.getMessage(),e);
			} finally {
				amazonDynamoDBClient = null;
				awsCredentials = null;
			}
	}
			
		

	
	public String  dateConversion(String dateTimeObservation){
		 //String dateDb = "20170113074029.354";
	     SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddhhmmss.SSS");
	     Date date = null;
		try {
			date = simpleDateFormat.parse(dateTimeObservation);
			//date = simpleDateFormat.parse(dateDb);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	     
	     SimpleDateFormat newSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
	     String dateNew = newSimpleDateFormat.format(date);
	     return dateNew;
	}
	
}
