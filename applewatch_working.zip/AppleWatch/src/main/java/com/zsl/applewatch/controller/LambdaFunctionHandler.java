package com.zsl.applewatch.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.applewatch.dto.FitnessData;
import com.zsl.applewatch.service.FitnessDataService;
import com.zsl.applewatch.service.FitnessDataServiceImpl;
import com.zsl.applewatch.controller.LambdaFunctionHandler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {

	static final Logger logger = LogManager.getLogger(LambdaFunctionHandler.class);
	Map<String, String> result = new LinkedHashMap<>();
    @Override
    public Object handleRequest(Object input, Context context) {
        
    	logger.info("[INFO] FITNESS DATA RECEIVED SUCCESSFULLY FROM APPLEWATCH");
    	Map<String, List<Object>> fitnessDataObject = (Map<String, List<Object>>)input;
         List<Object> fitnessDataList = fitnessDataObject.get("fitnessData");
         
         FitnessDataService fitnessDataService = new FitnessDataServiceImpl();
    
          String status=fitnessDataService.updateFitnessData(fitnessDataList);
         if(status.equals("success")){
        	 logger.info("[INFO] FITNESS DATA UPDATED SUCCESSFULLY TO DYNAMO DB");
        	 result.put("Message", "FITNESS DATA Updated Successfully");
         }else if(status.equals("error")){
        	 logger.error("[ERROR] ERROR OCCURED IN FITNESS DATA UPDATE TO DYNAMO DB");
        	 throw new RuntimeException("error");
          }
     
         
        return status;
    }
    public static void main(String[] args){
    	try {
    		
    		FitnessDataService fitnessDataService = new FitnessDataServiceImpl();
    	Map<String, List<Object>> fitnessDataObject = new LinkedHashMap<String, List<Object>>();
        List<Object> fitnessDataList = new LinkedList<Object>();
        Map<String,String> fitnessobj = new LinkedHashMap<String,String>();
        fitnessobj.put("givenName", "Vignesh");
        fitnessobj.put("nrPatientId", "c05857f6-9c7f-4501-9892-c38ce4c169b4");
        fitnessobj.put("dateTimeOfObservation", "20180809031100.057");
      //  vitalobj.put("observationSiteIdentifier", "BARRELCHEST");
        //fitnessobj.put("measurementText", "TEMPERATURE");
        //fitnessobj.put("measurementIdentifier", "8310-5");
        //fitnessobj.put("observationValue", "98.6");
        //fitnessobj.put("unitsIdentifier", "FAHRENHEIT");
        //fitnessobj.put("unitsIdentifierText", "FAHRENHEIT");
        //fitnessobj.put("observationMethodIdentifier_0", "ORAL");
      //  vitalobj.put("observationMethodIdentifier_1", "CHEYNE_STOKES");
      // vitalobj.put("isHL7Created", "NO");
        //fitnessobj.put("customer", "ZSL");
        //fitnessobj.put("facility", "6824");
       // vitalobj.put("facility", "6824");
        //fitnessobj.put("emrOperator", "MATRIXCARE");
       // vitalobj.put("facility", "TESTFACILITY");
       // vitalobj.put("emrOperator", "PCCApp");
        //fitnessobj.put("userId", "55e7143e-d7e4-4f9f-9741-d14db85f6890");
        //fitnessobj.put("deviceId", "adr-876e5ac39198a21c");
        //fitnessobj.put("macId", "00:E0:C9:F2:A3:7E");
       
        
        
        fitnessDataList.add(fitnessobj);

       String status=fitnessDataService.updateFitnessData(fitnessDataList);
        System.out.println(status);    
    	}catch(Exception e){
    		throw new RuntimeException(e.getMessage(),e);
    	}
    
    }
    }
    
    


