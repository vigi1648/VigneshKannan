package com.zsl.pccimages.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "PCCDEVELOPER")
public class LoginInfo {

	@DynamoDBHashKey(attributeName = "ORGID")
	private String orgId;
	@DynamoDBAttribute(attributeName = "ACCESSTOKEN")
	private String accessToken;
	@DynamoDBAttribute(attributeName = "REFRESHTOKEN")
	private String refreshToken;
	@DynamoDBAttribute(attributeName = "EXPIRESIN")
	private String expiresIn;
	@DynamoDBAttribute(attributeName = "FACILITYID")
	private String facilityId;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(String expiresIn) {
		this.expiresIn = expiresIn;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

}
