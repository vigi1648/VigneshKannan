package com.zsl.lgcns.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.zsl.lgcns.dto.PatientInfo;
import com.zsl.lgcns.dto.Patients;

public interface PatientsService {

	public Object getPatients(Map<String, String> userInfo) throws IOException;
	
}
