package com.zsl.lgcns.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.zsl.lgcns.dao.PatientsDAO;
import com.zsl.lgcns.dao.PatientsDAOImpl;
import com.zsl.lgcns.dto.PatientInfo;
import com.zsl.lgcns.dto.Patients;
import com.zsl.lgcns.dao.PatientsDAO;
import com.zsl.lgcns.dao.PatientsDAOImpl;
import com.zsl.lgcns.dto.Patients;


public class PatientsServiceImpl implements PatientsService {
	
	Logger log = Logger.getLogger(PatientsServiceImpl.class);

//	@SuppressWarnings("unchecked")
	@Override
	public Object getPatients(Map<String, String> userInfo) throws IOException {
		
		log.info("Entered into getPatient service");
		
		PatientsDAO patientsDAO = new PatientsDAOImpl();
		Patients patients = new Patients(); 
		List<PatientInfo> patientlist = null;
		Map<String, PatientInfo> patientInfo = null;
		patientInfo = new HashMap<String, PatientInfo>();
		String sendingApplication = userInfo.get("sendingApplication");
		String sendingFacility = userInfo.get("sendingFacility");

        patientlist = patientsDAO.getPatients(sendingApplication,sendingFacility);
	    System.out.println("patient list DB"+ patientlist);
			    

    
	return patientlist;
		}
}
				


			
