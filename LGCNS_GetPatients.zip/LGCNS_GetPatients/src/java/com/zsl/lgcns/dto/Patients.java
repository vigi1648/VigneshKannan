package com.zsl.lgcns.dto;

import java.util.List;

import com.zsl.lgcns.dto.PatientInfo;

public class Patients
{
	
	public String LASTKEY;
	public List<PatientInfo> PATIENTLIST;
	
	public String getLASTKEY() {
		return LASTKEY;
	}
	public void setLASTKEY(String lASTKEY) {
		this.LASTKEY = lASTKEY;
	}
	public List<PatientInfo> getPATIENTLIST() {
		return PATIENTLIST;
	}
	public void setPATIENTLIST(List<PatientInfo> patientList) {
		this.PATIENTLIST = patientList;
	}
}