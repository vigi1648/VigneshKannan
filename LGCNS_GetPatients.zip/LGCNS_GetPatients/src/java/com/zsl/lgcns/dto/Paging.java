package com.zsl.lgcns.dto;

public class Paging
{
    private String hasMore;

    private String page;

    private String pageSize;

    public String getHasMore ()
    {
        return hasMore;
    }

    public void setHasMore (String hasMore)
    {
        this.hasMore = hasMore;
    }

    public String getPage ()
    {
        return page;
    }

    public void setPage (String page)
    {
        this.page = page;
    }

    public String getPageSize ()
    {
        return pageSize;
    }

    public void setPageSize (String pageSize)
    {
        this.pageSize = pageSize;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [hasMore = "+hasMore+", page = "+page+", pageSize = "+pageSize+"]";
    }
}