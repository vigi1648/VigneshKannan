package com.zsl.lgcns.dto;

public class Organization {
	public String OrgCode;
	public String FacilityCode;
	public String getOrgCode() {
		return OrgCode;
	}
	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	public String getFacilityCode() {
		return FacilityCode;
	}
	public void setFacilityCode(String facilityCode) {
		FacilityCode = facilityCode;
	}
	

}
