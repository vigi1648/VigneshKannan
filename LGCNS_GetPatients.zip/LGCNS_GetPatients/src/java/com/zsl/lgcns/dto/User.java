package com.zsl.lgcns.dto;

public class User {
	public String UserID;
	public String PasswordDigest;
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getPasswordDigest() {
		return PasswordDigest;
	}
	public void setPasswordDigest(String passwordDigest) {
		PasswordDigest = passwordDigest;
	}
	
	
}
