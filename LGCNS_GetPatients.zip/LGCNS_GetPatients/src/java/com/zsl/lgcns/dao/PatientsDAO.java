package com.zsl.lgcns.dao;

import java.util.List;


import com.zsl.lgcns.dto.PatientInfo;

public interface PatientsDAO {

	public List<PatientInfo> getPatients(String facility, String sendingApplication);
	
}
