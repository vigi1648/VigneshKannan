package com.zsl.lgcns.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.zsl.lgcns.dto.PatientInfo;
import com.zsl.lgcns.dto.Patients;
import com.zsl.lgcns.util.AWSAuthenticationUtil;
import com.zsl.lgcns.util.DynamoDBUtil;


public class PatientsDAOImpl implements PatientsDAO {
	
	Logger log = Logger.getLogger(PatientsDAOImpl.class);

	AWSCredentials awsCredentials = null;
	AmazonDynamoDBClient amazonDynamoDBClient = null;
	DynamoDB dynamoDB = null;
	
	@Override
	public List<PatientInfo> getPatients(String sendingApplication, String sendingFacility) {
		// TODO Auto-generated method stub
			try {
				System.out.println("get patients DB");
				awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
				amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
				
				DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(amazonDynamoDBClient);
			
				Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
				attributeValues.put(":v1", new AttributeValue().withS(sendingFacility));
				attributeValues.put(":v2", new AttributeValue().withS(sendingApplication));
				
				
				DynamoDBQueryExpression<PatientInfo> queryExpression = new DynamoDBQueryExpression<PatientInfo>()
						   .withIndexName("SENDINGFACILITY-SENDINGAPPLICATION-index")
	 	                   .withConsistentRead(false)
			               .withKeyConditionExpression("SENDINGFACILITY = :v1 and SENDINGAPPLICATION = :v2")
			               .withExpressionAttributeValues(attributeValues);
		           
		           
		        List<PatientInfo> patientList =  dynamoDBMapper.query(PatientInfo.class, queryExpression);
		          
		        return patientList;
		           
			} catch (AmazonServiceException ase) {
				throw new RuntimeException("Internal Server Error");
			} catch (AmazonClientException ace){
				throw new RuntimeException("Internal Server Error");
			} catch (Exception e){
				throw new RuntimeException(e.getMessage());
			} finally {
				amazonDynamoDBClient = null;
				awsCredentials = null;
			}
			
		}
	
	
}

	

	

	

