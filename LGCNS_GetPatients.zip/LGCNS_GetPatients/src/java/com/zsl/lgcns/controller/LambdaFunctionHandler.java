package com.zsl.lgcns.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

//import com.adtservice.ADTService;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.lgcns.dto.PatientInfo;
import com.zsl.lgcns.service.PatientsService;
import com.zsl.lgcns.service.PatientsServiceImpl;
import com.zsl.lgcns.dto.Patients;
import com.zsl.lgcns.service.PatientsService;
import com.zsl.lgcns.service.PatientsServiceImpl;
import com.zsl.lgcns.dto.Patients;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {

    @Override
    public Object handleRequest(Object input, Context context) {
    	
    	System.out.println("Handler mathod");
        
    	PatientsService patientsService = new PatientsServiceImpl();
    	Map<String, String> userInfo =  (LinkedHashMap<String, String>)input;
    	String sendingApplication = userInfo.get("sendingApplication");
        String sendingFacility = userInfo.get("sendingFacility");
    	//userInfo.put("emrOperator", "PCCApp");
    	
    	try {
			return patientsService.getPatients(userInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userInfo;
    }
    
    
    public static void main(String [] args) throws Exception{
    	
    	System.out.println("Main mathod");
    	
    
    	PatientsService patientsService = new PatientsServiceImpl();
    	
    	Map<String, String> userInfo = new LinkedHashMap<String, String>();
    	userInfo.put("sendingApplication", "PCCApp");
    	userInfo.put("sendingFacility", "11");
    	patientsService.getPatients(userInfo);
    
    }

    }



