package com.zsl.nrchecklogin.dto;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="MDIAchieveAPIRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class MDIAchieveAPIRequest {
	
	@XmlElement(name="RequestData")
	private RequestData RequestData;
	private String Version;

    public RequestData getRequestData ()
    {
        return RequestData;
    }

    public void setRequestData (RequestData RequestData)
    {
        this.RequestData = RequestData;
    }
    
    public String getVersion() {
		return Version;
	}

	public void setVersion(String version) {
		Version = version;
	}

	@Override
    public String toString()
    {
        return "ClassPojo [RequestData = "+RequestData+"]";
    }
}
