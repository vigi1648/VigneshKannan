package com.zsl.nrchecklogin.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ServiceResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceResult
{
    private int TransactionId;

    private UserData UserData;

    private String MessageTxt;

    private String FacilityOID;

    public int getTransactionId ()
    {
        return TransactionId;
    }

    public void setTransactionId (int TransactionId)
    {
        this.TransactionId = TransactionId;
    }

    public UserData getUserData ()
    {
        return UserData;
    }

    public void setUserData (UserData UserData)
    {
        this.UserData = UserData;
    }

    public String getMessageTxt ()
    {
        return MessageTxt;
    }

    public void setMessageTxt (String MessageTxt)
    {
        this.MessageTxt = MessageTxt;
    }

    public String getFacilityOID ()
    {
        return FacilityOID;
    }

    public void setFacilityOID (String FacilityOID)
    {
        this.FacilityOID = FacilityOID;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [TransactionId = "+TransactionId+", UserData = "+UserData+", MessageTxt = "+MessageTxt+", FacilityOID = "+FacilityOID+"]";
    }
}
