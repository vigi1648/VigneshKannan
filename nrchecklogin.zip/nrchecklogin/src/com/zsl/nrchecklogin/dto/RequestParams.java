package com.zsl.nrchecklogin.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class RequestParams
{
    private UserData UserData;

    private String FacilityOID;

    public UserData getUserData ()
    {
        return UserData;
    }

    public void setUserData (UserData UserData)
    {
        this.UserData = UserData;
    }

    public String getFacilityOID ()
    {
        return FacilityOID;
    }

    public void setFacilityOID (String FacilityOID)
    {
        this.FacilityOID = FacilityOID;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [UserData = "+UserData+", FacilityOID = "+FacilityOID+"]";
    }
}