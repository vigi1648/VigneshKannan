
package com.zsl.nrchecklogin.dto;

import java.io.UnsupportedEncodingException;

import org.bouncycastle.crypto.CryptoException;

import com.zsl.nrchecklogin.util.BouncyCastleEngine;
import com.zsl.nrchecklogin.util.CommonUtil;

public class UserInfo {

	private String userId;
	private String emailId;
	private String userRole;
	private String userName;
	private String password;
	private String familyName;
	private String givenName;
	private String customer;
	private String facility;
	private String groupId;
	private String alertRole;
	private String emrOperator;
	private String userStatus;
	private Boolean alertFlag;
	private String encryptionKey;
	private String groupName;
	private Boolean openAlert;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		String dataKey = null;
		String decryptedValue = null;
		try {
			dataKey = CommonUtil.getInstance().getDataKey();
			decryptedValue = BouncyCastleEngine.AESDecryption(password, dataKey);
			this.password = decryptedValue;
		} catch (UnsupportedEncodingException usee) {
			throw new RuntimeException(usee.getMessage(), usee);
		} catch (CryptoException ce){
			throw new RuntimeException(ce.getMessage(), ce);
		}
		finally {
			decryptedValue = null;
			dataKey = null;
		}
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getFacility() {
		return facility;
	}
	public void setFacility(String facility) {
		this.facility = facility;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getAlertRole() {
		return alertRole;
	}
	public void setAlertRole(String alertRole) {
		this.alertRole = alertRole;
	}
	
	public String getEmrOperator() {
		return emrOperator;
	}
	public void setEmrOperator(String emrOperator) {
		this.emrOperator = emrOperator;
	}
	public Boolean getAlertFlag() {
		return alertFlag;
	}
	public void setAlertFlag(Boolean alertFlag) {
		this.alertFlag = alertFlag;
	}
	public String getEncryptionKey() {
		return encryptionKey;
	}
	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	public String getGivenName() {
		return givenName;
	}
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(AlertAuthorityGroup alertGroup) {
		this.groupName = alertGroup.getGroupName();
	}
	
	public Boolean getOpenAlert() {
		return openAlert;
	}
	public void setOpenAlert(AlertInfo alertInfo) {
		this.openAlert = alertInfo.getOpenAlert();
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
}
