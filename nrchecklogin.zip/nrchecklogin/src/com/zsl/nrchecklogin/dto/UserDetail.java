package com.zsl.nrchecklogin.dto;

import java.io.UnsupportedEncodingException;

import org.bouncycastle.crypto.CryptoException;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.zsl.nrchecklogin.util.BouncyCastleEngine;
import com.zsl.nrchecklogin.util.CommonUtil;

@DynamoDBTable(tableName="USERS_PROFILE")
public class UserDetail {

	@DynamoDBHashKey(attributeName="USERID")
	private String userId;
	@DynamoDBAttribute(attributeName="GIVENNAME")
	private String givenName;
	@DynamoDBAttribute(attributeName="FAMILYNAME")
	private String familyName;
	@DynamoDBAttribute(attributeName="MOBILE")
	private String mobile;
	@DynamoDBAttribute(attributeName="EMAIL")
	private String emailId;
	@DynamoDBAttribute(attributeName="GENDER")
	private String gender;
	@DynamoDBAttribute(attributeName="CUSTOMER")
	private String customer;
	@DynamoDBAttribute(attributeName="FACILITY")
	private String facility;
	@DynamoDBAttribute(attributeName="USERROLE")
	private String userRole;
	@DynamoDBAttribute(attributeName="EMROPERATOR")
	private String emrOperator;
	@DynamoDBAttribute(attributeName="USERSTATUS")
	private String userStatus;
	@DynamoDBAttribute(attributeName="USERNAME")
	private String userName;
	@DynamoDBAttribute(attributeName="PASSWORD")
	private String password;
	@DynamoDBAttribute(attributeName="GROUPID")
	private String groupId;
	@DynamoDBAttribute(attributeName="ALERTROLE")
	private String alertRole;
	private Boolean alertFlag;
	private String encryptionKey;
	private String groupName;
	private Boolean openAlert;


	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getGivenName() {
		return givenName;
	}
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getFacility() {
		return facility;
	}
	public void setFacility(String facility) {
		this.facility = facility;
	}

	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getEmrOperator() {
		return emrOperator;
	}
	public void setEmrOperator(String emrOperator) {
		this.emrOperator = emrOperator;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		String dataKey = null;
		String encryptedValue = null;
		try {
			dataKey = CommonUtil.getInstance().getDataKey();
			encryptedValue = BouncyCastleEngine.AESEncryption(password, dataKey);
			this.password = encryptedValue;
		} catch (UnsupportedEncodingException usee) {
			throw new RuntimeException(usee.getMessage(), usee);
		} catch (CryptoException ce){
			throw new RuntimeException(ce.getMessage(), ce);
		}
		finally {
			encryptedValue = null;
			dataKey = null;
		}
	}

	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getAlertRole() {
		return alertRole;
	}
	public void setAlertRole(String alertRole) {
		this.alertRole = alertRole;
	}
	public Boolean getAlertFlag() {
		return alertFlag;
	}
	public void setAlertFlag(Boolean alertFlag) {
		this.alertFlag = alertFlag;
	}
	public String getEncryptionKey() {
		return encryptionKey;
	}
	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Boolean getOpenAlert() {
		return openAlert;
	}
	public void setOpenAlert(Boolean openAlert) {
		this.openAlert = openAlert;
	}


	}
