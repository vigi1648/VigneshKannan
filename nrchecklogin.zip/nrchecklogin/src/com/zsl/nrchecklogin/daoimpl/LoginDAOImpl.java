package com.zsl.nrchecklogin.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.InternalServerErrorException;
import com.amazonaws.services.dynamodbv2.model.ItemCollectionSizeLimitExceededException;
import com.amazonaws.services.dynamodbv2.model.LimitExceededException;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughputExceededException;
import com.amazonaws.services.dynamodbv2.model.ResourceInUseException;
import com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException;
import com.zsl.nrchecklogin.dao.LoginDAO;
import com.zsl.nrchecklogin.dto.AlertAuthorityGroup;
import com.zsl.nrchecklogin.dto.AlertInfo;
import com.zsl.nrchecklogin.dto.UserInfo;
import com.zsl.nrchecklogin.dto.UsersProfile;
import com.zsl.nrchecklogin.util.AWSAuthenticationUtil;
import com.zsl.nrchecklogin.util.DynamoDBUtil;




/**
 * Created on 28/07/2018.
   checking user login from LGCNS using SOAP web service  
   Fetching user details from DynamoDB & send LGCNS whether the user is correct or not
 */
public class LoginDAOImpl implements LoginDAO {

	private static Logger log = Logger.getLogger(LoginDAOImpl.class);
	
	AWSCredentials awsCredentials = null;
	AmazonDynamoDBClient client = null;
	@Override
	
	public UsersProfile doLogin(String userName) {
		try {
			awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			client = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(client);
			
			//String userStatus = "ACTIVE";
			String userRole = "RCGA";
			String userRole1 = "RCCA";
			String userRole2 = "RCFA";
			String userRole3 = "N";
			String userRole4 = "CT";
			
			Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
			attributeValues.put(":v1", new AttributeValue().withS(userName));
			attributeValues.put(":v2", new AttributeValue().withS(userRole));
			attributeValues.put(":v3", new AttributeValue().withS(userRole1));
			attributeValues.put(":v4", new AttributeValue().withS(userRole2));
			attributeValues.put(":v5", new AttributeValue().withS(userRole3));
			attributeValues.put(":v6", new AttributeValue().withS(userRole4));
			//attributeValues.put(":v7", new AttributeValue().withS(userStatus));
			
			
	           DynamoDBQueryExpression<UsersProfile> queryExpression = new DynamoDBQueryExpression<UsersProfile>()
	        	   .withIndexName("USERNAME-index")
	               .withConsistentRead(false)
	               .withKeyConditionExpression("USERNAME = :v1")
	               .withFilterExpression("(USERROLE = :v2 OR USERROLE = :v3 OR USERROLE = :v4 OR USERROLE = :v5 OR USERROLE = :v6)")
	               .withExpressionAttributeValues(attributeValues);
	           
	           List<UsersProfile> userInfo =  dynamoDBMapper.query(UsersProfile.class, queryExpression);
	         
	           if(userInfo.size() > 0) {
	        	   
	        	   return userInfo.get(0);
	           } else {
	        	  return null;
	           }
	          
		} catch (AmazonServiceException ase) {
			throw new RuntimeException(ase);
		} catch (AmazonClientException ace){
			throw new RuntimeException(ace);
		} catch (Exception e){
			throw new RuntimeException(e.getMessage());
		} finally {
			client = null;
			awsCredentials = null;
		}
	}	
	
	
	public String getAlertGroup(String groupId){
		String groupName = null;
		try {
			awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			client = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(client);
			
			String alertAuthorityGroupStatus = "ACTIVE";
			Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
			attributeValues.put(":v1", new AttributeValue().withS(groupId));
			attributeValues.put(":v2", new AttributeValue().withS(alertAuthorityGroupStatus));
			
	           DynamoDBQueryExpression<AlertAuthorityGroup> queryExpression = new DynamoDBQueryExpression<AlertAuthorityGroup>()
	               .withConsistentRead(false)
	               .withKeyConditionExpression("GROUPID = :v1")
	               .withFilterExpression("ALERTAUTHORITYGROUPSTATUS = :v2")
	               .withExpressionAttributeValues(attributeValues);
	           
	           List<AlertAuthorityGroup> alertGroupList =  dynamoDBMapper.query(AlertAuthorityGroup.class, queryExpression);
	           
	           if(alertGroupList.size() > 0) {
	          for(AlertAuthorityGroup alertGroup : alertGroupList){
	        	  groupName = alertGroup.getGroupName();
	          }
	          return groupName;
	           } else {
	        	   return null;
	           }
	          
		} catch (AmazonServiceException ase) {
			throw new RuntimeException(ase);
		} catch (AmazonClientException ace){
			throw new RuntimeException(ace);
		} catch (Exception e){
			throw new RuntimeException(e.getMessage());
		} finally {
			client = null;
			awsCredentials = null;
		}
	}
	
	public boolean getAlertInfo(String groupId, String customer,String facility){
		AlertInfo alertInfo = null;
		
		try {
			awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			client = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(client);
			
			String alertStatus = "OPEN";
			Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
			attributeValues.put(":v1", new AttributeValue().withS(groupId));
			attributeValues.put(":v2", new AttributeValue().withS(alertStatus));
			attributeValues.put(":v3", new AttributeValue().withS(facility));
			attributeValues.put(":v4", new AttributeValue().withS(customer));
			
	           DynamoDBQueryExpression<AlertInfo> queryExpression = new DynamoDBQueryExpression<AlertInfo>()
	        	   .withIndexName("GROUPID-ALERTSTATUS-index")
	               .withConsistentRead(false)
	               .withKeyConditionExpression("GROUPID = :v1 and ALERTSTATUS = :v2")
	               .withFilterExpression("FACILITY = :v3 and CUSTOMER = :v4")
	               .withExpressionAttributeValues(attributeValues);
	           
	           List<AlertInfo> alertList =  dynamoDBMapper.query(AlertInfo.class, queryExpression);
	         
	           if(alertList.size() > 0) {
	        	   
	        	   return true;
	           } else {
	        	  return false;
	           }
	          
		} catch (AmazonServiceException ase) {
			throw new RuntimeException(ase);
		} catch (AmazonClientException ace){
			throw new RuntimeException(ace);
		} catch (Exception e){
			throw new RuntimeException(e.getMessage());
		} finally {
			client = null;
			awsCredentials = null;
		}
	}
	
	public void saveUserDetails(UsersProfile userInfo) {
		
		try {
			awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			client = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper mapper = new DynamoDBMapper(client);
			mapper.save(userInfo);
			
		} catch (AmazonServiceException ase) {
			throw new RuntimeException("internalServerError"+ ase.getMessage(),ase);
		} catch (AmazonClientException ace){
			throw new RuntimeException("invalidRequest"+ace.getMessage(),ace);
		} catch (Exception e){
			throw new RuntimeException(e.getMessage());
		} finally {
			client = null;
			awsCredentials = null;
		}
	}
	
}



/*public AlertAuthorityGroup getAlertGroup(String groupId){
AlertAuthorityGroup alertGroup = null;
try {
	AWSCredentials awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
	AmazonDynamoDBClient amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
	DynamoDB dynamoDB = DynamoDBUtil.getAmazonDynamoDB(amazonDynamoDBClient);
		
	String alertAuthorityGroupStatus = "ACTIVE";
		Table table = dynamoDB.getTable("ALERT_AUTHORITY_GROUP");
		QuerySpec spec = new QuerySpec()
		    .withKeyConditionExpression("GROUPID = :v_groupId")
		    .withFilterExpression("(ALERTAUTHORITYGROUPSTATUS = :v_alertGroupStatus")
		    .withValueMap(new ValueMap()
		        .withString("::v_groupId", groupId)
		        .withString(":v_alertGroupStatus", alertAuthorityGroupStatus));
		        
		        

		ItemCollection<QueryOutcome> items = table.query(spec);
		alertGroup = new AlertAuthorityGroup();
		for(Item item : items){
			alertGroup.setGroupName(item.getString("GROUPNAME"));
		}
} catch (ConditionalCheckFailedException ccfe) {
	log.error(ccfe.getMessage(), ccfe);
	throw new RuntimeException("");
} catch (ItemCollectionSizeLimitExceededException icsle){
	log.error(icsle.getMessage(), icsle);
	throw new RuntimeException("");
} catch (LimitExceededException lee){
	log.error(lee.getMessage(), lee);
	throw new RuntimeException("");
} catch(ProvisionedThroughputExceededException ptee){
	log.error(ptee.getMessage(), ptee);
	throw new RuntimeException("");
} catch(ResourceInUseException riue){
	log.error(riue.getMessage(), riue);
	throw new RuntimeException("");
} catch (ResourceNotFoundException rnfe){
	log.error(rnfe.getMessage(), rnfe);
	throw new RuntimeException("");
} catch (InternalServerErrorException insee){
	log.error(insee.getMessage(), insee);
	throw new RuntimeException("");
} 
	return alertGroup;
}*/