package com.zsl.nrchecklogin.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.nrchecklogin.service.LoginService;
import com.zsl.nrchecklogin.serviceimpl.LoginServiceImpl;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {

	static Logger log = Logger.getLogger(LambdaFunctionHandler.class);
	
	Object result = null;
    @Override
    public Object handleRequest(Object input, Context context) {
    	log.info("Enter the Lambda Function Check Login");
    	try {
    		LoginService loginService = new LoginServiceImpl();
        	Map<String, String> userCredentials = (LinkedHashMap<String, String>) input;
        	String userName = userCredentials.get("userName");
        	String password = userCredentials.get("password");
        	log.info("Username and password is retrieved successfully");
        	result = loginService.doLogin(userName, password);
        
        	return result;
        	
		} catch (RuntimeException re) {
			log.error(re.getMessage(), re);
			throw re;
			
		}
    	     
    }
    public static void main(String args[]){
    	Object result = null;
    	LoginService loginService = new LoginServiceImpl();
    	Map<String, String> userCredentials = new LinkedHashMap<String, String>();
    	String userName = "Mary";
    	String password = "Mar";
    	//Maureen
    	result = loginService.doLogin(userName, password);
    	if(result.equals("authenticationFails")){
    		log.error("Authentication Fails");
    		throw new RuntimeException("authenticationFails");
    	}else{
    		
    	}
    }
}
