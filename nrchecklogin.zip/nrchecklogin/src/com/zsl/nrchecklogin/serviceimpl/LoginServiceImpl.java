package com.zsl.nrchecklogin.serviceimpl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.zsl.nrchecklogin.dao.LoginDAO;
import com.zsl.nrchecklogin.daoimpl.LoginDAOImpl;
import com.zsl.nrchecklogin.dto.MDIAchieveAPIRequest;
import com.zsl.nrchecklogin.dto.RequestData;
import com.zsl.nrchecklogin.dto.RequestParams;
import com.zsl.nrchecklogin.dto.ServiceResult;
import com.zsl.nrchecklogin.dto.UserData;
import com.zsl.nrchecklogin.dto.UsersProfile;
import com.zsl.nrchecklogin.service.LoginService;
import com.zsl.nrchecklogin.util.BouncyCastleEngine;
import com.zsl.nrchecklogin.util.CommonUtil;





/**
 * Created on 28/07/2018.
   checking user login from LGCNS using SOAP web service  
   
 */

public class LoginServiceImpl implements LoginService {
	String alertGroup = null;
	UsersProfile userInfo = null;
	private static Logger log = Logger.getLogger(LoginServiceImpl.class);
		
	@SuppressWarnings("unused")
	@Override
	public Object doLogin(String userName, String password) {
		try {	
		log.debug("Enter the doLogin method in Service layer");
		LoginDAO loginDAO = new LoginDAOImpl();
		UsersProfile userInfo = loginDAO.doLogin(userName);
		if(userInfo != null){
		String passcode = userInfo.getPassword();
		String	dataKey = CommonUtil.getInstance().getDataKey();
		String	passcode1 = BouncyCastleEngine.AESDecryption(passcode, dataKey);
		String	mcpassword = BouncyCastleEngine.AESDecryption(passcode1, dataKey);
			//String	mcpassword = "";
		if(userInfo.getEmrOperator() == "PCCApp"){
			if(userInfo.getGroupId() != null && !userInfo.getGroupId().equals("")) {
				alertGroup = loginDAO.getAlertGroup(userInfo.getGroupId());
				userInfo.setGroupName(alertGroup);
				boolean alertDetails = loginDAO.getAlertInfo(userInfo.getGroupId(),userInfo.getCustomer(),userInfo.getFacility());
				userInfo.setOpenAlert(alertDetails);
				if(userInfo.getAlertRole() == null || userInfo.getAlertRole().equals("")){
					if(userInfo.getUserStatus().equals("ACTIVE")){
						if(password.equals(mcpassword)){
							userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
							userInfo.setAlertFlag(false);	
							return userInfo;
						}
					else{
						return "invalid userName and password";
					}
						}else {
						return "inactive user";
					}
				} else {
					if(userInfo.getUserStatus().equals("ACTIVE")){
						if(password.equals(mcpassword)){
							userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
							userInfo.setAlertFlag(true);
							return userInfo;
					}
					else{
						return "invalid userName and password";
					}
					}else {
						return "inactive user";
					}
				}
				 }else 
				 {
						if(userInfo.getAlertRole() == null || userInfo.getAlertRole().equals("")){
							if(userInfo.getUserStatus().equals("ACTIVE")){
								if(password.equals(mcpassword)){
									userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
									userInfo.setAlertFlag(false);
									userInfo.setGroupName(null);
									userInfo.setOpenAlert(false);
									return userInfo;
								}
								else{
									return "invalid userName and password";
								}
							}else {
								return "inactive user";
							}
						} else {
							if(userInfo.getUserStatus().equals("ACTIVE")){
								if(password.equals(mcpassword)){
									userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
									userInfo.setAlertFlag(true);
									userInfo.setGroupName(null);
									userInfo.setOpenAlert(false);
									return userInfo;
								}
								else{
									return "invalid userName and password";
								}	
							}else {
								return "inactive user";
							}
						}
					}
	
		}else {
			if(userInfo != null){
				if(userInfo.getGroupId() != null && !userInfo.getGroupId().equals("")) {
					alertGroup = loginDAO.getAlertGroup(userInfo.getGroupId());
					userInfo.setGroupName(alertGroup);
					boolean alertDetails = loginDAO.getAlertInfo(userInfo.getGroupId(),userInfo.getCustomer(),userInfo.getFacility());
					userInfo.setOpenAlert(alertDetails);
				
				if(userInfo.getAlertRole() == null || userInfo.getAlertRole().equals("")){
					if(userInfo.getUserStatus().equals("ACTIVE")){
						String facility = userInfo.getFacility();
						String facilityOID = "2.16.124.113611.6432.1.1."+facility;
				
						ServiceResult serviceResult  = validateUser(facilityOID,userName,password);
						int transactionId = serviceResult.getTransactionId();
						if(transactionId == 0)
						{
							userInfo.setUserName(serviceResult.getUserData().getUserName());
							userInfo.setFamilyName(serviceResult.getUserData().getLastName());
							userInfo.setGivenName(serviceResult.getUserData().getFirstName());
							userInfo.setPassword(mcpassword);
							loginDAO.saveUserDetails(userInfo);
							userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
							userInfo.setAlertFlag(false);
							return userInfo;
						}else{
							String messageTxt = serviceResult.getMessageTxt();
							return messageTxt;
						}
						}else{
							return "inactive user";
						}
					}else{
						if(userInfo.getUserStatus().equals("ACTIVE")){
							String facility = userInfo.getFacility();
							String facilityOID = "2.16.124.113611.6432.1.1."+facility;
						
							ServiceResult serviceResult  = validateUser(facilityOID,userName,password);
							int transactionId = serviceResult.getTransactionId();
							if(transactionId == 0)
							{
								userInfo.setUserName(serviceResult.getUserData().getUserName());
								userInfo.setFamilyName(serviceResult.getUserData().getLastName());
								userInfo.setGivenName(serviceResult.getUserData().getFirstName());
								userInfo.setPassword(mcpassword);
								loginDAO.saveUserDetails(userInfo);
								userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
								userInfo.setAlertFlag(true);
								log.info("users authenticated successfully");
								return userInfo;
							}else{
								String messageTxt = serviceResult.getMessageTxt();
								return messageTxt;
							}
								}else{
									return "inactive user";
								}
					}
				}else{
						if(userInfo.getAlertRole() == null || userInfo.getAlertRole().equals("")){
							if(userInfo.getUserStatus().equals("ACTIVE")){
								String facility = userInfo.getFacility();
								String facilityOID = "2.16.124.113611.6432.1.1."+facility;
					
								ServiceResult serviceResult  = validateUser(facilityOID,userName,password);
								int transactionId = serviceResult.getTransactionId();
								if(transactionId == 0)
								{
									userInfo.setUserName(serviceResult.getUserData().getUserName());
									userInfo.setFamilyName(serviceResult.getUserData().getLastName());
									userInfo.setGivenName(serviceResult.getUserData().getFirstName());
									userInfo.setPassword(mcpassword);
									loginDAO.saveUserDetails(userInfo);
									userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
									userInfo.setAlertFlag(false);
									userInfo.setGroupName(null);
									userInfo.setOpenAlert(false);
									return userInfo;
								}else{
									String messageTxt = serviceResult.getMessageTxt();
									return messageTxt;
								}
							}else{
								return "inactive user";
							}
						}else{
							if(userInfo.getUserStatus().equals("ACTIVE")){
								String facility = userInfo.getFacility();
								String facilityOID = "2.16.124.113611.6432.1.1."+facility;
							
								ServiceResult serviceResult  = validateUser(facilityOID,userName,password);
								int transactionId = serviceResult.getTransactionId();
								if(transactionId == 0)
								{
									userInfo.setUserName(serviceResult.getUserData().getUserName());
									userInfo.setFamilyName(serviceResult.getUserData().getLastName());
									userInfo.setGivenName(serviceResult.getUserData().getFirstName());
									userInfo.setPassword(mcpassword);
									loginDAO.saveUserDetails(userInfo);
									userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
									userInfo.setAlertFlag(true);
									userInfo.setGroupName(null);
									userInfo.setOpenAlert(false);
									return userInfo;
								}else{
									String messageTxt = serviceResult.getMessageTxt();
									return messageTxt;
								}
							}else{
								return "inactive user";
									}
						}
					}
				}else
				{
					return "user's not registered, go to register through nurserosie admin portal";
				}
			}	
			}else{
				return "user's not registered, go to register through nurserosie admin portal";
			}
			}catch(Exception e){
				throw new RuntimeException(e.getMessage(), e);
			}
		}
	
	
	
	
	
	
	public ServiceResult validateUser(String facilityOID, String userName,
			String password) throws Exception {
		
		ServiceResult serviceResult = null;
		UserData userData = null;
		//JSONObject soapDatainJsonObject = null;
		
		//SSLContext sc = SSLContext.getInstance("SSL");
		SSLContext sc = SSLContext.getInstance("TLSv1");
		sc.init(null, getTrustManagers(), null);
		SSLContext.setDefault(sc);
	    sc.init(getKeyManagers(), new TrustManager[] { new X509TrustManager() {
			
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub
				
			}
		}}, new java.security.SecureRandom());
	    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
   
		HttpURLConnection httpUrlConnection = null;
		try {
			CommonUtil commonUtil = CommonUtil.getInstance();
			httpUrlConnection = commonUtil.getHttpURLConnection();
			httpUrlConnection.setDoInput(true);
			httpUrlConnection.setDoOutput(true);
			httpUrlConnection.setRequestMethod("POST");
			httpUrlConnection.setRequestProperty("Content-type", "text/xml; charset=utf-8");
			httpUrlConnection.setRequestProperty("SOAPAction", "http://external.api.integration.mdiachieve.com/ApiServiceInterface/invoke");
			OutputStream out =  httpUrlConnection.getOutputStream();
			Writer wout = new OutputStreamWriter(out);
			String request = createRequest(facilityOID, userName, password);
			wout.write(request);
			wout.flush();
			wout.close();
			
			out.flush();
			out.close();
			System.out.println(httpUrlConnection.getResponseCode());
			System.out.println(httpUrlConnection.getResponseMessage());
			
			DocumentBuilderFactory docFactory = commonUtil.getDocumentBuilderFactory();
			DocumentBuilder docBuilder = commonUtil.getDocumentBuilder(docFactory);
			Document doc = docBuilder.parse(httpUrlConnection.getInputStream());
			
			NodeList nodes = doc.getElementsByTagName("return");
			String line = nodes.item(0).getTextContent().trim();

			StringReader strreader = new StringReader(line);
			JAXBContext jaxbContext = JAXBContext.newInstance(ServiceResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			serviceResult = (ServiceResult)jaxbUnmarshaller.unmarshal(strreader);
			System.out.println(serviceResult.getMessageTxt());
			System.out.println(serviceResult.getTransactionId());
			System.out.println(serviceResult.getUserData().getFirstName());
			
		   
		} catch (ProtocolException pe) {
			// TODO: handle exception
		} catch (IOException ioe){
			throw new RuntimeException(ioe.getMessage(),ioe);
			
		} catch (Exception e){
			e.getStackTrace();
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
		}
		return serviceResult;
		
	}
	
	/*private OutputStream getOutputStream(HttpURLConnection httpUrlConnection){
		OutputStream out = null;
		try {
			out = httpUrlConnection.getOutputStream();
		} catch (IOException ioe) {
			getOutputStream(httpUrlConnection);
		}
		return out;
	}*/
	private String createRequest(String facilityOID, String userName, String password){
		
		DocumentBuilderFactory docFactory = CommonUtil.getInstance().getDocumentBuilderFactory();
		DocumentBuilder docBuilder = CommonUtil.getInstance().getDocumentBuilder(docFactory);
		Document doc = docBuilder.newDocument();
		
		Element rootElement = doc.createElementNS("http://schemas.xmlsoap.org/soap/envelope/", "soapenv:Envelope");
		doc.appendChild(rootElement);
		
		Element body = doc.createElement("soapenv:Body");
		rootElement.appendChild(body);
		
		Element invoke = doc.createElementNS("http://external.api.integration.mdiachieve.com/", "ext:invoke");
		body.appendChild(invoke);
		
		Element requestData = doc.createElement("requestData");
		invoke.appendChild(requestData);
		
		CDATASection cdata = doc.createCDATASection(createData(facilityOID, userName, password));
		requestData.appendChild(cdata);
		
		TransformerFactory transformerFactory = CommonUtil.getTransformerFactory();
		Transformer transformer = CommonUtil.getTransformer(transformerFactory);
		DOMSource source = new DOMSource(doc);
		
		
		StreamResult streamResult = new StreamResult(new StringWriter());
		try {
			transformer.transform(source, streamResult);
		} catch (TransformerException tfe) {
			// TODO: handle exception
		}
		
		return streamResult.getWriter().toString();
		
	}
	
	private String createData(String facilityOID, String userName, String password){
		StreamResult streamResult = null;
		MDIAchieveAPIRequest mdiAchieveAPIRequest = new MDIAchieveAPIRequest();
		mdiAchieveAPIRequest.setVersion("1.0");
		RequestData requestData = new RequestData();
		
		requestData.setRequestType("User.Validation");
		
		RequestParams requestParams = new RequestParams();
		requestParams.setFacilityOID(facilityOID);
		com.zsl.nrchecklogin.dto.UserData userData = new com.zsl.nrchecklogin.dto.UserData();
		userData.setUserName(userName);
		userData.setPassword(password);
		requestParams.setUserData(userData);
		requestData.setRequestParams(requestParams);
		mdiAchieveAPIRequest.setRequestData(requestData);
		try{
			JAXBContext jaxbContext = JAXBContext.newInstance(MDIAchieveAPIRequest.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			streamResult = new StreamResult(new StringWriter());
			jaxbMarshaller.marshal(mdiAchieveAPIRequest, streamResult);
			
		}catch(JAXBException jaxbe) {
			
		}
		return streamResult.getWriter().toString();
	}

	private static KeyManager[] getKeyManagers() throws Exception {
	    InputStream keyStoreInput = Class.forName("com.zsl.nrchecklogin.serviceimpl.LoginServiceImpl").getResourceAsStream("nurserosie.p12");
	    KeyStore keyStore = KeyStore.getInstance("PKCS12");
	    keyStore.load(keyStoreInput, "ros123ie".toCharArray());
	    KeyManagerFactory kmfactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	    kmfactory.init(keyStore, "ros123ie".toCharArray());
	    return kmfactory.getKeyManagers();
	}
	
	private static TrustManager[] getTrustManagers() throws Exception{
		TrustManagerFactory trustManagerFactory = null;
		try{
	    InputStream trustStoreInput = Class.forName("com.zsl.nrchecklogin.serviceimpl.LoginServiceImpl").getResourceAsStream("custom.truststore");
	    KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
	    trustStore.load(trustStoreInput, "changeit".toCharArray());
	    trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
	    trustManagerFactory.init(trustStore);
	    
		}catch(Exception e){
				e.getStackTrace();
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());
			}
		
		return trustManagerFactory.getTrustManagers();
		}
	
}


/*@Override
public Object doLogin(String userName, String password) {
	try {
		
	log.debug("Enter the doLogin method in Service layer");
	LoginDAO loginDAO = new LoginDAOImpl();
	UsersProfile userInfo = loginDAO.doLogin(userName);
	if(userInfo.getGroupId() != null && !userInfo.getGroupId().equals("")) {
	alertGroup = loginDAO.getAlertGroup(userInfo.getGroupId());
	userInfo.setGroupName(alertGroup);
	boolean alertDetails = loginDAO.getAlertInfo(userInfo.getGroupId(),userInfo.getCustomer(),userInfo.getFacility());
	userInfo.setOpenAlert(alertDetails);
	if(userInfo.getAlertRole() == null || userInfo.getAlertRole().equals("")){
		if(userInfo.getUserStatus().equals("ACTIVE")){
			if(password.equals(userInfo.getPassword())){
				userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
				userInfo.setAlertFlag(false);	
				return userInfo;
			}
		else{
			return "invalid userName and password";
		}
			}else {
			return "inactive user";
		}
	} else {
		if(userInfo.getUserStatus().equals("ACTIVE")){
			if(password.equals(userInfo.getPassword())){
				userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
				userInfo.setAlertFlag(true);
				return userInfo;
		}
		else{
			return "invalid userName and password";
		}
		}else {
			return "inactive user";
		}
	}
	 }else{
		
			if(userInfo.getAlertRole() == null || userInfo.getAlertRole().equals("")){
				if(userInfo.getUserStatus().equals("ACTIVE")){
					if(password.equals(userInfo.getPassword())){
						userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
						userInfo.setAlertFlag(false);
						userInfo.setGroupName(null);
						userInfo.setOpenAlert(false);
						return userInfo;
					}
					else{
						return "invalid userName and password";
					}
				}else {
					return "inactive user";
				}
			} else {
				if(userInfo.getUserStatus().equals("ACTIVE")){
					if(password.equals(userInfo.getPassword())){
						userInfo.setEncryptionKey("2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o");
						userInfo.setAlertFlag(true);
						userInfo.setGroupName(null);
						userInfo.setOpenAlert(false);
						return userInfo;
					}
					else{
						return "invalid userName and password";
					}	
				}else {
					return "inactive user";
				}
			}
		}
	
	}catch(Exception e){
		throw new RuntimeException(e.getMessage(), e);
	}
}


}
*/
