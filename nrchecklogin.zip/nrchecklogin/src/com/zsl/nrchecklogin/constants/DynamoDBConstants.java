package com.zsl.nrchecklogin.constants;

public class DynamoDBConstants {

	
}
