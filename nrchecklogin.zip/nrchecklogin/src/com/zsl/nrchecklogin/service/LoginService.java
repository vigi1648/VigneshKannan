package com.zsl.nrchecklogin.service;

import com.zsl.nrchecklogin.dto.AlertInfo;

public interface LoginService {

	public Object doLogin(String userName, String password); 
	
}
