package com.zsl.nrchecklogin.dao;

import java.util.List;

import com.zsl.nrchecklogin.dto.AlertAuthorityGroup;
import com.zsl.nrchecklogin.dto.AlertInfo;
import com.zsl.nrchecklogin.dto.UserInfo;
import com.zsl.nrchecklogin.dto.UsersProfile;

public interface LoginDAO {

	public UsersProfile doLogin(String userName);
	
	public String getAlertGroup(String groupId);
	
	public boolean getAlertInfo(String groupId, String customer,String facility);
	
	public void saveUserDetails(UsersProfile userInfo);
}
