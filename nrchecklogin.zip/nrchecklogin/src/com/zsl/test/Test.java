package com.zsl.test;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.zsl.nrchecklogin.util.AWSAuthenticationUtil;
import com.zsl.nrchecklogin.util.DynamoDBUtil;

public class Test {

	public static void main(String [] args){
		AWSCredentials awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
		AmazonDynamoDBClient amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
		DynamoDB dynamoDB = DynamoDBUtil.getAmazonDynamoDB(amazonDynamoDBClient);
				
			Table table = dynamoDB.getTable("USERS_PROFILE");
			Index index = table.getIndex("USERNAME-index");
			QuerySpec spec = new QuerySpec()
			    .withKeyConditionExpression("USERNAME = :v_USERNAME")
			    .withValueMap(new ValueMap()
			        .withString(":v_USERNAME", "TESTUSER"));

			ItemCollection<QueryOutcome> items = index.query(spec);
			System.out.println();
for(Item item : items){
	System.out.println(item);
}
			/*Iterator<Item> iterator = items.iterator();
			Item item = null;
			while (iterator.hasNext()) {
			    item = iterator.next();
			    System.out.println(item.toJSONPretty());
			}*/
	}
}
