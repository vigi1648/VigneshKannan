package com.amazonaws.samples;
import java.util.Iterator;
import java.util.Scanner;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class PatientsInfo {
	
	
	 static AmazonDynamoDB client;
	 
	 
	 public static void main(String args[])throws Exception{

   		 getcredentials();
			String app,status,fs;
			
			
	DynamoDB db=new DynamoDB(client);
	Table table = db.getTable("EMROPERATOR_INFO");// CHANGE BEFORE RUNNING
	Table table1 = db.getTable("PATIENTS_INFO");// CHANGE BEFORE RUNNING
	//Index
	Index index=table.getIndex("EMROPERATOR-index");// CHANGE BEFORE RUNNING
	Index index1=table1.getIndex("SENDINGAPPLICATION-SENDINGFACILITY-index");// CHANGE BEFORE RUNNING
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Application");
	app=sc.next();
	System.out.println("Enter facility status");
	fs=sc.next();
	System.out.println("Enter Patient Status");
	status=sc.next();
	sc.close();

	
	int count=0;
	
	
	
	QuerySpec queryspec1=new QuerySpec().withKeyConditionExpression("EMROPERATOR=:emr") .withFilterExpression("begins_with ( ACCEXPIRESIN, :val) AND FACILITYSTATUS= :f ")//AND FACILITYSTATUS= :f
			.withProjectionExpression("FACILITY").withValueMap(new ValueMap().withString(":emr",app).withString(":f", fs).withString(":val", "2"));//.withString(":f", fs)
           
           
                     
	

	 try{
			ItemCollection<QueryOutcome> items = index.query(queryspec1);
			for (Item userItem : items) {
				String fac= (String) userItem.get("FACILITY");
				
				
				QuerySpec queryspec=new QuerySpec().withKeyConditionExpression("SENDINGAPPLICATION = :s AND  SENDINGFACILITY = :f")
                        .withFilterExpression("PATIENTSTATUS= :p")/*.withProjectionExpression("PATIENTID")*/
	                       .withValueMap(new ValueMap().withString(":f", fac).withString(":s",app).withString(":p",status)
	                       );

				ItemCollection<QueryOutcome> items1 = index1.query(queryspec);
																							
				Iterator<Item> iter1 = items1.iterator(); 
				

				
				
				while(iter1.hasNext()){
					
				iter1.next();
		    //   System.out.println(	iter1.next().toString());
		       
				 
			   
				}
				System.out.println("Facility:  "+fac+"\t"+"  Active Patients:  "+items1.getAccumulatedItemCount());
				
				count=count+items1.getAccumulatedItemCount();
				
			}
			 System.out.println("Total Facilities : "+items.getAccumulatedItemCount());
	 }
	 catch (Exception e){
		 System.out.println(e.getMessage());
	 }
	 System.out.println("Total count: "+count);
	 }
	 public static  void getcredentials() throws Exception {
	      
	        ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider();
	        try {
	            credentialsProvider.getCredentials();
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
	        client = AmazonDynamoDBClientBuilder.standard()
	            .withCredentials(credentialsProvider)
	            .withRegion("us-east-1")//CHANGE BEFORE RUNNING
	            .build();
	    }
}
