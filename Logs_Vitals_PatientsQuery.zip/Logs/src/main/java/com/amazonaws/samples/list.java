package com.amazonaws.samples;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class list {
	 static AmazonDynamoDB client;
	 public static void main(String args[])throws Exception{
			credentials();
			
			
			DynamoDB db=new DynamoDB(client);
			Table table = db.getTable("EMROPERATOR_INFO");// CHANGE BEFORE RUNNING
			Table table1 = db.getTable("VITALSTATS");// CHANGE BEFORE RUNNING
			//Index
			Index index=table.getIndex("EMROPERATOR-index");// CHANGE BEFORE RUNNING
			Index index1=table1.getIndex("FACILITY-DATETIMEOFOBSERVATION-index");// CHANGE BEFORE RUNNING
			  
			//Date Function
			System.out.println("Enter date in ddmmyyyy format");
			Scanner sc=new Scanner(System.in);
			 String currentDate=sc.next();
			 sc.close();
				
	SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
	Date date=formatter.parse(currentDate) ;
			
			
			
			
			
			Date yesterday=getYesterday(date);
			
		   
			SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");

			String yesterdaystr = df.format(yesterday);
		
			String currentDatestr = df.format(date);
		
		    System.out.println(currentDatestr);
			System.out.println(yesterdaystr);
			
			
			
             int count=0;
             
            
			//EMROPERATOR Query
			QuerySpec queryspec1=new QuerySpec().withKeyConditionExpression("EMROPERATOR=:emr")
                 .withFilterExpression("begins_with ( ACCEXPIRESIN, :val) AND FACILITYSTATUS=:a ").withProjectionExpression("FACILITY")//AND FACILITYSTATUS=:a
                
                 
                            .withValueMap(new ValueMap().withString(":emr","PCCApp").withString(":val", "2").withString(":a", "ACTIVE"));
		
		
			
			

			 try{
					ItemCollection<QueryOutcome> items = index.query(queryspec1);
					for (Item userItem : items) {
						
					
						//System.out.println(userItem.get("FACILITY"));
						//System.out.println("Facility is:"+ userItem.attributes());
						
					String fac= (String) userItem.get("FACILITY");
					// String fac1= (String) userItem.get("FACILITYNAME");
					   
		              // System.out.println(fac);
						
		                
				
						
						QuerySpec queryspec=new QuerySpec().withKeyConditionExpression("FACILITY = :f AND  DATETIMEOFOBSERVATION BETWEEN :y AND :c")
		                           .withFilterExpression("contains(TRANSACTIONID, :S)")
		 	                       .withValueMap(new ValueMap().withString(":f", fac).withString(":y",yesterdaystr).withString(":c",currentDatestr)
		 	                       .withString(":S", "Success"));   //yesterdaystr   daybeforestr  currentDatestr .withString(":f", fac)
						
					
						

						
						ItemCollection<QueryOutcome> items1 = index1.query(queryspec);
																									
						Iterator<Item> iter1 = items1.iterator(); 
						

						
						
						while(iter1.hasNext()){
							
						
				       	iter1.next().toJSONPretty();
						 
					   
						}
						
						System.out.println(fac+"\t  "+items1.getAccumulatedItemCount());
						
						count=count+items1.getAccumulatedItemCount();
						
						
						
						/*System.out.print("Facility:\t"+fac);
						System.out.print("\t\t");
						System.out.println("\tCount:"+items1.getAccumulatedItemCount());*/
						
						}//toJSONPretty()
										 
					 System.out.println("Total Active Vital Counts : "+items.getAccumulatedItemCount());
					}
				 catch(Exception e){
					 System.out.println(e.getMessage());
				 }
			
              System.out.print("Total Vital Counts : "+count);
		}
	 
	
		public static   Date getYesterday(Date date) {
		    Calendar cal = Calendar.getInstance();

		    cal.setTime(date);
		    cal.add(Calendar.DATE, -1);
		    return (Date)cal.getTime();
		}
		

	 public static  void credentials() throws Exception {
	      
	        ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider();
	        try {
	            credentialsProvider.getCredentials();
	        } catch (Exception e) {
	            throw new AmazonClientException(
	                    "Cannot load the credentials from the credential profiles file. " +
	                    "Please make sure that your credentials file is at the correct " +
	                    "location (C:\\Users\\manjunathpg\\.aws\\credentials), and is in valid format.",
	                    e);
	        }
	        client = AmazonDynamoDBClientBuilder.standard()
	            .withCredentials(credentialsProvider)
	            .withRegion("us-east-1")//CHANGE BEFORE RUNNING
	            .build();
	    }

}
