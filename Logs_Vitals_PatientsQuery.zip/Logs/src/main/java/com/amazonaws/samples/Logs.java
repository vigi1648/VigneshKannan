package com.amazonaws.samples;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.logs.AWSLogs;
import com.amazonaws.services.logs.AWSLogsClientBuilder;
import com.amazonaws.services.logs.model.DescribeLogStreamsRequest;
import com.amazonaws.services.logs.model.DescribeLogStreamsResult;
import com.amazonaws.services.logs.model.FilterLogEventsRequest;
import com.amazonaws.services.logs.model.FilterLogEventsResult;
import com.amazonaws.services.logs.model.LogStream;

public class Logs {
	
	  public  void FilterLog(String loggroupname, String err)
      {
	//		Mail mailobj=new Mail();

		  int count=0;
		//  long currentdatemillis = System.currentTimeMillis();
		  //  long yesterdayMillis = System.currentTimeMillis()- (24 * 60 * 60 * 1000);
		    ClientConfiguration clientConfig = new ClientConfiguration();

	          AWSLogsClientBuilder builder = AWSLogsClientBuilder.standard();

	         AWSLogs logsClient = builder.withCredentials( new AWSStaticCredentialsProvider( new ProfileCredentialsProvider().getCredentials() ) )
	                  .withRegion( "us-east-1")
	                  .withClientConfiguration( clientConfig ).build();
	         DescribeLogStreamsRequest describeLogStreamsRequest = new DescribeLogStreamsRequest().withDescending(true).withLimit(15)
	        		  .withLogGroupName(loggroupname);//.withOrderBy(datestr)

	        /*  DescribeLogStreamsRequest describeLogStreamsRequest = new DescribeLogStreamsRequest().withDescending(true).withLimit(10)
	        		  .withLogGroupName("/aws/lambda/CronExcluding6customers");//.withOrderBy(datestr)
*/	          DescribeLogStreamsResult describeLogStreamsResult = logsClient.describeLogStreams( describeLogStreamsRequest );
                 System.out.println(loggroupname+" "+err);

	          for ( LogStream logStream : describeLogStreamsResult.getLogStreams() )
	          {
	        	  
	        	  
	        	  System.out.println(logStream.getLogStreamName());
	        
	          
	        	  
	        	  FilterLogEventsRequest filter=new FilterLogEventsRequest()//.withEndTime(currentdatemillis)      .withStartTime(yesterdayMillis)
	        	.withFilterPattern(err).withLogGroupName(loggroupname).withLogStreamNames(logStream.getLogStreamName());
	        	  
	        	  FilterLogEventsResult fliterresponse=logsClient.filterLogEvents(filter);
	        	
	        	//  System.out.println(fliterresponse.getEvents());
	        	  System.out.println(fliterresponse.getEvents().size());
	        	  
	        	 count=fliterresponse.getEvents().size();

	        	  
	        	  
	        //	 count=count+fliterresponse.getEvents().size();
	        		/*for (FilteredLogEvent  outputLogEvent  : fliterresponse.getEvents() ) {
	              	  System.out.println(outputLogEvent.getMessage() );
	              	  
	                }*/
	        	  System.out.println(count);
		          if(count>1500) {
		        	  //send mail
		        	System.out.println("--------------------------------------------------"); 
		        	System.out.println("TRRIGGER ALARM");  
		        	System.out.println("The error "+err+"exceeds "+count+"in cron "+loggroupname+"log name "+logStream.getLogStreamName());
		        	System.out.println("---------------------------------------------------"); 
		        	//	mailobj.triggerMail(loggroupname,logStream.getLogStreamName(),count,err);

		          }  
	          
	          }
	         
	          
	          
      }

}
