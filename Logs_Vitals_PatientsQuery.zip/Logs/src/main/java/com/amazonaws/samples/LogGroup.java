package com.amazonaws.samples;

public class LogGroup {
	 
	public static void main(String []args) {
		
		
		Logs logobj=new Logs();
		String arr[]= {"/aws/lambda/CronExcluding6customers","/aws/lambda/Cron_494952012","/aws/lambda/Cron_494952549","/aws/lambda/Cron_494954025and80185","/aws/lambda/Cron_5000079","/aws/lambda/Cron_80072"};
		String err[]= {"error","401","response1Unauthorized","Null"};

		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<err.length;j++) {
			logobj.FilterLog(arr[i],err[j]);
			}
		}
		
		
		
		
		
		
	}

	
	
}
