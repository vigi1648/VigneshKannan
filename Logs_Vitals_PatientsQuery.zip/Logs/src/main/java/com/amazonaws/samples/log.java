package com.amazonaws.samples;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.logs.AWSLogs;
import com.amazonaws.services.logs.AWSLogsClientBuilder;
import com.amazonaws.services.logs.model.DescribeLogStreamsRequest;
import com.amazonaws.services.logs.model.DescribeLogStreamsResult;
import com.amazonaws.services.logs.model.FilterLogEventsRequest;
import com.amazonaws.services.logs.model.FilterLogEventsResult;
import com.amazonaws.services.logs.model.GetLogEventsRequest;
import com.amazonaws.services.logs.model.GetLogEventsResult;
import com.amazonaws.services.logs.model.LogStream;
import com.amazonaws.services.logs.model.OutputLogEvent;
import com.amazonaws.services.logs.model.StartQueryRequest;
import com.amazonaws.services.logs.model.StartQueryResult;

public class log {
	  public static void main( String[] args )
      {
		String queryString = "filter @message like /error/ | stats count(*) as exceptionCount by bin(1h)| sort exceptionCount desc";
		  long currentdatemillis = System.currentTimeMillis();
		    long yesterdayMillis = System.currentTimeMillis()- (24 * 60 * 60 * 1000);
		  //  Boolean isMatch = true;
		  //  String date1=currentdatemillis+"";
		    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");  
		    Date date = new Date();  
			String datestr = formatter.format(date);
		    System.out.println(formatter.format(date));  
          ClientConfiguration clientConfig = new ClientConfiguration();

          AWSLogsClientBuilder builder = AWSLogsClientBuilder.standard();

         AWSLogs logsClient = builder.withCredentials( new AWSStaticCredentialsProvider( new ProfileCredentialsProvider().getCredentials() ) )
                  .withRegion( "us-east-1")
                  .withClientConfiguration( clientConfig ).build();

          DescribeLogStreamsRequest describeLogStreamsRequest = new DescribeLogStreamsRequest().withDescending(true).withLimit(10)
        		  .withLogGroupName("/aws/lambda/CronExcluding6customers");//.withOrderBy(datestr)
          DescribeLogStreamsResult describeLogStreamsResult = logsClient.describeLogStreams( describeLogStreamsRequest );

          for ( LogStream logStream : describeLogStreamsResult.getLogStreams() )
          {
        	  System.out.println(logStream.getLogStreamName());

        	  
        	  GetLogEventsRequest getLogEventsRequest = new GetLogEventsRequest()
                      .withStartTime( yesterdayMillis )
                      .withEndTime( currentdatemillis )
                      .withLogGroupName( "/aws/lambda/CronExcluding6customers" )
                      .withLogStreamName( logStream.getLogStreamName() );
        	/*  
        	  FilterLogEventsRequest filter=new FilterLogEventsRequest().withEndTime(currentdatemillis)
        			  .withStartTime(yesterdayMillis).withFilterPattern("ERROR").withLogGroupName("/aws/lambda/CronExcluding6customers").withLogStreamNames(logStream.getLogStreamName());
        	  
        	  FilterLogEventsResult fliterresponse=logsClient.filterLogEvents(filter);
        	
        	  System.out.println(fliterresponse.getEvents());
        	  System.out.println(fliterresponse.getEvents().size());*/
        	  

        	/*  StartQueryRequest req=new StartQueryRequest().withLogGroupName("/aws/lambda/CronExcluding6customers")
        			  .withQueryString(queryString).withStartTime(yesterdayMillis).withEndTime(currentdatemillis);
        	  
        	  StartQueryResult response=logsClient.startQuery(req);
        	  response.withQueryId(response.getQueryId());
        	  System.out.println(response.getSdkResponseMetadata());*/
        	  
        	  
              /*GetLogEventsRequest getLogEventsRequest = new GetLogEventsRequest()
                      .withStartTime( 1531231200000L )
                      .withEndTime( 1531576800000L )
                      .withLogGroupName( "CronExcluding6customers" )
                      .withLogStreamName( logStream.getLogStreamName() );*/

              GetLogEventsResult result = logsClient.getLogEvents( getLogEventsRequest );
              
              
			for (OutputLogEvent  outputLogEvent  : result.getEvents() ) {
            	  System.out.println(outputLogEvent.getMessage() );
            	  
              }

              
              

              /*result.getEvents().forEach( outputLogEvent -> {
                  System.out.println( outputLogEvent.getMessage() );
              } );*/

          }
      }

}
