package com.amazonaws.samples;

import java.util.ArrayList;

import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.DeleteItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class Deletion {
	
public void delete(ItemCollection<QueryOutcome> items1, String facility, Table table1) {
	
	 ArrayList<String> names = new ArrayList<String>();
     ArrayList<String> names1 = new ArrayList<String>();

     
 	int l=0;


	for (Item userItem1 : items1) {
		String pat= (String) userItem1.get("PATIENTID");
		String pat1= (String) userItem1.get("NRPATIENTID");

		names.add(pat);
		names1.add(pat1);

	}
	//System.out.println(names.size());
	
	
	for(int i=0;i<names.size();i++) {
		for(int j=i+1;j<names.size();j++) {
			if(names.get(i).equals(names.get(j)))	{
				 DeleteItemSpec deleteItemSpec = new DeleteItemSpec()
						 .withPrimaryKey("NRPATIENTID",names1.get(j)).withConditionExpression("PATIENTID = :id ")//and HASPHOTO = :val
				            .withValueMap(new ValueMap().withString(":id",names.get(j)));//.withString(":val",val )


				   try {
				            System.out.println("Attempting a conditional delete...");
				            table1.deleteItem(deleteItemSpec);
				            
				            System.out.println("DeleteItem succeeded");
				            System.out.println("deleted item: " + names.get(j) + " " + names1.get(j));
                            names.remove(j);
                            names1.remove(j);


				        }
				        catch (Exception e) {
				           System.err.println("Unable to delete item: " + names.get(i) + " " + names1.get(j));
				           System.err.println(e.getMessage());
				        
				        }
				   
				
				
				
				
			
				l=l+1;
			}
			
		}	
	}
	

	if(l==0) {
		
		System.out.println(facility+"\t  "+"DELETED COUNT:"+l);
		
	}
	else {
		System.out.println(facility+"\t "+"DELETED COUNT:"+l);

	}
	
	
	
}
	

}
