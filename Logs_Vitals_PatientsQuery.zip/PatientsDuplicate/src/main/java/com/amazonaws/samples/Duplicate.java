package com.amazonaws.samples;

import java.util.ArrayList;
import java.util.Scanner;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class Duplicate {
	 static AmazonDynamoDB client;

	public static void main(String []args) throws Exception {
		credentials obj2=new credentials();
		client=  obj2.getcredentials();
		Deletion del=new Deletion();

        DynamoDB db=new DynamoDB(client);
    	Table table = db.getTable("EMROPERATOR_INFO");// CHANGE BEFORE RUNNING

    	Table table1 = db.getTable("PATIENTS_INFO");// CHANGE BEFORE RUNNING
    	//Index
    	Index index=table.getIndex("EMROPERATOR-index");// CHANGE BEFORE RUNNING

    	Index index1=table1.getIndex("SENDINGAPPLICATION-SENDINGFACILITY-index");// CHANGE BEFORE RUNNING
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter Application");
    	String app = sc.next();
    	System.out.println("Enter facility status ");
    	String facilitystatus = sc.next();
    	System.out.println("Enter Patient Status");
    	String Patientstatus = sc.next();
    	sc.close();
    	

        

    	QuerySpec queryspec1=new QuerySpec().withKeyConditionExpression("EMROPERATOR=:emr") .withFilterExpression("begins_with ( ACCEXPIRESIN, :val) AND FACILITYSTATUS= :f")
    			.withProjectionExpression("FACILITY").withValueMap(new ValueMap().withString(":emr",app).withString(":val", "2").withString(":f", facilitystatus));
               
			ItemCollection<QueryOutcome> items = index.query(queryspec1);
			System.out.println("Facility \t   No of Duplicates");


   	 try{

   			for (Item userItem : items) {
				String fac1= (String) userItem.get("FACILITY");		               
               
		        ArrayList<String> names = new ArrayList<String>();


		QuerySpec queryspec=new QuerySpec().withKeyConditionExpression("SENDINGAPPLICATION = :s AND SENDINGFACILITY = :f")/*.withProjectionExpression("PATIENTID")*/
                .withFilterExpression("PATIENTSTATUS= :p")
                   .withValueMap(new ValueMap().withString(":f", fac1).withString(":s",app).withString(":p",Patientstatus)
                   );
		
		
		ItemCollection<QueryOutcome> items1 = index1.query(queryspec);
	//	Iterator<Item> iter1 = items1.iterator(); 
		//del.delete(items1,fac1,table1);

    	int l=0;

		for (Item userItem1 : items1) {
			String pat= (String) userItem1.get("PATIENTID");
			names.add(pat);
			
		}
		for(int i=0;i<names.size();i++) {
			for(int j=i+1;j<names.size();j++) {
				if(names.get(i).equals(names.get(j)))	{
					
					System.out.println(names.get(i)+"\t\t"+names.get(j));
					//del.delete(items1,fac1,table1);
					
					
					l=l+1;
				}
				
			}	
		}
		

		if(l==0) {
			
			System.out.println(fac1+"\t "+l);
			
		}
		else {
			System.out.println(fac1+"\t "+l);

		}
		
		
		
   			}
   	 }

   	 catch(Exception e) {
   		System.out.println( e.getMessage());
   		
   	 }
	
	 System.out.println("Total Facilities : "+items.getAccumulatedItemCount());

		
		
		
	}
	

}
