package com.amazonaws.samples;

import java.util.Scanner;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.DeleteItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class Inactivedeletion {
	

	 static AmazonDynamoDB client;

		public static void main(String []args) throws Exception {
			credentials obj2=new credentials();
			client=  obj2.getcredentials();
	
	        DynamoDB db=new DynamoDB(client);
	    	Table table = db.getTable("EMROPERATOR_INFO");// CHANGE BEFORE RUNNING

	    	Table table1 = db.getTable("PATIENTS_INFO_UAT");// CHANGE BEFORE RUNNING
	    	Index index=table.getIndex("EMROPERATOR-index");// CHANGE BEFORE RUNNING

	    	Index index1=table1.getIndex("SENDINGAPPLICATION-SENDINGFACILITY-index");// CHANGE BEFORE RUNNING
	    	Scanner sc=new Scanner(System.in);
	    	System.out.println("Enter Application");
	    	String app = sc.next();
	    	System.out.println("Enter facility status  ");
	    	String facility = sc.next();
	    	System.out.println("Enter Patient Status");
	    	String Patientstatus = sc.next();
	    	sc.close();
	    	

//	    	int count=0;
	    	
	    	
	    	
	    	QuerySpec queryspec1=new QuerySpec().withKeyConditionExpression("EMROPERATOR=:emr") .withFilterExpression("begins_with ( ACCEXPIRESIN, :val) AND FACILITYSTATUS= :f")
	    			.withProjectionExpression("FACILITY").withValueMap(new ValueMap().withString(":emr",app).withString(":val", "2").withString(":f", facility));
	               
	               
	                         
	    	

	    	 try{
	    			ItemCollection<QueryOutcome> items = index.query(queryspec1);
	    			for (Item userItem : items) {
	    				String fac= (String) userItem.get("FACILITY");
	    				
	    				
	    				QuerySpec queryspec=new QuerySpec().withKeyConditionExpression("SENDINGAPPLICATION = :s AND  SENDINGFACILITY = :f")
	                            .withFilterExpression("PATIENTSTATUS= :p")/*.withProjectionExpression("PATIENTID")*/
	    	                       .withValueMap(new ValueMap().withString(":f", fac).withString(":s",app).withString(":p",Patientstatus)
	    	                       );

	    				ItemCollection<QueryOutcome> items1 = index1.query(queryspec);
	    																							
	    			//	Iterator<Item> iter1 = items1.iterator(); 
	    				
	    				int l=0;


	    				for (Item userItem1 : items1) {
	    					//String pat= (String) userItem1.get("PATIENTID");
		    				System.out.println("Facility:  "+fac+"\t"+"  InActive Patients:  "+items1.getAccumulatedItemCount());

	    					String pat= (String) userItem1.get("NRPATIENTID");
	    					
	    					
	    					
	    					 DeleteItemSpec deleteItemSpec = new DeleteItemSpec()
									 .withPrimaryKey("NRPATIENTID",pat).withConditionExpression("PATIENTSTATUS = :sts ")//and HASPHOTO = :val
							            .withValueMap(new ValueMap().withString(":sts",Patientstatus));



							   try {
							            System.out.println("Attempting a conditional delete...");
							            table1.deleteItem(deleteItemSpec);
							            
							            System.out.println("DeleteItem succeeded");
							            System.out.println("deleted item: " + pat + " " + userItem1.get("PATIENTSTATUS"));//Patientstatus

							        }
							   catch(Exception e) {
								   System.err.println("Unable to delete item: "+pat+" "+userItem1.get("PATIENTSTATUS"));//Patientstatus
						           System.err.println(e.getMessage());							 
						           
							   }
							       
							
							
							
							
						
							l=l+1;



	    				}
	    				
	    		    	 System.out.println("Total deleted count: "+l);


	    			}
	    			 System.out.println("Total Facilities : "+items.getAccumulatedItemCount());
	    	 }
	    	 catch (Exception e){
	    		 System.out.println(e.getMessage());
	    	 }
	
	

	    	
	    	
	    	
	    	
	    	
	    	
	    	
	
		}

}
