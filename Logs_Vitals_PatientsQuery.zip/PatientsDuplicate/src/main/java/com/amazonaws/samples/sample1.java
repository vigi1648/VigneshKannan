package com.amazonaws.samples;

import java.util.ArrayList;
import java.util.Scanner;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.document.BatchWriteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;
import com.amazonaws.services.dynamodbv2.document.spec.DeleteItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class sample1 {
	 static AmazonDynamoDB client;

		public static void main(String []args) throws Exception {
			credentials obj2=new credentials();
			client=  obj2.getcredentials();
	
	        DynamoDB db=new DynamoDB(client);

	    	Table table1 = db.getTable("PATIENTS_INFO_UAT");// CHANGE BEFORE RUNNING
	    	Index index1=table1.getIndex("SENDINGAPPLICATION-SENDINGFACILITY-index");// CHANGE BEFORE RUNNING
	    	Scanner sc=new Scanner(System.in);
	    	System.out.println("Enter Application");
	    	String app = sc.next();
	    	System.out.println("Enter facility  ");
	    	String facility = sc.next();
	    	System.out.println("Enter Patient Status");
	    	String Patientstatus = sc.next();
	    	sc.close();
	     //   ArrayList<String> names = new ArrayList<String>();
	      //  ArrayList<String> names1 = new ArrayList<String>();


		//	System.out.println("Facility \t   Deleted Duplicates");
	    		    	
	    	
	    	
	    			 
	    	
	    	
	    	
	    	

			QuerySpec queryspec=new QuerySpec().withKeyConditionExpression("SENDINGAPPLICATION = :s AND SENDINGFACILITY = :f")/*.withProjectionExpression("NRPATIENTID,HASPHOTO,PATIENTID")*/
	                .withFilterExpression("PATIENTSTATUS= :p")
	                   .withValueMap(new ValueMap().withString(":f", facility).withString(":s",app).withString(":p",Patientstatus)
	                   );
		
			ItemCollection<QueryOutcome> items1 = index1.query(queryspec);
			//Iterator<Item> iter1 = items1.iterator(); 
	    	int l=0;


			for (Item userItem1 : items1) {
				//String pat= (String) userItem1.get("PATIENTID")
				String pat1= (String) userItem1.get("NRPATIENTID");

				
				
			//	names.add(pat);
				//names1.add(pat1);

		//	System.out.println(names.size());
		//	System.out.println(names);
			
			
					DeleteItemSpec deleteItemSpec = new DeleteItemSpec()
								 .withPrimaryKey("NRPATIENTID",pat1).withConditionExpression("PATIENTSTATUS = :id ")//and HASPHOTO = :val
						            .withValueMap(new ValueMap().withString(":id",Patientstatus));//.withString(":val",val )

				
						   try {

								//TableWriteItems deletetable = new TableWriteItems("PATIENTS_INFO_UAT").w.withHashOnlyKeysToDelete(names1.get(i), Patientstatus);

									//	.withHashAndRangeKeysToDelete(pat1,Patientstatus);
						            System.out.println("Attempting a conditional delete...");
						            table1.deleteItem(deleteItemSpec);
									//BatchWriteItemOutcome outcome = db.batchWriteItem(deletetable);
							//	System.out.println(outcome.getBatchWriteItemResult());
 
						            System.out.println("DeleteItem succeeded");
						            System.out.println("deleted item: " + pat1 + " " + Patientstatus);

						        }
						   catch(Exception e) {
							   e.printStackTrace();
						   }
						       
						
						
						
						
					
						l=l+1;
					
			}
	
				
		System.out.println("TOTAL DELETED COUNT:" +l);	
		}
		
}
		
		
		


/*TableWriteItems deletetable = new TableWriteItems("PATIENTS_INFO_UAT")

.withHashAndRangeKeysToDelete(pat1,Patientstatus);
BatchWriteItemOutcome outcome = db.batchWriteItem(deletetable);

do {
Map<String, List<WriteRequest>> unprocessedItems =
outcome.getUnprocessedItems();

if (outcome.getUnprocessedItems().size() == 0) {
System.out.println("No unprocessed items found");
}
else {
System.out.println("Retrieving the unprocessed items");
outcome = db.batchWriteItemUnprocessed(unprocessedItems);
}
} while (outcome.getUnprocessedItems().size() > 0);*/







