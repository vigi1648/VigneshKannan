package com.amazonaws.samples;

import java.util.Scanner;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class Duplicatedeletion {
	
	 static AmazonDynamoDB client;

		public static void main(String []args) throws Exception {
			credentials obj2=new credentials();
			client=  obj2.getcredentials();
	Deletion del=new Deletion();
	        DynamoDB db=new DynamoDB(client);

	    	Table table1 = db.getTable("PATIENTS_INFO");// CHANGE BEFORE RUNNING
	    	Index index1=table1.getIndex("SENDINGAPPLICATION-SENDINGFACILITY-index");// CHANGE BEFORE RUNNING
	    	Scanner sc=new Scanner(System.in);
	    	System.out.println("Enter Application");
	    	String app = sc.next();
	    	System.out.println("Enter facility  ");
	    	String facility = sc.next();
	    	System.out.println("Enter Patient Status");
	    	String Patientstatus = sc.next();
	    	sc.close();
	     //   ArrayList<String> names = new ArrayList<String>();
	       // ArrayList<String> names1 = new ArrayList<String>();


		//	System.out.println("Facility \t   Deleted Duplicates");

			QuerySpec queryspec=new QuerySpec().withKeyConditionExpression("SENDINGAPPLICATION = :s AND SENDINGFACILITY = :f")/*.withProjectionExpression("NRPATIENTID,HASPHOTO,PATIENTID")*/
	                .withFilterExpression("PATIENTSTATUS= :p")
	                   .withValueMap(new ValueMap().withString(":f", facility).withString(":s",app).withString(":p",Patientstatus)
	                   );
		
			ItemCollection<QueryOutcome> items1 = index1.query(queryspec);
		//	Iterator<Item> iter1 = items1.iterator(); 
			
			del.delete(items1,facility,table1);
		/*	
	    	int l=0;


			for (Item userItem1 : items1) {
				String pat= (String) userItem1.get("PATIENTID");
				String pat1= (String) userItem1.get("NRPATIENTID");

				names.add(pat);
				names1.add(pat1);

			}
			System.out.println(names.size());
		//	System.out.println(names);
			
			
			for(int i=0;i<names.size();i++) {
				for(int j=i+1;j<names.size();j++) {
					if(names.get(i).equals(names.get(j)))	{
					//	String val=null;
						 DeleteItemSpec deleteItemSpec = new DeleteItemSpec()
								 .withPrimaryKey("NRPATIENTID",names1.get(j)).withConditionExpression("PATIENTID = :id ")//and HASPHOTO = :val
						            .withValueMap(new ValueMap().withString(":id",names.get(j)));//.withString(":val",val )


						   try {
						            System.out.println("Attempting a conditional delete...");
						            table1.deleteItem(deleteItemSpec);
						            
						            System.out.println("DeleteItem succeeded");
						            System.out.println("deleted item: " + names.get(j) + " " + names1.get(j));
		                            names.remove(j);
		                            names1.remove(j);


						        }
						        catch (Exception e) {
						           System.err.println("Unable to delete item: " + names.get(i) + " " + names1.get(j));
						           System.err.println(e.getMessage());
						 //  e.printStackTrace();
						        
						        }
						   
						
						
						
						
					//	System.out.println(names.get(i)+"\t\t"+names.get(j));
					
						l=l+1;
						//System.out.println("Facility :"+fac1);
					}
					
				}	
			}
			
		//	System.out.println("Facility \t   No of Duplicates");

			if(l==0) {
	//System.out.println("\t No duplication");
				
				System.out.println(facility+"\t "+l);
				
			}
			else {
				//System.out.println("\tDuplication exists");
				//System.out.println("\tNo of duplicates:"+l);
				System.out.println(facility+"\t "+l);

			}
		*/
		
		}
		

}
