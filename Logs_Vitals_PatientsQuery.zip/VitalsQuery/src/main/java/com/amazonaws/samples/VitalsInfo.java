package com.amazonaws.samples;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class VitalsInfo {
	   static int count=0;
	 public static void main(String args[])throws Exception{
			Credentialsclass obj2=new Credentialsclass();
         obj2.credentials();
			DynamoDB db=new DynamoDB(Credentialsclass.client);
			Table table = db.getTable("EMROPERATOR_INFO");// CHANGE BEFORE RUNNING
			Table table1 = db.getTable("VITALSTATS");// CHANGE BEFORE RUNNING
			//Index
			Index index=table.getIndex("EMROPERATOR-index");// CHANGE BEFORE RUNNING
			Index index1=table1.getIndex("FACILITY-DATETIMEOFOBSERVATION-index");// CHANGE BEFORE RUNNING
			  
			//Date Function
			System.out.println("Enter date in ddmmyyyy format");
			
			Scanner sc=new Scanner(System.in);
			 String currentDate=sc.next();
				System.out.println("Enter FACILITY STATUS");

			 String status=sc.next();
			 sc.close();
				
	SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
	Date date=formatter.parse(currentDate) ;				
			
			Date yesterday=getYesterday(date);			
		   
			SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");

			String yesterdaystr = df.format(yesterday);
		
			String currentDatestr = df.format(date);
		
		    System.out.println(currentDatestr);
			System.out.println(yesterdaystr);
			
			
			

	           	   Excel obj1=new Excel();
			
             
            
			//EMROPERATOR Query
			QuerySpec queryspec1=new QuerySpec().withKeyConditionExpression("EMROPERATOR=:emr")
                 .withFilterExpression("begins_with ( ACCEXPIRESIN, :val) AND FACILITYSTATUS=:a ").withProjectionExpression("FACILITY")//AND FACILITYSTATUS=:a
                
                 
                            .withValueMap(new ValueMap().withString(":emr","PCCApp").withString(":val", "2").withString(":a", status));
		
		
			
	


			 try{
					ItemCollection<QueryOutcome> items = index.query(queryspec1);
					for (Item userItem : items) {
						
					
						
					String fac= (String) userItem.get("FACILITY");
				
						
		                
				
						
						QuerySpec queryspec=new QuerySpec().withKeyConditionExpression("FACILITY = :f AND  DATETIMEOFOBSERVATION BETWEEN :y AND :c")
		                           .withFilterExpression("contains(TRANSACTIONID, :S)")
		 	                       .withValueMap(new ValueMap().withString(":f", fac).withString(":y",yesterdaystr).withString(":c",currentDatestr)
		 	                       .withString(":S", "Success"));   //yesterdaystr   daybeforestr  currentDatestr .withString(":f", fac)
						
					
						

						
						ItemCollection<QueryOutcome> items1 = index1.query(queryspec);
																									
						Iterator<Item> iter1 = items1.iterator(); 
						

						
						
						while(iter1.hasNext()){
							
						
				       	iter1.next().toJSONPretty();
						 
					   
						}
						//System.out.println(fac+"\t "+items1.getAccumulatedItemCount());
						
						obj1.write(fac,items1.getAccumulatedItemCount(),currentDatestr,status);
						
						
						count=count+items1.getAccumulatedItemCount();
						
						
						
						
						}
										 
					 System.out.println("Total Active Facilities : "+items.getAccumulatedItemCount());
					}
				 catch(Exception e){
					 System.out.println(e.getMessage());
				 }
			
            //  System.out.print("Total Vital Counts : "+count);
			 
 		System.out.println("Done");
	
	 
	 
	 
	 
	 
	 }
	 
	 
	 
	
		public static   Date getYesterday(Date date) {
		    Calendar cal = Calendar.getInstance();

		    cal.setTime(date);
		    cal.add(Calendar.DATE, -1);
		    return cal.getTime();
		}
		

	
}

