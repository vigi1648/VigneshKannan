package com.amazonaws.samples;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	
//Date date=new Date();
  
   String i="1";
  
   Map < String, Object[] > empinfo =new TreeMap < String, Object[] >();

   {
	      empinfo.put( i, new Object[] { "FacilityID", "Vitalcounts" });

   }
   
	

	public void write(String fac, int accumulatedItemCount, String currentDatestr, String status) throws IOException {
		// TODO Auto-generated method stub
		

		 XSSFWorkbook workbook = new XSSFWorkbook();
	     XSSFSheet sheet = workbook.createSheet(" Reports");
	     
	 
	      
	     i=i+1;
	      empinfo.put( i, new Object[] { fac, accumulatedItemCount });
	      
	      
	      
	      
	     //Writing Excel
		    
 	     Set<String> keyset = empinfo.keySet(); 
         int rownum = 0; 
         for (String key : keyset) { 
            Row row = sheet.createRow(rownum++); 
             Object[] objArr = empinfo.get(key); 
             int cellnum = 0; 
             for (Object obj : objArr) { 
                 Cell cell = row.createCell(cellnum++); 
                 if (obj instanceof String) 
                     cell.setCellValue((String)obj); 
                 else if (obj instanceof Integer) 
                     cell.setCellValue((Integer)obj); 
             } 
         }
	
         int num = sheet.getLastRowNum(); 
         Row row = sheet.createRow(++num); 
         row.createCell(0).setCellValue("Total count:"); 
         row.createCell(1).setCellValue(VitalsInfo.count); 


       
	      //Saving excel
 	     FileOutputStream fos =new FileOutputStream(new File("D:\\kamesh\\New folder\\output1"+status+currentDatestr+".xlsx"));
	        workbook.write(fos);
	        workbook.close();
	        fos.close();
	
	 
		
	}


	

}
