package com.zsl.nrgetpatient.dto;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="PATIENTS_INFO_UAT")
public class PatientsInfo{

	public String LASTKEY;
	public List<PatientInfo> PATIENTLIST;

	public String getLASTKEY() {
		return LASTKEY;
	}
	public void setLASTKEY(String lASTKEY) {
		this.LASTKEY = lASTKEY;
	}
	public List<PatientInfo> getPATIENTLIST() {
		return PATIENTLIST;
	}
	public void setPATIENTLIST(List<PatientInfo> patientList) {
		this.PATIENTLIST = patientList;
	}
	
	
}
