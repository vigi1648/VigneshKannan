package com.zsl.nrgetpatient.dao;

import java.util.List;

import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.zsl.nrgetpatient.dto.PatientInfo;


public interface PatientInfoDAO {

	//public ItemCollection<QueryOutcome> getPatients(String sendingApplication,String sendingFacility);
	
	public List<PatientInfo> getPatients(String sendingApplication,String sendingFacility);
}
