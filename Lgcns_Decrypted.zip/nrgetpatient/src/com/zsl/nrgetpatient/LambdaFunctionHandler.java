package com.zsl.nrgetpatient;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.bouncycastle.crypto.CryptoException;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.DynamodbEvent;
import com.zsl.nrgetpatient.dto.PatientInfo;
import com.zsl.nrgetpatient.dto.PatientsInfo;
import com.zsl.nrgetpatient.service.PatientInfoService;
import com.zsl.nrgetpatient.serviceimpl.PatientInfoServiceImpl;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {

    @Override
    public Object handleRequest(Object input, Context context) {
    	PatientInfoService patientsService = new PatientInfoServiceImpl();
        Map<String,String> patientInfo = (LinkedHashMap<String, String>)input;
        String sendingApplication = patientInfo.get("SendingApplication");
        String sendingFacility = patientInfo.get("SendingFacility");
       PatientInfo patientMap = new PatientInfo();
       //patientsService.getPatients(patientInfo);
        //PatientsInfo patientsInfo = patientsService.getPatients(sendingApplication, sendingFacility);
    	try {
			return patientsService.getPatients(patientInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return patientMap;
    }
    
    
public static void main(String args[]) throws Exception{
	PatientInfoService patientsService = new PatientInfoServiceImpl();
	Map<String, String> patientInfo = new LinkedHashMap<String, String>();
	String sendingApplication = "LGCNS";
    String sendingFacility = "8000";
    
	patientInfo.put("sendingApplication", "LGCNS");
	patientInfo.put("sendingFacility", "8000");
    patientsService.getPatients(patientInfo);
    
    //PatientsInfo patientMap = patientInfoService.getPatients(sendingApplication,sendingFacility);
    //PatientsInfo patientsInfo = patientInfoService.getPatients(sendingApplication, sendingFacility);
}
}
