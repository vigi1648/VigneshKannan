package com.zsl.pccimages.service;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.imageio.ImageIO;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.crypto.CryptoException;
import org.json.JSONObject;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.S3Link;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.zsl.pccimages.dto.Paging;
import com.zsl.pccimages.util.BouncyCastleEngine;
import com.zsl.pccimages.dao.PatientsDAO;
import com.zsl.pccimages.dao.PatientsDAOImpl;
import com.zsl.pccimages.dto.Data;
import com.zsl.pccimages.dto.EMROperatorInfo;
import com.zsl.pccimages.dto.Errors;
import com.zsl.pccimages.dto.PatientDetails;
import com.zsl.pccimages.dto.Patients;
import com.zsl.pccimages.dto.PatientsError;
import com.zsl.pccimages.util.AWSAuthenticationUtil;
import com.zsl.pccimages.util.CommonUtil;
import com.zsl.pccimages.util.DynamoDBUtil;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.transfer.TransferProgress;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;

public class PatientsServiceImpl implements PatientsService {
	
	static final Logger logger = LogManager.getLogger(PatientsServiceImpl.class);
	
	private String dataKey;
	
	AWSCredentials awsCredentials = null;
	AmazonDynamoDBClient amazonDynamoDBClient = null;
	DynamoDB dynamoDB = null;
	
	
	//To multipart Upload
	 private  String boundary;
	    private static final String LINE_FEED = "\r\n";
	    private HttpURLConnection connection;
	    private String charset;
	    private OutputStream outputStream;
	    private PrintWriter writer;
	 
	    public PatientsServiceImpl(String requestURL, String charset,String authorization)
	            throws Exception {
	    	
	    //	String authorization = "Bearer "+"UDwLK6BkjR6UkB6pWjAoqu7YJEFy:3";
	    //	String authorization = "Bearer "+token;
	        this.charset = charset;
	         
	   
	  boundary = ""+System.currentTimeMillis();
	        URL url = new URL(requestURL);
	        connection = (HttpURLConnection) url.openConnection();
	        connection.setUseCaches(false);
	        connection.setDoOutput(true); 
	        connection.setDoInput(true);
	        connection.setRequestProperty("Content-Type",
	                "multipart/form-data; boundary=" + boundary);
	  
	        connection.setRequestProperty("Authorization", authorization);
	     
	        outputStream = connection.getOutputStream();
	        writer = new PrintWriter(new OutputStreamWriter(outputStream, charset),
	                true);
	    }




public PatientsServiceImpl() {
	// TODO Auto-generated constructor stub
}






public Object getPatients(Map<String, Object> userInfo) throws IOException, InterruptedException, CryptoException, Exception {
				logger.info("Entered into getPatient service");
		
		PatientsDAO patientsDAO = new PatientsDAOImpl();
		Data data = new Data();
		StringBuilder response = null;
		Patients patients = new Patients(); 
		
		EMROperatorInfo emrinfo = null;
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		List<PatientDetails> patientDetailsList = null;
		List<PatientDetails> patientDetailsList1 = null;
		Map<String, PatientDetails> patientInfo = null;
		Map<String, PatientDetails> pccpatientInfo = null;

		patientDetailsList = new ArrayList<PatientDetails>();
		patientInfo = new HashMap<String, PatientDetails>();
		pccpatientInfo = new HashMap<String, PatientDetails>();
		

		
		String emrOperator = (String) userInfo.get("emrOperator");
		String sendingFacility=(String) userInfo.get("facility");
		List<EMROperatorInfo> emrOperatorList = patientsDAO.getfacility(emrOperator,sendingFacility);
		
	/*	EMROperatorInfo facilitys=new EMROperatorInfo();
		facilitys=(EMROperatorInfo) patientsDAO.getfacility(emrOperator,sendingFacility);*/
		
		for(EMROperatorInfo facilityList : emrOperatorList){
			String[] facilityArray = facilityList.getFacility().split("\\.");
			String nrfacility = facilityList.getFacility();
//          String facility = facilityList.getFacility();
			
			String facility = facilityArray[0];
            String sendingApplication = facilityList.getEmrOperator();
            String orgId = facilityList.getOrigin();
			String accessToken = facilityList.getAccessToken();
            String accessTokenExpiresIn = facilityList.getAccexpiresIn().replace(".", "");
            long accessTokenExpiresL = Long.parseLong(accessTokenExpiresIn);
            String refereshToken = facilityList.getRefreshToken();
            String refereshTokenExpiresIn = facilityList.getRefexpiresIn().replace(".", "");
            long refereshTokenExpiresL = Long.parseLong(refereshTokenExpiresIn);
            logger.info("Entered into EMROperatorInfo Iterator" + facility);
            
            DateFormat converter = null;
            converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
            converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
            String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
            long currenttime = Long.parseLong(formatedDate);
            
            
            converter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            calendar=Calendar.getInstance();
            String dateTimeOfObservation = converter.format(calendar.getTime());
            
            
            String nrpatientId=(String) userInfo.get("nrPatientId");
 		   String charset = "UTF-8";
 	String bucketName="testdemo37";//CHANGE BEFORE RUNNING     
	String keyName ="PCC/PDF"+"/" +nrfacility +"/" +nrpatientId;


 	// String keyName="Pdf-converted.pdf";//CHANGE BEFORE RUNNING  it should be patient id
 	// String keyName=(String) userInfo.get("filePath");
 	 BufferedImage image = null;
 	/*String recordeddate = (String) userInfo.get("dateTimeOfObservation");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

		Date date1 = formatter.parse(recordeddate); */
	//	String dateTimeOfObservation = formatter.format(date1);


		List<PatientDetails>  patientList = patientsDAO.getPatient(nrfacility,sendingApplication,nrpatientId);
        for(PatientDetails patientDetail : patientList)
        {
        	dataKey = CommonUtil.getInstance().getDataKey();
       	 String patientId=patientDetail.getPatientId() != null && !patientDetail.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESDecryption(patientDetail.getPatientId(), dataKey) : null;

        if(accessTokenExpiresL >= currenttime)
        {
        	

  
		System.out.println("Before Calling time of getPatient API:" + currenttime);

		final String urlString="https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients/"+patientId+"/documents";
		System.out.println("PCC getPatient API Call URL" + urlString);
		System.out.println("After Calling time of getPatient API:" + currenttime);
		logger.info("URL String of GetPatient" + urlString);
    	String authorization = "Bearer "+accessToken;
    	
    try
    {
    	File file = new File("file.txt");
        file.createNewFile();  

    	JSONObject jsonobj   = new JSONObject();
    	jsonobj.put("documentName","report"+currenttime);
    	jsonobj.put("documentCategory","1");
    	jsonobj.put("effectiveDate",dateTimeOfObservation);// "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"  "2018-05-15T06:13:41.451Z"
    	
    	 FileWriter fileWriter = new FileWriter("file.txt");
    	    fileWriter.write(jsonobj.toString()); 
    	 
    	    fileWriter.flush();
           fileWriter.close();
           PatientsServiceImpl multipart = new PatientsServiceImpl(urlString, charset,authorization);

      	 multipart.addjson("metadata",file);
      	 
      	 awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
		 AWSCredentialsProvider s3CredentialProvider=new ProfileCredentialsProvider();
		 s3CredentialProvider.getCredentials();
			TransferManager xfer_mgr = new TransferManager(s3CredentialProvider);
			 String file_path="upload.pdf";
 		
 		File f = new File(file_path);
		//TransferManager xfer_mgr = TransferManagerBuilder.standard().build();
		  Download xfer = xfer_mgr.download(bucketName, keyName, f);
		   System.out.println(xfer.getProgress().toString());
		   xfer.waitForCompletion();
		 System.out.println(xfer.getState());
		/*image= ImageIO.read(f);
		   ImageIO.write(image, "png", f);*/
		
		
		  multipart.addFile("file", f);
		  response= multipart.finish();
		  
		  JSONObject myResponse = new JSONObject(response.toString());
		  result.put("DocumentId",myResponse.get("documentId"));
         // result.put("PatientID",userInfo.get("patientId").toString());
		  result.put("PatientID",patientId);
                    System.out.println(result);
		  
		  
		
           
    }  
		
    
            	
		catch(Exception e)
		{
			System.out.println(connection.getResponseCode());
			System.out.println(connection.getResponseMessage());
		result.put("ResponseCode", connection.getResponseCode());
		result.put("ResponseMessage", connection.getResponseMessage());
		
			e.printStackTrace();
			logger.info(e);
		}

        }
    			
        else if(refereshTokenExpiresL >= currenttime){
        	 emrinfo = AccessToken(refereshToken,refereshTokenExpiresIn);
             String newaccessToken = emrinfo.getAccess_token();
             String newaccessTokenExpiresIn = emrinfo.getExpires_in().replace(".","");
             long newaccessTokenExpiresL = Long.parseLong(newaccessTokenExpiresIn);
             String newrefereshTokenExpiresIn = emrinfo.getRefresh_expires_in().replace(".", "");
             long newrefereshTokenExpiresL = Long.parseLong(newrefereshTokenExpiresIn);
             EMROperatorInfo emrIn = updateemrInfo(emrinfo,facilityList);
             PatientsDAO patientDAO = new PatientsDAOImpl();
          // String updtdmsg = patientDAO.updateEmrInfo(emrIn);
      
             if(newaccessTokenExpiresL >= currenttime){
             	

            	  
         		System.out.println("Before Calling time of getPatient API:" + currenttime);

         		final String urlString="https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients/"+patientId+"/documents";
         		System.out.println("PCC getPatient API Call URL" + urlString);
         		System.out.println("After Calling time of getPatient API:" + currenttime);
         		logger.info("URL String of GetPatient" + urlString);
             	String authorization = "Bearer "+accessToken;
             	
             try
             {
             	File file = new File("file.txt");
                 file.createNewFile();  

             	JSONObject jsonobj   = new JSONObject();
             	jsonobj.put("documentName","report"+currenttime);
             	jsonobj.put("documentCategory","1");
             	jsonobj.put("effectiveDate",dateTimeOfObservation);// "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"  "2018-05-15T06:13:41.451Z"
             	
             	 FileWriter fileWriter = new FileWriter("file.txt");
             	    fileWriter.write(jsonobj.toString()); 
             	 
             	    fileWriter.flush();
                    fileWriter.close();
                    PatientsServiceImpl multipart = new PatientsServiceImpl(urlString, charset,authorization);

               	 multipart.addjson("metadata",file);
               	 
               	 awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
         		 AWSCredentialsProvider s3CredentialProvider=new ProfileCredentialsProvider();
         		 s3CredentialProvider.getCredentials();
         			TransferManager xfer_mgr = new TransferManager(s3CredentialProvider);
         			 String file_path="upload.pdf";
          		
          		File f = new File(file_path);
         		//TransferManager xfer_mgr = TransferManagerBuilder.standard().build();
         		  Download xfer = xfer_mgr.download(bucketName, keyName, f);
         		   System.out.println(xfer.getProgress().toString());
         		   xfer.waitForCompletion();
         		 System.out.println(xfer.getState());
         		/*image= ImageIO.read(f);
         		   ImageIO.write(image, "png", f);*/
         		
         		
         		  multipart.addFile("file", f);
         		  response= multipart.finish();
         		  
         		  JSONObject myResponse = new JSONObject(response.toString());
         		  result.put("DocumentId",myResponse.get("documentId"));
                  // result.put("PatientID",userInfo.get("patientId").toString());
         		  result.put("PatientID",patientId);
                             System.out.println(result);
         		  
         		  
         		
                    
             }  
         		
             
                     	
         		catch(Exception e)
         		{
         			System.out.println(connection.getResponseCode());
         			System.out.println(connection.getResponseMessage());
         		result.put("ResponseCode", connection.getResponseCode());
         		result.put("ResponseMessage", connection.getResponseMessage());
         		
         			e.printStackTrace();
         			logger.info(e);
         		}

                 } 
        
             else {
            	 logger.error("New Access token Expired");
             }
             
          
        }     
        else {
      			logger.error("Referesh token Expired");
      		}
           
                
     
		}
		}
		return result;
		}
	
	
	
	
	
	
	public EMROperatorInfo AccessToken(String refereshToken,String refereshTokenExpiresIn) throws MalformedURLException
	{
		EMROperatorInfo emrOperatorInfo = null;
		StringBuilder response = null;
		HttpURLConnection connection = null;
		
		DateFormat converter = null;
        converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
        converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
        long currenttime = Long.parseLong(formatedDate);
        
		System.out.println("Before Calling newAccessToken API time:"+ currenttime );
	// Demo getAccessToken URL :	
	//	final String URLstr = "https://5zexw2gi20.execute-api.us-east-1.amazonaws.com/poc/pcc-developer/get-token?code=&refresh_token="+refereshToken+"";
	// Prod  getAccessToken URL : 	
		String URLstr = "https://pccdeveloperapi.rosieconnect2.com/api/get-token?code=&refresh_token="+refereshToken+"";
		System.out.println("Calling newAccessToken API"+ URLstr );
		System.out.println("After Calling newAccessToken API time:"+ currenttime );
        try {
        final URL url = new URL(URLstr);
    	connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(HttpMethod.GET);
		connection.setDoOutput(true);
//		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
		
		if (connection.getInputStream() != null) {
			logger.info("Comes to InputStream");
            final InputStream inputStream = connection.getInputStream();
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            try {
                response = new StringBuilder();

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }
                JsonParser jsonParser = new JsonParser();
                String jsonObject = jsonParser.parse(response.toString()).toString();
                Gson gson = new Gson();
                emrOperatorInfo = gson.fromJson(jsonObject, EMROperatorInfo.class);
                
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
		}
    } catch (Exception e) {
    	InputStream errorstream = connection.getErrorStream();
    	if(errorstream != null)
    	{
    	BufferedReader br = null;
    	System.out.println("Comes to errorstream while try to get token");
        br = new BufferedReader(new InputStreamReader(errorstream));
        String response1 = "";
        String nachricht;
        try {
			while ((nachricht = br.readLine()) != null){
			    response1 += nachricht;
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        JsonParser jsonParserError = new JsonParser();
        String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
        Gson gsonError = new Gson();
        PatientsError patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
        String errDetail = null;
        for(Errors errors : patientsResponseError.getErrors()){
        	System.out.println("response1" + errors.getTitle());
        	System.out.println("response2" + errors.getDetail());
        	logger.error(errors.getDetail());
        	errDetail = errors.getDetail();
        	break;
        	
        }
    	}
        
        e.printStackTrace();
    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    }
		
		return emrOperatorInfo;
	}
	
	public EMROperatorInfo updateemrInfo(EMROperatorInfo emrinfo,EMROperatorInfo facilityList){
		
		EMROperatorInfo facility = new EMROperatorInfo();
		
		String facility1 = facilityList.getFacility();
		String emroperator1 = facilityList.getEmrOperator();
		PatientsDAO patientDAO = new PatientsDAOImpl();
		EMROperatorInfo emrinf = patientDAO.getEMRInfo(facility1,emroperator1);
		emrinf.setAccessToken(emrinfo.getAccess_token());
		emrinf.setAccexpiresIn(emrinfo.getExpires_in());
		return emrinf;
	}
	
	public void addjson(String fieldName, File uploadFile)
            throws Exception {
    	 String fileName = uploadFile.getName();
    	
    	
    	 System.out.println(URLConnection.guessContentTypeFromName(uploadFile.getName()));
    
         writer.append("--" + boundary).append(LINE_FEED);
         
         writer.append("Content-Disposition: form-data; name=" + fieldName+ "; filename=\"" + fileName).append(LINE_FEED);
         writer.append(
                 "Content-Type: application/json")
                 .append(LINE_FEED);
       
         writer.append("Content-Transfer-Encoding: binary").append(LINE_FEED);
         writer.append(LINE_FEED);
         writer.flush();
  
         FileInputStream inputStream = new FileInputStream(uploadFile);
         byte[] buffer = new byte[4096];
         int bytesRead = -1;
         while ((bytesRead = inputStream.read(buffer)) != -1) {
             outputStream.write(buffer, 0, bytesRead);
         }
         outputStream.flush();
         inputStream.close();
          
         writer.append(LINE_FEED);
         writer.flush();    
    }
	
	
	public void addFile(String fieldName, File uploadFile) throws Exception {
		 String fileName = uploadFile.getName();
	    	
	    	
    	 System.out.println(URLConnection.guessContentTypeFromName(uploadFile.getName()));
    
         writer.append("--" + boundary).append(LINE_FEED);
         
         writer.append("Content-Disposition: form-data; name=" + fieldName+ "; filename=\"" + fileName).append(LINE_FEED);
         writer.append(
                 "Content-Type: "
                         + URLConnection.guessContentTypeFromName(fileName))
                 .append(LINE_FEED);
     
         writer.append("Content-Transfer-Encoding: binary").append(LINE_FEED);
         writer.append(LINE_FEED);
         writer.flush();
  
         FileInputStream inputStream = new FileInputStream(uploadFile);
         byte[] buffer = new byte[4096];
         int bytesRead = -1;
         while ((bytesRead = inputStream.read(buffer)) != -1) {
             outputStream.write(buffer, 0, bytesRead);
         }
         outputStream.flush();
         inputStream.close();
          
         writer.append(LINE_FEED);
         writer.flush();    
		
		
		
	}
 
    public StringBuilder finish() throws Exception {
    
    	StringBuilder response1 = null;
 
        writer.append(LINE_FEED).flush();
        writer.append("--" + boundary + "--").append(LINE_FEED);
        writer.close();
 
       
        
     
        int status = connection.getResponseCode();
       String responsemsg= connection.getResponseMessage();
       System.out.println("Responsecode:"+status);
       System.out.println("Responsemessage:"+responsemsg);
       
   /*	if (httpConn.getErrorStream() != null) {
        final InputStream inputStream = httpConn.getErrorStream();
        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

        try {
            response1 = new StringBuilder();

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                response1.append(line);
            }
            
            JSONObject myResponse = new JSONObject(response1.toString());
            
            System.out.println("Reading JSON Response"+myResponse);
        }
        catch(Exception e) {
			e.printStackTrace();
		}
	}*/
       
	if (connection.getInputStream() != null) {

		logger.info("Comes to InputStream");
        final InputStream inputStream = connection.getInputStream();
        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        try {
        	response1 = new StringBuilder();

        String line;
        while ((line = bufferedReader.readLine()) != null) {
        	response1.append(line);
        }
      

     
 
        return response1;
        
    }
	catch(Exception e) {
		e.printStackTrace();
	}
}
	return response1;
    }
}