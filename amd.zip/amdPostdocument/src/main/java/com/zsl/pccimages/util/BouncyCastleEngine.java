package com.zsl.pccimages.util;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.paddings.BlockCipherPadding;
import org.bouncycastle.crypto.paddings.PKCS7Padding;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;


public class BouncyCastleEngine {

	private BlockCipher _blockCipher;
    private PaddedBufferedBlockCipher _cipher;
    private BlockCipherPadding _padding;
    
    public BouncyCastleEngine(BlockCipher blockCipher)
    {
        _blockCipher = blockCipher;
    }
    
    public void SetPadding(BlockCipherPadding padding)
    {
        if (padding != null)
            _padding = padding;
    }
    
    public String Encrypt(String plain, String key) throws UnsupportedEncodingException, CryptoException
    {
        byte[] result = BouncyCastleCrypto(true, plain.getBytes("UTF-8"), key);
        byte[]   bytesEncoded = Base64.getEncoder().encode(result);
        
        return new String(bytesEncoded);
    }
    
    public String Decrypt(String cipher, String dataKey) throws UnsupportedEncodingException, CryptoException
    {
        byte[] result = BouncyCastleCrypto(false, Base64.getDecoder().decode(cipher), dataKey);
        return new String(result);
    }
    
    private byte[] BouncyCastleCrypto(boolean forEncrypt, byte[] input, String key) throws UnsupportedEncodingException, CryptoException
    {
            _cipher = _padding == null ? new PaddedBufferedBlockCipher(_blockCipher) : new PaddedBufferedBlockCipher(_blockCipher, _padding);
            byte[] keyByte = key.getBytes("UTF-8");
            _cipher.init(forEncrypt, new KeyParameter(keyByte));
            byte[] cipherArray = new byte[_cipher.getOutputSize(input.length)];
            int outputByteCount = _cipher.processBytes(input, 0,
        			input.length, cipherArray, 0);
            
            outputByteCount += _cipher.doFinal(cipherArray, outputByteCount);
        	byte[] result = new byte[outputByteCount];
        	System.arraycopy(cipherArray, 0, result, 0, outputByteCount);
        	return result;
    }
    
    public static String AESEncryption(String plain, String key) throws UnsupportedEncodingException, CryptoException
    {
        BouncyCastleEngine bcEngine = new BouncyCastleEngine(new AESEngine());
        bcEngine.SetPadding(new PKCS7Padding());
        try {
        	return bcEngine.Encrypt(plain, key);
		} catch (UnsupportedEncodingException uee) {
			throw new RuntimeException(uee.getMessage(), uee);
		} catch (CryptoException ce) {
			throw new RuntimeException(ce.getMessage(), ce);
		}
    }
    
    public static String AESDecryption(String cipher, String dataKey) throws UnsupportedEncodingException, CryptoException
    {
        BouncyCastleEngine bcEngine = new BouncyCastleEngine(new AESEngine());
        bcEngine.SetPadding(new PKCS7Padding());
        try {
        	return bcEngine.Decrypt(cipher, dataKey);
		} catch (UnsupportedEncodingException uee) {
			throw new RuntimeException(uee.getMessage(), uee);
		} catch (CryptoException ce) {
			throw new RuntimeException(ce.getMessage(), ce);
		}
    }
}
