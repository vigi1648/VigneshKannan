package com.zsl.pccimages.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.bouncycastle.crypto.CryptoException;

import com.zsl.pccimages.dto.PatientDetails;

public interface PatientsService {

	public Object getPatients(Map<String, Object> userInfo) throws IOException,InterruptedException,CryptoException, Exception;
	
}
