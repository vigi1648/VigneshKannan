package com.zsl.pccimages.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.crypto.CryptoException;
import org.json.JSONArray;
import org.json.JSONObject;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.pccimages.controller.LambdaFunctionHandler;
import com.zsl.pccimages.service.PatientsService;
import com.zsl.pccimages.service.PatientsServiceImpl;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {
	static final Logger logger = LogManager.getLogger(LambdaFunctionHandler.class);
    @Override
    public Object handleRequest(Object input, Context context) {
    	System.out.println(" Enter Lambda Function Handler method");
    	logger.info("Info Message Logged !!!");
    	Map<String, Object> inputParams = (LinkedHashMap<String, Object>)input;
    	PatientsService patientsService = new PatientsServiceImpl();
    	Map<String, Object> userInfo = new LinkedHashMap<String, Object>();
    	userInfo.put("emrOperator", "PCCApp");
    	
    	
    	try {
    		return patientsService.getPatients(inputParams);
			//return patientsService.getPatients(userInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CryptoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
		return patientsService;
    }
    
    
    public static void main(String [] args) throws Exception{
    	
    	System.out.println("Main mathod");
    	PatientsService patientsService = new PatientsServiceImpl();
    	Map<String, Object> userInfo = new LinkedHashMap<String, Object>();
    	userInfo.put("facility", "12.1504955528");
    	userInfo.put("emrOperator", "PCCApp");
    	userInfo.put("accessToken", "3kVbEJQ3Ge8MOxQBDNBAJUX5mI2d:3");
    	//userInfo.put("filePath", "https://testdemo37.s3.amazonaws.com/Pdf-converted.pdf");
    	userInfo.put("nrPatientId", "42605dee-8913-470c-8039-8005e4f0ac75");
    	userInfo.put("dateTimeOfObservation","20190417054905.352");
      	patientsService.getPatients(userInfo);
        
        
        
        
        
        
        

       

        


    	
    	
    	
    	
    	
    
    }


}
