package com.zsl.pccimages.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.crypto.CryptoException;
import org.json.JSONArray;
import org.json.JSONObject;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.pccimages.controller.LambdaFunctionHandler;
import com.zsl.pccimages.service.PatientsService;
import com.zsl.pccimages.service.PatientsServiceImpl;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {
	static final Logger logger = LogManager.getLogger(LambdaFunctionHandler.class);
    @Override
    public Object handleRequest(Object input, Context context) {
    	System.out.println(" Enter Lambda Function Handler method");
    	logger.info("Info Message Logged !!!");
    	Map<String, Object> inputParams = (LinkedHashMap<String, Object>)input;
    	PatientsService patientsService = new PatientsServiceImpl();
    	Map<String, Object> userInfo = new LinkedHashMap<String, Object>();
    	userInfo.put("emrOperator", "PCCApp");
    	
    	try {
    		return patientsService.getPatients(inputParams);
			//return patientsService.getPatients(userInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CryptoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
		return userInfo;
    }
    
    
    public static void main(String [] args) throws Exception{
    	
    	System.out.println("Main mathod");
    	PatientsService patientsService = new PatientsServiceImpl();
    	
           JSONObject json = new JSONObject(); 
    	Map<String, Object> jo = new LinkedHashMap<String, Object>();
        List<Object> ja = new ArrayList();
  

        jo.put("customer", "1504955528");
        jo.put("accessToken", "GvrdHfL6WncvJPTgAnUiL8LcAO1G:3");
        jo.put("facility", "12.1504955528");
        jo.put("emrOperator", "PCCApp");
      jo.put("patientId", "6218"); 
        jo.put("effectiveDate", "2019-06-26T07:43:16.000Z");
        jo.put("noteType", "NoteType 5"); 
        jo.put("externalId", "22");
         
    /*    json.put("name", "Date of Service"); 
        json.put("value", "2019-06-02"); 
        ja.add(json);
        json = new JSONObject(); 
        json.put("name", "Visit Type Sample"); 
        json.put("value", "Visit Type value Sample"); 
        ja.add(json);
        json = new JSONObject(); 
        json.put("name", "Transition of Care"); 
        json.put("value", "Transition of Care value"); 
        ja.add(json);
        json = new JSONObject(); 
        json.put("name", "History Details"); 
        json.put("value", "History Details for this progress note"); 
        ja.add(json);
        json = new JSONObject(); 
        json.put("name", "Details"); 
        json.put("value", "Details this progress note."); 
        ja.add(json);
        json = new JSONObject(); 
        json.put("name", "Signed Date"); 
        json.put("value", "Date this progress note was signed by the provider. This is a string field and the date format is left to the calling partner."); 
        ja.add(json);
        json = new JSONObject(); */
        json.put("name", "Provider"); 
        json.put("value", "Provider Name who provided the service."); 
        ja.add(json);
        jo.put("sections", ja);
        System.out.println(jo);
      	patientsService.getPatients(jo);
        
        
        
        
        
        
        

       

        


    	
    	
    	
    	
    	
    
    }


}
