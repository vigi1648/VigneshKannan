package com.zsl.patientscron.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.zsl.patientscron.dto.PatientDetails;

public interface PatientsService {

	public Object getPatients(Map<String, String> userInfo) throws IOException,InterruptedException;
	
}
