package com.zsl.nregetvitalsreport.util;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;

public class DynamoDBUtil {
public static AmazonDynamoDBClient getAmazonDynamoDBClient(AWSCredentials awsCredentials){
		
        AmazonDynamoDBClient client = null;
        try {
              client = new AmazonDynamoDBClient(awsCredentials);
              // client = new AmazonDynamoDBClient();
        } catch (Exception e) {
               // TODO: handle exception
        }
        return client;
 }

 public static DynamoDB getAmazonDynamoDB(AmazonDynamoDBClient client){
        DynamoDB dynamoDB = null;
        try {
               dynamoDB = new DynamoDB(client);
        } catch (Exception e) {
               // TODO: handle exception
        }
        return dynamoDB;
 }

 public static Table getDynamoDBTable(DynamoDB dynamoDB, String tableName){
        Table table = null;
        try {
               table = dynamoDB.getTable(tableName);
        } catch (Exception e) {
               // TODO: handle exception
        }
        return table;
}
}
