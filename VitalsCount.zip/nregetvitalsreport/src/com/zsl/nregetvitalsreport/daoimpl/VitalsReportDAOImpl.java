package com.zsl.nregetvitalsreport.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.Select;
import com.zsl.nregetvitalsreport.dao.VitalsReportDAO;
import com.zsl.nregetvitalsreport.dto.Customer;
import com.zsl.nregetvitalsreport.dto.EMROperatorInfo;
import com.zsl.nregetvitalsreport.dto.VitalStats;
import com.zsl.nregetvitalsreport.util.AWSAuthenticationUtil;
import com.zsl.nregetvitalsreport.util.DynamoDBUtil;



public class VitalsReportDAOImpl implements VitalsReportDAO {
	
	AWSCredentials awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
	AmazonDynamoDBClient amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
	DynamoDBMapper mapper = new DynamoDBMapper(amazonDynamoDBClient);
	
	public List<Customer> getCustomer() {
	
		String isCustomer1 ="YES";
		 Map<String, AttributeValue> attributeValue = new HashMap<String, AttributeValue>();
		    attributeValue.put(":val1", new AttributeValue().withS(isCustomer1));
		
		DynamoDBQueryExpression<Customer> queryExpression = new DynamoDBQueryExpression<Customer>()
			    .withIndexName("ISCUSTOMER-index")
			    .withProjectionExpression("CUSTOMER, CUSTOMERNAME")
			    .withConsistentRead(false)
			    .withKeyConditionExpression("ISCUSTOMER = :val1")
			    .withExpressionAttributeValues(attributeValue);
	    
	    List<Customer> customerList =  mapper.query(Customer.class, queryExpression);
	    return customerList;
	}
	
	public List<EMROperatorInfo> getFacility(String getCustomer) {
		
		 Map<String, AttributeValue> attributeValue = new HashMap<String, AttributeValue>();
		    attributeValue.put(":val1", new AttributeValue().withS(getCustomer));
		
		DynamoDBQueryExpression<EMROperatorInfo> queryExpression = new DynamoDBQueryExpression<EMROperatorInfo>()
			    .withIndexName("CUSTOMER-index")
			    .withProjectionExpression("FACILITY, FACILITYNAME")
			    .withConsistentRead(false)
			    .withKeyConditionExpression("CUSTOMER = :val1")
			    .withExpressionAttributeValues(attributeValue);
	    
	    List<EMROperatorInfo> facilityList =  mapper.query(EMROperatorInfo.class, queryExpression);
	    return facilityList;
	}
	
	public int getVitalsReport(String dateTimeOfObservationFrom,String dateTimeOfObservationTo, String facility)
	{
		
		Map<String, AttributeValue> attributeValue = new HashMap<String, AttributeValue>();
	    attributeValue.put(":val1", new AttributeValue().withS(facility));
	    attributeValue.put(":val2", new AttributeValue().withS(dateTimeOfObservationFrom));
	    attributeValue.put(":val3", new AttributeValue().withS(dateTimeOfObservationTo));
	
	DynamoDBQueryExpression<VitalStats> queryExpression = new DynamoDBQueryExpression<VitalStats>()
		    .withIndexName("FACILITY-DATETIMEOFOBSERVATION-index")
		    .withConsistentRead(false)
		    .withKeyConditionExpression("FACILITY = :val1 and DATETIMEOFOBSERVATION between :val2 and :val3 ")
		    .withSelect(Select.COUNT)
		    .withExpressionAttributeValues(attributeValue);
    
    
       int customerList = mapper.count(VitalStats.class, queryExpression);
       return customerList;
	}

}
