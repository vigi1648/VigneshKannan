package com.zsl.nregetvitalsreport;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.nregetvitalsreport.dto.Customer;
import com.zsl.nregetvitalsreport.service.VitalsReportService;
import com.zsl.nregetvitalsreport.serviceimpl.VitalsReportServiceImpl;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {

   
    public Object handleRequest(Object input, Context context) {
       
        Map<String, String> vitalStatsInfo = (LinkedHashMap<String, String>)input; 
        //String facility = vitalStatsInfo.get("facility");
        String dateTimeOfObservationFrom = vitalStatsInfo.get("fromDate");
        String dateTimeOfObservationTo = vitalStatsInfo.get("toDate");
        VitalsReportService vitalsReportService = new VitalsReportServiceImpl();
        List<Customer> customerList = vitalsReportService.getVitalsReport(dateTimeOfObservationFrom,dateTimeOfObservationTo);
        return customerList;
 
    }

}
