package com.zsl.nregetvitalsreport.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="VITALSTATS")
public class VitalStats {
@DynamoDBHashKey(attributeName="MESSAGEID")	
private String messageid;
@DynamoDBAttribute(attributeName="ACKID")
private String ackid;
@DynamoDBAttribute(attributeName="ACKMESSAGE")
private String ackmessage;
//@DynamoDBAttribute(attributeName="DATETIMEOFOBSERVATION")
@DynamoDBIndexRangeKey(globalSecondaryIndexName="FACILITY-DATETIMEOFOBSERVATION-index",attributeName="DATETIMEOFOBSERVATION")
private String datetimeofobservation;
@DynamoDBAttribute(attributeName="DEVICEID")
private String deviceid;
@DynamoDBAttribute(attributeName="HL7MESSAGE")
private String hl7message;
@DynamoDBAttribute(attributeName="MEASUREMENTIDENTIFIER")
private String mesaurementidentifier;
@DynamoDBAttribute(attributeName="MEASUREMENTTEXT")
private String measurementtext;
@DynamoDBAttribute(attributeName="MESSAGECONTROLID")
private String messagecontrolid;
@DynamoDBAttribute(attributeName="NRPATIENTID")
private String nrpatientid;
@DynamoDBAttribute(attributeName="OBSERVATIONVALUE")
private String observationvalue;
@DynamoDBAttribute(attributeName="UNITSIDENTIFIER")
private String unitsidentifier;
@DynamoDBAttribute(attributeName="UNITSIDENTIFIERTEXT")
private String unitsidentifiertext;
@DynamoDBAttribute(attributeName="OBSERVATIONSITEIDENTIFIER")
private String observationidentifier;
@DynamoDBAttribute(attributeName="OBSERVATIONMETHODIDENTIFIER_0")
private String observationmethodidentifier_0;
@DynamoDBAttribute(attributeName="OBSERVATIONMETHODIDENTIFIER_1")
private String observationmethodidentifier_1;
@DynamoDBIndexHashKey(globalSecondaryIndexName="FACILITY-DATETIMEOFOBSERVATION-index",attributeName="Facility")
private String facility;
@DynamoDBAttribute(attributeName="EMROPERATOR")
private String emroperator;
@DynamoDBAttribute(attributeName="MACID")
private String macid;
@DynamoDBAttribute(attributeName="CUSTOMER")
private String customer;
@DynamoDBAttribute(attributeName="ISUPDATEDTOPCC")
private String isupdatedtopcc;



public String getMessageid() {
	return messageid;
}
public void setMessageid(String messageid) {
	this.messageid = messageid;
}
public String getAckid() {
	return ackid;
}
public void setAckid(String ackid) {
	this.ackid = ackid;
}
public String getAckmessage() {
	return ackmessage;
}
public void setAckmessage(String ackmessage) {
	this.ackmessage = ackmessage;
}
public String getDatetimeofobservation() {
	return datetimeofobservation;
}
public void setDatetimeofobservation(String datetimeofobservation) {
	this.datetimeofobservation = datetimeofobservation;
}
public String getDeviceid() {
	return deviceid;
}
public void setDeviceid(String deviceid) {
	this.deviceid = deviceid;
}
public String getHl7message() {
	return hl7message;
}
public void setHl7message(String hl7message) {
	this.hl7message = hl7message;
}
public String getMesaurementidentifier() {
	return mesaurementidentifier;
}
public void setMesaurementidentifier(String mesaurementidentifier) {
	this.mesaurementidentifier = mesaurementidentifier;
}
public String getMeasurementtext() {
	return measurementtext;
}
public void setMeasurementtext(String measurementtext) {
	this.measurementtext = measurementtext;
}
public String getMessagecontrolid() {
	return messagecontrolid;
}
public void setMessagecontrolid(String messagecontrolid) {
	this.messagecontrolid = messagecontrolid;
}
public String getNrpatientid() {
	return nrpatientid;
}
public void setNrpatientid(String nrpatientid) {
	this.nrpatientid = nrpatientid;
}
public String getObservationvalue() {
	return observationvalue;
}
public void setObservationvalue(String observationvalue) {
	this.observationvalue = observationvalue;
}
public String getUnitsidentifier() {
	return unitsidentifier;
}
public void setUnitsidentifier(String unitsidentifier) {
	this.unitsidentifier = unitsidentifier;
}
public String getUnitsidentifiertext() {
	return unitsidentifiertext;
}
public void setUnitsidentifiertext(String unitsidentifiertext) {
	this.unitsidentifiertext = unitsidentifiertext;
}
public String getObservationidentifier() {
	return observationidentifier;
}
public void setObservationidentifier(String observationidentifier) {
	this.observationidentifier = observationidentifier;
}
public String getObservationmethodidentifier_0() {
	return observationmethodidentifier_0;
}
public void setObservationmethodidentifier_0(
		String observationmethodidentifier_0) {
	this.observationmethodidentifier_0 = observationmethodidentifier_0;
}
public String getObservationmethodidentifier_1() {
	return observationmethodidentifier_1;
}
public void setObservationmethodidentifier_1(
		String observationmethodidentifier_1) {
	this.observationmethodidentifier_1 = observationmethodidentifier_1;
}
public String getFacility() {
	return facility;
}
public void setFacility(String facility) {
	this.facility = facility;
}
public String getEmroperator() {
	return emroperator;
}
public void setEmroperator(String emroperator) {
	this.emroperator = emroperator;
}
public String getMacid() {
	return macid;
}
public void setMacid(String macid) {
	this.macid = macid;
}
public String getCustomer() {
	return customer;
}
public void setCustomer(String customer) {
	this.customer = customer;
}
public String getIsupdatedtopcc() {
	return isupdatedtopcc;
}
public void setIsupdatedtopcc(String isupdatedtopcc) {
	this.isupdatedtopcc = isupdatedtopcc;
}

}
