package com.zsl.nregetvitalsreport.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="EMROPERATOR_INFO")
public class EMROperatorInfo {
	@DynamoDBHashKey(attributeName="FACILITY")	
	private String facility;
	@DynamoDBAttribute(attributeName="FACILITYNAME")
	private String facilityName;
	
	private Integer vitalsCount;
	
	public String getFacility() {
		return facility;
	}
	public void setFacility(String facility) {
		this.facility = facility;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public Integer getVitalsCount() {
		return vitalsCount;
	}
	public void setVitalsCount(Integer vitalsCount) {
		this.vitalsCount = vitalsCount;
	}
	
	
}
