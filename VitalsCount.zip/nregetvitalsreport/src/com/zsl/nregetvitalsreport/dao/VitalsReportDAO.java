package com.zsl.nregetvitalsreport.dao;

import java.util.List;

import com.zsl.nregetvitalsreport.dto.Customer;
import com.zsl.nregetvitalsreport.dto.EMROperatorInfo;

public interface VitalsReportDAO {
public int getVitalsReport(String dateTimeOfObservationFrom,String dateTimeOfObservationTo, String facility);
public List<Customer> getCustomer();
public List<EMROperatorInfo> getFacility(String getCustomer);
}
