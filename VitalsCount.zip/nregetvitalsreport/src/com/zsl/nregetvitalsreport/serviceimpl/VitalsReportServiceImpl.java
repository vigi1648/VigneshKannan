package com.zsl.nregetvitalsreport.serviceimpl;

import java.util.List;

import com.zsl.nregetvitalsreport.dao.VitalsReportDAO;
import com.zsl.nregetvitalsreport.daoimpl.VitalsReportDAOImpl;
import com.zsl.nregetvitalsreport.dto.Customer;
import com.zsl.nregetvitalsreport.dto.EMROperatorInfo;
import com.zsl.nregetvitalsreport.service.VitalsReportService;

public class VitalsReportServiceImpl implements VitalsReportService {
	
	public List<Customer> getVitalsReport(String dateTimeOfObservationFrom,String dateTimeOfObservationTo)
	{
		VitalsReportDAO vitalsReportDAO = new VitalsReportDAOImpl();
		
		List<Customer> customerList = vitalsReportDAO.getCustomer();
		
		for(Customer customer : customerList){
			List<EMROperatorInfo> facilityList = vitalsReportDAO.getFacility(customer.getCustomer());
			customer.setFacilityList(facilityList);
			for(EMROperatorInfo facility : facilityList){
				facility.setVitalsCount(vitalsReportDAO.getVitalsReport(dateTimeOfObservationFrom, dateTimeOfObservationTo, facility.getFacility()));
			}
		}
		return customerList;
	}
}