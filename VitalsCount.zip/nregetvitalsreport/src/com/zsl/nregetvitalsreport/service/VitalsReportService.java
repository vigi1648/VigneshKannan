package com.zsl.nregetvitalsreport.service;

import java.util.List;

import com.zsl.nregetvitalsreport.dto.Customer;

public interface VitalsReportService {
	
public List<Customer> getVitalsReport(String dateTimeOfObservationFrom,String dateTimeOfObservationTo);
}
