package com.zsl.applewatch.service;

import java.util.List;

import com.zsl.applewatch.dto.FitnessData;

public interface FitnessDataService {

	public String updateFitnessData(List<Object> fitnessDataList); 
}
