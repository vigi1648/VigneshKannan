package com.zsl.applewatch.dto;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
@DynamoDBTable(tableName="VITALSTATS_UAT")
public class HeartRate  {
	@DynamoDBAttribute(attributeName="HEARTVALUE")
public List<HeartRate> heartValue;
	@DynamoDBAttribute(attributeName="HEARTTIME")
private List<HeartRate> heartTime;
public List<HeartRate> getHeartValue() {
	return heartValue;
}
public void setHeartValue(List<HeartRate> heartValue) {
	this.heartValue = heartValue;
}
public List<HeartRate> getHeartTime() {
	return heartTime;
}
public void setHeartTime(List<HeartRate> heartTime) {
	this.heartTime = heartTime;
}


}
