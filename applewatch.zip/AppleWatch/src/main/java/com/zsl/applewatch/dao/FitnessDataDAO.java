package com.zsl.applewatch.dao;

import java.util.List;

import com.zsl.applewatch.dto.FitnessData;
import com.zsl.applewatch.dto.HeartRate;


public interface FitnessDataDAO {

	public String fitnessData(List<FitnessData> fitnessDetailsList);
	
	public void updateFitnessData(List<FitnessData> vitalInfo);

}
