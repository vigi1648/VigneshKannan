package com.zsl.mc.constants;

public class CommonConstants {

	public static final String  NOPATIENTSFOUND = "NOPATIENTSFOUND";
}
