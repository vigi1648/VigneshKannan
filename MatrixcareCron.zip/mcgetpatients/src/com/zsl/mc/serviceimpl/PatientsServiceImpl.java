package com.zsl.mc.serviceimpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.zsl.mc.dao.PatientDAO;
import com.zsl.mc.daoimpl.PatientDAOImpl;
import com.zsl.mc.dto.EMROperatorInfo;
import com.zsl.mc.dto.MDIAchieveAPIRequest;
import com.zsl.mc.dto.Message;
import com.zsl.mc.dto.PatientDetails;
import com.zsl.mc.dto.PatientInfo;
import com.zsl.mc.dto.RequestData;
import com.zsl.mc.dto.RequestParams;
import com.zsl.mc.service.PatientsService;
import com.zsl.mc.util.BouncyCastleEngine;
import com.zsl.mc.util.CommonUtil;


public class PatientsServiceImpl implements PatientsService {
    
	private String dataKey;
	
	//List<PatientDetails> PatientsListInfo= null;
	
	@Override
	public void getPatients(String emrOperator) throws Exception {
		String snapshotDate = "2017-03-17";
		
			PatientDAO patientDAO = new PatientDAOImpl();
		
			List<PatientDetails> patientlist = null;
			Map<String, PatientDetails> patientInfo = null;
			PatientDetails updatePatient = null;
			List<PatientDetails> updatedPatientList= null;
			List<PatientDetails> updatedPatientListInfo= null;
			List<PatientDetails> createdPatientListInfo= null;
			PatientDetails createPatients = null;
			PatientDetails updatePatients = null;
			
			patientInfo = new HashMap<String, PatientDetails>();
			updatedPatientList = new ArrayList<PatientDetails>();
			updatedPatientListInfo = new ArrayList<PatientDetails>();
			createdPatientListInfo = new ArrayList<PatientDetails>();
		
			List<EMROperatorInfo> emrOperatorList = patientDAO.getfacility(emrOperator);
			for(EMROperatorInfo facilityList : emrOperatorList){
				String facility = facilityList.getFacility();
				String facilityOid = "2.16.124.113611.6432.1.1."+facility;
				String facilityOID = facilityOid;
				String sendingApplication = facilityList.getEmrOperator();
/*				String facility = "4376";
				String sendingApplication = "MATRIXCARE";

				String facilityOID = "2.16.124.113611.6432.1.1.4376";*/
			    patientlist = patientDAO.getPatient(facility,sendingApplication);
			    for(PatientDetails patient : patientlist) {
					patientInfo.put(patient.getPatientId(), patient);
				}
			    
			    List<PatientDetails> patientDetailsList = getPatient(facilityOID,snapshotDate);
				for(PatientDetails matrixPatient : patientDetailsList) {
					updatePatient = patientInfo.get(matrixPatient.getPatientId());
					if(updatePatient != null){
						updatePatients = updatePatientDetails(updatePatient,matrixPatient);
						updatedPatientListInfo.add(updatePatients);
					}else {
						createPatients = createPatientDetails(matrixPatient);
						updatedPatientListInfo.add(createPatients);
					}	
					
					}
				List<FailedBatch> failedBatchList = patientDAO.savePatients(updatedPatientListInfo);
				if(!(failedBatchList.size() > 0)) {
					EMROperatorInfo emrList = updateFacility(facilityList);
					patientDAO.saveupdatedfacility(emrList);
				}else{
					throw new RuntimeException("ERROR OCCURED IN USERS CREATION");
				}
			
			}
		   
	}

private List<PatientDetails> getPatient(String facilityOID, String snapshotDate)throws Exception{
	
	    List<PatientDetails> patientDetailsList = null;
		String emrOperator="MATRIXCARE";
		//SSLContext sc = SSLContext.getInstance("SSL");
		SSLContext sc = SSLContext.getInstance("TLSv1.2");
	    sc.init(getKeyManagers(), new TrustManager[] { new X509TrustManager() {
			
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1)
					throws CertificateException{
				// TODO Auto-generated method stub
				
			}
		}}, new java.security.SecureRandom());
	    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	    // Create all-trusting host name verifier
	    HostnameVerifier allHostsValid = new HostnameVerifier() {
	        public boolean verify(String hostname, SSLSession session) {
	          return true;
	        }
	    };
	    // Install the all-trusting host verifier
	    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		HttpURLConnection httpUrlConnection = null;
		try {
		    
			CommonUtil commonUtil = CommonUtil.getInstance();
			httpUrlConnection = commonUtil.getHttpURLConnection();
			httpUrlConnection.setDoInput(true);
			httpUrlConnection.setDoOutput(true);
			httpUrlConnection.setRequestMethod("POST");
			httpUrlConnection.setRequestProperty("Content-type", "text/xml; charset=utf-8");
			httpUrlConnection.setRequestProperty("SOAPAction", "http://external.api.integration.mdiachieve.com/ApiServiceInterface/invoke");
			OutputStream out =  httpUrlConnection.getOutputStream();
			Writer wout = new OutputStreamWriter(out);
			String request = createRequest(facilityOID, snapshotDate);
			wout.write(request);
			wout.flush();
			wout.close();
			
			out.flush();
			out.close();
			System.out.println(httpUrlConnection.getResponseCode());
			System.out.println(httpUrlConnection.getResponseMessage());
			
			StringBuffer respbuf= new StringBuffer();
			BufferedReader in= null;
			String inputLine = null;
			DocumentBuilderFactory docFactory = commonUtil.getDocumentBuilderFactory();
			DocumentBuilder docBuilder = commonUtil.getDocumentBuilder(docFactory);
			Document doc = docBuilder.parse(httpUrlConnection.getInputStream());
			
			NodeList nodes = doc.getElementsByTagName("return");
			String line = nodes.item(0).getTextContent().trim()+"</PatientInfo>";
			String newLine = line.replaceFirst("<message>", "<PatientInfo><message>");
//			System.out.println(newLine);
			
//			DocumentBuilder docBuilder1 = CommonUtil.getDocumentBuilder(docFactory);
//			Document docNew = docBuilder1.parse(new InputSource(new StringReader(line)));
//		     //System.out.println("Name: " + getCharacterDataFromElement(line));
//			
//			Document doc2 = docBuilder1.newDocument();
//		     Element rootElement = docNew.createElement("PatientInfo");
//				doc2.appendChild(rootElement);
//				
//				Node copyNode = doc2.importNode(docNew.getFirstChild(), true);
//				rootElement.appendChild(copyNode);
//				System.out.println(rootElement);
//			System.out.println(nodes.item(0).getTextContent());
//			Node node = doc.getLastChild();
//			
//			String patientInfo = nodes.item(0).getTextContent().trim()+"<PatientInfo>";
			StringReader strreader = new StringReader(newLine);
			JAXBContext jaxbContext = JAXBContext.newInstance(PatientInfo.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			PatientInfo patientInfo1 = (PatientInfo)jaxbUnmarshaller.unmarshal(strreader);
			 patientDetailsList = new ArrayList<PatientDetails>();
			for(Message message : patientInfo1.getMessage()){
				patientDetailsList.add(addPatientDetails(message));
			}
			
		} catch (ProtocolException pe) {
			throw new RuntimeException(pe.getMessage(),pe);
		} catch (IOException ioe){
			System.out.println(ioe);
			
		} catch (Exception e){
			e.getStackTrace();
		}
		return patientDetailsList;
}
	
	private String createRequest(String facilityOID, String snapshotDate){
		
		DocumentBuilderFactory docFactory = CommonUtil.getInstance().getDocumentBuilderFactory();
		DocumentBuilder docBuilder = CommonUtil.getInstance().getDocumentBuilder(docFactory);
		Document doc = docBuilder.newDocument();
		
		Element rootElement = doc.createElementNS("http://schemas.xmlsoap.org/soap/envelope/", "soapenv:Envelope");
		doc.appendChild(rootElement);
		
		Element body = doc.createElement("soapenv:Body");
		rootElement.appendChild(body);
		
		Element invoke = doc.createElementNS("http://external.api.integration.mdiachieve.com/", "ext:invoke");
		body.appendChild(invoke);
		
		Element requestData = doc.createElement("requestData");
		invoke.appendChild(requestData);
		
		CDATASection cdata = doc.createCDATASection(createData(facilityOID, snapshotDate));
		requestData.appendChild(cdata);
		
		TransformerFactory transformerFactory = CommonUtil.getTransformerFactory();
		Transformer transformer = CommonUtil.getTransformer(transformerFactory);
		DOMSource source = new DOMSource(doc);
		
		StreamResult streamResult = new StreamResult(new StringWriter());
		try {
			transformer.transform(source, streamResult);
		} catch (TransformerException tfe) {
			// TODO: handle exception
		}
		
		return streamResult.getWriter().toString();
		
	}
	
	private String createData(String facilityOID, String snapshotDate){
		StreamResult streamResult = null;
		MDIAchieveAPIRequest mdiAchieveAPIRequest = new MDIAchieveAPIRequest();
		mdiAchieveAPIRequest.setVersion("1.0");
		RequestData requestData = new RequestData();
		
		requestData.setRequestType("Census.CensusSnapshot.Export");
		
		RequestParams requestParams = new RequestParams();
		requestParams.setSnapshotDate(snapshotDate);
		requestParams.setFacilityOID(facilityOID);
		requestData.setRequestParams(requestParams);
		mdiAchieveAPIRequest.setRequestData(requestData);
		try{
			JAXBContext jaxbContext = JAXBContext.newInstance(MDIAchieveAPIRequest.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			streamResult = new StreamResult(new StringWriter());
			jaxbMarshaller.marshal(mdiAchieveAPIRequest, streamResult);
			
		}catch(JAXBException jaxbe) {
			
		}
		return streamResult.getWriter().toString();
	}

	private static KeyManager[] getKeyManagers() throws Exception {
	    InputStream keyStoreInput = Class.forName("com.zsl.mc.serviceimpl.PatientsServiceImpl").getResourceAsStream("nurserosie.p12");
	    KeyStore keyStore = KeyStore.getInstance("PKCS12");
	    keyStore.load(keyStoreInput, "ros123ie".toCharArray());
	    KeyManagerFactory kmfactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	    kmfactory.init(keyStore, "ros123ie".toCharArray());
	    return kmfactory.getKeyManagers();
	}
	
	private PatientDetails addPatientDetails(Message message){
		
		dataKey = CommonUtil.getInstance().getDataKey();
		
		PatientDetails patientDetails = new PatientDetails();
		
		patientDetails.setPatientId(message.getCensusSnapshotVo().getPatientID() != null && !message.getCensusSnapshotVo().getPatientID().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(message.getCensusSnapshotVo().getPatientID(), dataKey) : null);
		
		String firstName = CommonUtil.getInstance().getFirstNameFromFullName(message.getCensusSnapshotVo().getFullName());
		String lastName = CommonUtil.getInstance().getLastNameFromFullName(message.getCensusSnapshotVo().getFullName());
		patientDetails.setGivenName(firstName != null && !firstName.trim().isEmpty() ? BouncyCastleEngine.AESEncryption(firstName, dataKey) : null);
		patientDetails.setFamilyName(lastName != null && !lastName.trim().isEmpty() ? BouncyCastleEngine.AESEncryption(lastName, dataKey) : null);
		patientDetails.setAdmitDateOrTime(message.getCensusSnapshotVo().getAdmitDate());
		patientDetails.setSendingApplication("MATRIXCARE");
		patientDetails.setReceivingApplication("NR");
		patientDetails.setSendingFacility(message.getCensusSnapshotVo().getFacilityID());
		patientDetails.setReceivingFacility("NURSEROSIE_ADT");
		patientDetails.setAssignedPatientLocationBed(message.getCensusSnapshotVo().getBed());
		patientDetails.setAssignedPatientLocationRoom(message.getCensusSnapshotVo().getRoom());
		patientDetails.setAssignedPatientLocationBuilding(message.getCensusSnapshotVo().getBuilding());
		if(message.getCensusSnapshotVo().getLastStatus().equals("In House")){
		patientDetails.setPatientStatus("ACTIVE");
		}else{
		patientDetails.setPatientStatus("INACTIVE");
		}
		return patientDetails;
	}
	
	private PatientDetails createPatientDetails(PatientDetails matrixPatient){
		try {
		
		    PatientDetails addPatient = new PatientDetails();
		     
		    if(((PatientDetails) matrixPatient).getPatientId() != null && !((PatientDetails) matrixPatient).getPatientId().equals("")) {
		    	addPatient.setPatientId(((PatientDetails) matrixPatient).getPatientId());
			}
		    if(((PatientDetails) matrixPatient).getClientId() != null && !((PatientDetails) matrixPatient).getClientId().equals("")) {
		    	addPatient.setClientId(((PatientDetails) matrixPatient).getClientId());
			}
			if(((PatientDetails) matrixPatient).getAddress() != null && !((PatientDetails) matrixPatient).getAddress().equals("")) {
				addPatient.setAddress(((PatientDetails) matrixPatient).getAddress());
			}
			if(((PatientDetails) matrixPatient).getAdministrativeSex() != null && !((PatientDetails) matrixPatient).getAdministrativeSex().equals("")) {
				addPatient.setAdministrativeSex(((PatientDetails) matrixPatient).getAdministrativeSex());
		    }
		    if(((PatientDetails) matrixPatient).getAdmitDateOrTime() != null && !((PatientDetails) matrixPatient).getAdmitDateOrTime().equals("")) {
		    	addPatient.setAdmitDateOrTime(((PatientDetails) matrixPatient).getAdmitDateOrTime());
		    }
		    if(((PatientDetails) matrixPatient).getAssignedPatientLocationBed() != null && !((PatientDetails) matrixPatient).getAssignedPatientLocationBed().equals("")) {
		    	addPatient.setAssignedPatientLocationBed(((PatientDetails) matrixPatient).getAssignedPatientLocationBed());
		    }
		    if(((PatientDetails) matrixPatient).getAssignedPatientLocationBuilding() != null && !((PatientDetails) matrixPatient).getAssignedPatientLocationBuilding().equals("")) {
		    	addPatient.setAssignedPatientLocationBuilding(((PatientDetails) matrixPatient).getAssignedPatientLocationBuilding());
		    }
		    if(((PatientDetails) matrixPatient).getAssignedPatientLocationFloor() != null && !((PatientDetails) matrixPatient).getAssignedPatientLocationFloor().equals("")) {
		    	addPatient.setAssignedPatientLocationFloor(((PatientDetails) matrixPatient).getAssignedPatientLocationFloor());
		    }
		    if(((PatientDetails) matrixPatient).getAssignedPatientLocationPersonLocationType() != null && !((PatientDetails) matrixPatient).getAssignedPatientLocationPersonLocationType().equals("")) {
		    	addPatient.setAssignedPatientLocationPersonLocationType(((PatientDetails) matrixPatient).getAssignedPatientLocationPersonLocationType());
		    }
		    if(((PatientDetails) matrixPatient).getAssignedPatientLocationPointOfCare() != null && !((PatientDetails) matrixPatient).getAssignedPatientLocationPointOfCare().equals("")) {
		    	addPatient.setAssignedPatientLocationPointOfCare(((PatientDetails) matrixPatient).getAssignedPatientLocationPointOfCare());
		    }
		    if(((PatientDetails) matrixPatient).getAssignedPatientLocationRoom() != null && !((PatientDetails) matrixPatient).getAssignedPatientLocationRoom().equals("")) {
		    	addPatient.setAssignedPatientLocationRoom(((PatientDetails) matrixPatient).getAssignedPatientLocationRoom());
		    }
		    if(((PatientDetails) matrixPatient).getAttendingDoctor() != null && !((PatientDetails) matrixPatient).getAttendingDoctor().equals("")) {
		    	addPatient.setAttendingDoctor(((PatientDetails) matrixPatient).getAttendingDoctor());
		    }
		    if(((PatientDetails) matrixPatient).getBedStatus() != null && !((PatientDetails) matrixPatient).getBedStatus().equals("")) {
		    	addPatient.setBedStatus(((PatientDetails) matrixPatient).getBedStatus());
		    }
		    if(((PatientDetails) matrixPatient).getCreatedOn() != null && !((PatientDetails) matrixPatient).getCreatedOn().equals("")) {
		    	addPatient.setCreatedOn(((PatientDetails) matrixPatient).getCreatedOn());
		    }
		    if(((PatientDetails) matrixPatient).getDataOrTimeOfMessage() != null && !((PatientDetails) matrixPatient).getDataOrTimeOfMessage().equals("")) {
		    	addPatient.setDataOrTimeOfMessage(((PatientDetails) matrixPatient).getDataOrTimeOfMessage());
		    }
		    if(((PatientDetails) matrixPatient).getDischargeDateOrTime() != null && !((PatientDetails) matrixPatient).getDischargeDateOrTime().equals("")) {
		    	addPatient.setDischargeDateOrTime(((PatientDetails) matrixPatient).getDischargeDateOrTime());
		    }
		    if(((PatientDetails) matrixPatient).getDob() != null && !((PatientDetails) matrixPatient).getDob().equals("")) {
		    	addPatient.setDob(((PatientDetails) matrixPatient).getDob());
		    }
		    if(((PatientDetails) matrixPatient).getEventOccuredTime() != null && !((PatientDetails) matrixPatient).getEventOccuredTime().equals("")) {
		    	addPatient.setEventOccuredTime(((PatientDetails) matrixPatient).getEventOccuredTime());
		    }
		    if(((PatientDetails) matrixPatient).getFamilyName() != null && !((PatientDetails) matrixPatient).getFamilyName().equals("")) {
		    	addPatient.setFamilyName(((PatientDetails) matrixPatient).getFamilyName());
		    }
		    if(((PatientDetails) matrixPatient).getGivenName() != null && !((PatientDetails) matrixPatient).getGivenName().equals("")) {
		    	addPatient.setGivenName(((PatientDetails) matrixPatient).getGivenName());
		    }
		    if(((PatientDetails) matrixPatient).getImageUrl() != null && !((PatientDetails) matrixPatient).getImageUrl().equals("")) {
		    	addPatient.setImageUrl(((PatientDetails) matrixPatient).getImageUrl());
		    }
		    if(((PatientDetails) matrixPatient).getLastModifiedOn() != null && !((PatientDetails) matrixPatient).getLastModifiedOn().equals("")) {
		    	addPatient.setLastModifiedOn(((PatientDetails) matrixPatient).getLastModifiedOn());
		    }
		    if(((PatientDetails) matrixPatient).getMaritalStatus() != null && !((PatientDetails) matrixPatient).getMaritalStatus().equals("")) {
		    	addPatient.setMaritalStatus(((PatientDetails) matrixPatient).getMaritalStatus());
		    }
		    if(((PatientDetails) matrixPatient).getOperatorId() != null && !((PatientDetails) matrixPatient).getOperatorId().equals("")) {
		    	addPatient.setOperatorId(((PatientDetails) matrixPatient).getOperatorId());
		    }
		    if(((PatientDetails) matrixPatient).getPatientAddressCountry() != null && !((PatientDetails) matrixPatient).getPatientAddressCountry().equals("")) {
		    	addPatient.setPatientAddressCountry(((PatientDetails) matrixPatient).getPatientAddressCountry());
		    }
		    if(((PatientDetails) matrixPatient).getPatientAddressState() != null && !((PatientDetails) matrixPatient).getPatientAddressState().equals("")) {
		    	addPatient.setPatientAddressState(((PatientDetails) matrixPatient).getPatientAddressState());
		    }
		    if(((PatientDetails) matrixPatient).getPatientAdressCity() != null && !((PatientDetails) matrixPatient).getPatientAdressCity().equals("")) {
		    	addPatient.setPatientAdressCity(((PatientDetails) matrixPatient).getPatientAdressCity());
		    }
		    if(((PatientDetails) matrixPatient).getPatientPhoneNumber() != null && !((PatientDetails) matrixPatient).getPatientPhoneNumber().equals("")) {
		    	addPatient.setPatientPhoneNumber(((PatientDetails) matrixPatient).getPatientPhoneNumber());
		    }
		    if(((PatientDetails) matrixPatient).getPatientSSNNumber() != null && !((PatientDetails) matrixPatient).getPatientSSNNumber().equals("")) {
		    	addPatient.setPatientSSNNumber(((PatientDetails) matrixPatient).getPatientSSNNumber());
		    }
		    if(((PatientDetails) matrixPatient).getPatientStatus() != null && !((PatientDetails) matrixPatient).getPatientStatus().equals("")) {
		    	addPatient.setPatientStatus(((PatientDetails) matrixPatient).getPatientStatus());
		    }
		    if(((PatientDetails) matrixPatient).getPatientStreetAddress() != null && !((PatientDetails) matrixPatient).getPatientStreetAddress().equals("")) {
		    	addPatient.setPatientStreetAddress(((PatientDetails) matrixPatient).getPatientStreetAddress());
		    }
		    if(((PatientDetails) matrixPatient).getPriorPatientLocationBed() != null && !((PatientDetails) matrixPatient).getPriorPatientLocationBed().equals("")) {
		    	addPatient.setPriorPatientLocationBed(((PatientDetails) matrixPatient).getPriorPatientLocationBed());
		    }
		    if(((PatientDetails) matrixPatient).getPriorPatientLocationBuilding() != null && !((PatientDetails) matrixPatient).getPriorPatientLocationBuilding().equals("")) {
		    	addPatient.setPriorPatientLocationBuilding(((PatientDetails) matrixPatient).getPriorPatientLocationBuilding());
		    }
		    if(((PatientDetails) matrixPatient).getPriorPatientLocationFacility() != null && !((PatientDetails) matrixPatient).getPriorPatientLocationFacility().equals("")) {
		    	addPatient.setPriorPatientLocationFacility(((PatientDetails) matrixPatient).getPriorPatientLocationFacility());
		    }
		    if(((PatientDetails) matrixPatient).getPriorPatientLocationFloor() != null && !((PatientDetails) matrixPatient).getPriorPatientLocationFloor().equals("")) {
		    	addPatient.setPriorPatientLocationFloor(((PatientDetails) matrixPatient).getPriorPatientLocationFloor());
		    }
		    if(((PatientDetails) matrixPatient).getPriorPatientLocationPersonLocationType() != null && !((PatientDetails) matrixPatient).getPriorPatientLocationPersonLocationType().equals("")) {
		    	addPatient.setPriorPatientLocationPersonLocationType(((PatientDetails) matrixPatient).getPriorPatientLocationPersonLocationType());
		    }
		    if(((PatientDetails) matrixPatient).getPriorPatientLocationPointOfCare() != null && !((PatientDetails) matrixPatient).getPriorPatientLocationPointOfCare().equals("")) {
		    	addPatient.setPriorPatientLocationPointOfCare(((PatientDetails) matrixPatient).getPriorPatientLocationPointOfCare());
		    }
		    if(((PatientDetails) matrixPatient).getPriorPatientLocationRoom() != null && !((PatientDetails) matrixPatient).getPriorPatientLocationRoom().equals("")) {
		    	addPatient.setPriorPatientLocationRoom(((PatientDetails) matrixPatient).getPriorPatientLocationRoom());
		    }
		    if(((PatientDetails) matrixPatient).getReceivingApplication() != null && !((PatientDetails) matrixPatient).getReceivingApplication().equals("")) {
		    	addPatient.setReceivingApplication(((PatientDetails) matrixPatient).getReceivingApplication());
		    }
		    if(((PatientDetails) matrixPatient).getReceivingFacility() != null && !((PatientDetails) matrixPatient).getReceivingFacility().equals("")) {
		    	addPatient.setReceivingFacility(((PatientDetails) matrixPatient).getReceivingFacility());
		    }
		    if(((PatientDetails) matrixPatient).getReligion() != null && !((PatientDetails) matrixPatient).getReligion().equals("")) {
		    	addPatient.setReligion(((PatientDetails) matrixPatient).getReligion());
		    }
		    if(((PatientDetails) matrixPatient).getSendingApplication() != null && !((PatientDetails) matrixPatient).getSendingApplication().equals("")) {
		    	addPatient.setSendingApplication(((PatientDetails) matrixPatient).getSendingApplication());
		    }
		    if(((PatientDetails) matrixPatient).getSendingFacility() != null && !((PatientDetails) matrixPatient).getSendingFacility().equals("")) {
		    	addPatient.setSendingFacility(((PatientDetails) matrixPatient).getSendingFacility());
		    }
		    if(((PatientDetails) matrixPatient).getZipCode()!= null && !((PatientDetails) matrixPatient).getZipCode().equals("")) {
		    	addPatient.setZipCode(((PatientDetails) matrixPatient).getZipCode());
		    }
		    
		
		    return addPatient;
		
		}catch(Exception e){
			throw new RuntimeException(e.getMessage(),e);
		}
	}
	
	private PatientDetails updatePatientDetails(PatientDetails updatePatient,PatientDetails matrixPatient){
		try {
				
		if(matrixPatient.getPatientId() != null && !matrixPatient.getPatientId().equals("")) {
			updatePatient.setPatientId(matrixPatient.getPatientId());
		}
		if(matrixPatient.getClientId() != null && !matrixPatient.getClientId().equals("")) {
			updatePatient.setClientId(matrixPatient.getClientId());
		}
		if(matrixPatient.getAddress() != null && !matrixPatient.getAddress().equals("")) {
			updatePatient.setAddress(matrixPatient.getAddress());
		}
		if(matrixPatient.getAdministrativeSex() != null && !matrixPatient.getAdministrativeSex().equals("")) {
			updatePatient.setAdministrativeSex(matrixPatient.getAdministrativeSex());
	    }
	    if(matrixPatient.getAdmitDateOrTime() != null && !matrixPatient.getAdmitDateOrTime().equals("")) {
	    	updatePatient.setAdmitDateOrTime(matrixPatient.getAdmitDateOrTime());
	    }
	    if(matrixPatient.getAssignedPatientLocationBed() != null && !matrixPatient.getAssignedPatientLocationBed().equals("")) {
	    	updatePatient.setAssignedPatientLocationBed(matrixPatient.getAssignedPatientLocationBed());
	    }
	    if(matrixPatient.getAssignedPatientLocationBuilding() != null && !matrixPatient.getAssignedPatientLocationBuilding().equals("")) {
	    	updatePatient.setAssignedPatientLocationBuilding(matrixPatient.getAssignedPatientLocationBuilding());
	    }
	    if(matrixPatient.getAssignedPatientLocationFloor() != null && !matrixPatient.getAssignedPatientLocationFloor().equals("")) {
	    	updatePatient.setAssignedPatientLocationFloor(matrixPatient.getAssignedPatientLocationFloor());
	    }
	    if(matrixPatient.getAssignedPatientLocationPersonLocationType() != null && !matrixPatient.getAssignedPatientLocationPersonLocationType().equals("")) {
	    	updatePatient.setAssignedPatientLocationPersonLocationType(matrixPatient.getAssignedPatientLocationPersonLocationType());
	    }
	    if(matrixPatient.getAssignedPatientLocationPointOfCare() != null && !matrixPatient.getAssignedPatientLocationPointOfCare().equals("")) {
	    	updatePatient.setAssignedPatientLocationPointOfCare(matrixPatient.getAssignedPatientLocationPointOfCare());
	    }
	    if(matrixPatient.getAssignedPatientLocationRoom() != null && !matrixPatient.getAssignedPatientLocationRoom().equals("")) {
	    	updatePatient.setAssignedPatientLocationRoom(matrixPatient.getAssignedPatientLocationRoom());
	    }
	    if(matrixPatient.getAttendingDoctor() != null && !matrixPatient.getAttendingDoctor().equals("")) {
	    	updatePatient.setAttendingDoctor(matrixPatient.getAttendingDoctor());
	    }
	    if(matrixPatient.getBedStatus() != null && !matrixPatient.getBedStatus().equals("")) {
	    	updatePatient.setBedStatus(matrixPatient.getBedStatus());
	    }
	    if(matrixPatient.getCreatedOn() != null && !matrixPatient.getCreatedOn().equals("")) {
	    	updatePatient.setCreatedOn(matrixPatient.getCreatedOn());
	    }
	    if(matrixPatient.getDataOrTimeOfMessage() != null && !matrixPatient.getDataOrTimeOfMessage().equals("")) {
	    	updatePatient.setDataOrTimeOfMessage(matrixPatient.getDataOrTimeOfMessage());
	    }
	    if(matrixPatient.getDischargeDateOrTime() != null && !matrixPatient.getDischargeDateOrTime().equals("")) {
	    	updatePatient.setDischargeDateOrTime(matrixPatient.getDischargeDateOrTime());
	    }
	    if(matrixPatient.getDob() != null && !matrixPatient.getDob().equals("")) {
	    	updatePatient.setDob(matrixPatient.getDob());
	    }
	    if(matrixPatient.getEventOccuredTime() != null && !matrixPatient.getEventOccuredTime().equals("")) {
	    	updatePatient.setEventOccuredTime(matrixPatient.getEventOccuredTime());
	    }
	    if(matrixPatient.getFamilyName() != null && !matrixPatient.getFamilyName().equals("")) {
	    	updatePatient.setFamilyName(matrixPatient.getFamilyName());
	    }
	    if(matrixPatient.getGivenName() != null && !matrixPatient.getGivenName().equals("")) {
	    	updatePatient.setGivenName(matrixPatient.getGivenName());
	    }
	    if(matrixPatient.getImageUrl() != null && !matrixPatient.getImageUrl().equals("")) {
	    	updatePatient.setImageUrl(matrixPatient.getImageUrl());
	    }
	    if(matrixPatient.getLastModifiedOn() != null && !matrixPatient.getLastModifiedOn().equals("")) {
	    	updatePatient.setLastModifiedOn(matrixPatient.getLastModifiedOn());
	    }
	    if(matrixPatient.getMaritalStatus() != null && !matrixPatient.getMaritalStatus().equals("")) {
	    	updatePatient.setMaritalStatus(matrixPatient.getMaritalStatus());
	    }
	    if(matrixPatient.getOperatorId() != null && !matrixPatient.getOperatorId().equals("")) {
	    	updatePatient.setOperatorId(matrixPatient.getOperatorId());
	    }
	    if(matrixPatient.getPatientAddressCountry() != null && !matrixPatient.getPatientAddressCountry().equals("")) {
	    	updatePatient.setPatientAddressCountry(matrixPatient.getPatientAddressCountry());
	    }
	    if(matrixPatient.getPatientAddressState() != null && !matrixPatient.getPatientAddressState().equals("")) {
	    	updatePatient.setPatientAddressState(matrixPatient.getPatientAddressState());
	    }
	    if(matrixPatient.getPatientAdressCity() != null && !matrixPatient.getPatientAdressCity().equals("")) {
	    	updatePatient.setPatientAdressCity(matrixPatient.getPatientAdressCity());
	    }
	    if(matrixPatient.getPatientPhoneNumber() != null && !matrixPatient.getPatientPhoneNumber().equals("")) {
	    	updatePatient.setPatientPhoneNumber(matrixPatient.getPatientPhoneNumber());
	    }
	    if(matrixPatient.getPatientSSNNumber() != null && !matrixPatient.getPatientSSNNumber().equals("")) {
	    	updatePatient.setPatientSSNNumber(matrixPatient.getPatientSSNNumber());
	    }
	    if(matrixPatient.getPatientStatus() != null && !matrixPatient.getPatientStatus().equals("")) {
	    	updatePatient.setPatientStatus(matrixPatient.getPatientStatus());
	    }
	    if(matrixPatient.getPatientStreetAddress() != null && !matrixPatient.getPatientStreetAddress().equals("")) {
	    	updatePatient.setPatientStreetAddress(matrixPatient.getPatientStreetAddress());
	    }
	    if(matrixPatient.getPriorPatientLocationBed() != null && !matrixPatient.getPriorPatientLocationBed().equals("")) {
	    	updatePatient.setPriorPatientLocationBed(matrixPatient.getPriorPatientLocationBed());
	    }
	    if(matrixPatient.getPriorPatientLocationBuilding() != null && !matrixPatient.getPriorPatientLocationBuilding().equals("")) {
	    	updatePatient.setPriorPatientLocationBuilding(matrixPatient.getPriorPatientLocationBuilding());
	    }
	    if(matrixPatient.getPriorPatientLocationFacility() != null && !matrixPatient.getPriorPatientLocationFacility().equals("")) {
	    	updatePatient.setPriorPatientLocationFacility(matrixPatient.getPriorPatientLocationFacility());
	    }
	    if(matrixPatient.getPriorPatientLocationFloor() != null && !matrixPatient.getPriorPatientLocationFloor().equals("")) {
	    	updatePatient.setPriorPatientLocationFloor(matrixPatient.getPriorPatientLocationFloor());
	    }
	    if(matrixPatient.getPriorPatientLocationPersonLocationType() != null && !matrixPatient.getPriorPatientLocationPersonLocationType().equals("")) {
	    	updatePatient.setPriorPatientLocationPersonLocationType(matrixPatient.getPriorPatientLocationPersonLocationType());
	    }
	    if(matrixPatient.getPriorPatientLocationPointOfCare() != null && !matrixPatient.getPriorPatientLocationPointOfCare().equals("")) {
	    	updatePatient.setPriorPatientLocationPointOfCare(matrixPatient.getPriorPatientLocationPointOfCare());
	    }
	    if(matrixPatient.getPriorPatientLocationRoom() != null && !matrixPatient.getPriorPatientLocationRoom().equals("")) {
	    	updatePatient.setPriorPatientLocationRoom(matrixPatient.getPriorPatientLocationRoom());
	    }
	    if(matrixPatient.getReceivingApplication() != null && !matrixPatient.getReceivingApplication().equals("")) {
	    	updatePatient.setReceivingApplication(matrixPatient.getReceivingApplication());
	    }
	    if(matrixPatient.getReceivingFacility() != null && !matrixPatient.getReceivingFacility().equals("")) {
	    	updatePatient.setReceivingFacility(matrixPatient.getReceivingFacility());
	    }
	    if(matrixPatient.getReligion() != null && !matrixPatient.getReligion().equals("")) {
	    	updatePatient.setReligion(matrixPatient.getReligion());
	    }
	    if(matrixPatient.getSendingApplication() != null && !matrixPatient.getSendingApplication().equals("")) {
	    	updatePatient.setSendingApplication(matrixPatient.getSendingApplication());
	    }
	    if(matrixPatient.getSendingFacility() != null && !matrixPatient.getSendingFacility().equals("")) {
	    	updatePatient.setSendingFacility(matrixPatient.getSendingFacility());
	    }
	    if(matrixPatient.getZipCode()!= null && !matrixPatient.getZipCode().equals("")) {
	    	updatePatient.setZipCode(matrixPatient.getZipCode());
	    }
	    
		
		return updatePatient;
		
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
private EMROperatorInfo updateFacility(EMROperatorInfo emrOperatorList) {
		
		//String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		
	DateFormat converter = null;
    converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
    converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
    String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
    long currenttime = Long.parseLong(formatedDate);
    String timeStamp = currenttime+"";
	
		emrOperatorList.setLastUpdatedPatient(timeStamp);
		
		
		return emrOperatorList;
		
	}
}
