package com.zsl.mc.service;

public interface PatientsService {

	//public void getPatients(String facilityOID, String snapshotDate)throws Exception ;
	
	public void getPatients(String emrOperator)throws Exception ;
}
