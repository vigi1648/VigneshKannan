package com.zsl.mc.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


public class Message
{
	@XmlElement
    private CensusSnapshotVo CensusSnapshotVo;

    public CensusSnapshotVo getCensusSnapshotVo ()
    {
        return CensusSnapshotVo;
    }

    public void setCensusSnapshotVo (CensusSnapshotVo CensusSnapshotVo)
    {
        this.CensusSnapshotVo = CensusSnapshotVo;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [CensusSnapshotVo = "+CensusSnapshotVo+"]";
    }
}
