package com.zsl.mc.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PatientInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class PatientInfo
{
	private Message[] message;

    private ServiceResult ServiceResult;

    public Message[] getMessage ()
    {
        return message;
    }

    public void setMessage (Message[] message)
    {
        this.message = message;
    }

    public ServiceResult getServiceResult ()
    {
        return ServiceResult;
    }

    public void setServiceResult (ServiceResult ServiceResult)
    {
        this.ServiceResult = ServiceResult;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [message = "+message+", ServiceResult = "+ServiceResult+"]";
    }
}
