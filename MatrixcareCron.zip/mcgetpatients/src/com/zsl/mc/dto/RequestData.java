package com.zsl.mc.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;



@XmlAccessorType(XmlAccessType.FIELD)
public class RequestData {

	
	private String RequestType;
	
	@XmlElement(name="RequestParams")
	private RequestParams RequestParams;

    

    public RequestParams getRequestParams ()
    {
        return RequestParams;
    }

    public void setRequestParams (RequestParams RequestParams)
    {
        this.RequestParams = RequestParams;
    }

    public String getRequestType ()
    {
        return RequestType;
    }

    public void setRequestType (String RequestType)
    {
        this.RequestType = RequestType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [RequestParams = "+RequestParams+", RequestType = "+RequestType+"]";
    }
}
