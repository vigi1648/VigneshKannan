package com.zsl.mc.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="EMROPERATOR_INFO_UAT")
public class EMROperatorInfo {
@DynamoDBHashKey(attributeName="FACILITY")	
private String facility;
@DynamoDBRangeKey(attributeName="EMROPERATOR")
private String emrOperator;
@DynamoDBAttribute(attributeName="CREATEDON")
private String createdOn;
@DynamoDBAttribute(attributeName="ORGIN")
private String origin;
@DynamoDBAttribute(attributeName="PASSWORD")
private String password;
@DynamoDBAttribute(attributeName="USERNAME")
private String userName;
@DynamoDBAttribute(attributeName="VENDORCODE")
private String vendorCode;
@DynamoDBAttribute(attributeName="CUSTOMER")
private String customer;
@DynamoDBAttribute(attributeName="FACILITYSTATUS")
private String facilityStatus;
@DynamoDBAttribute(attributeName="LASTUPDATEDPATIENT")
private String lastUpdatedPatient;

public String getFacility() {
	return facility;
}
public void setFacility(String facility) {
	this.facility = facility;
}
public String getEmrOperator() {
	return emrOperator;
}
public void setEmrOperator(String emrOperator) {
	this.emrOperator = emrOperator;
}
public String getCreatedOn() {
	return createdOn;
}
public void setCreatedOn(String createdOn) {
	this.createdOn = createdOn;
}
public String getOrigin() {
	return origin;
}
public void setOrigin(String origin) {
	this.origin = origin;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getVendorCode() {
	return vendorCode;
}
public void setVendorCode(String vendorCode) {
	this.vendorCode = vendorCode;
}
public String getCustomer() {
	return customer;
}
public void setCustomer(String customer) {
	this.customer = customer;
}
public String getFacilityStatus() {
	return facilityStatus;
}
public void setFacilityStatus(String facilityStatus) {
	this.facilityStatus = facilityStatus;
}
public String getLastUpdatedPatient() {
	return lastUpdatedPatient;
}
public void setLastUpdatedPatient(String lastUpdatedPatient) {
	this.lastUpdatedPatient = lastUpdatedPatient;
}



}
