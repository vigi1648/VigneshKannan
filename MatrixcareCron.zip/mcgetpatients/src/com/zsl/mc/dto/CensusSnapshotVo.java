package com.zsl.mc.dto;


public class CensusSnapshotVo
{
    private String LOCDescription;

    private String building;

    private String facilityName;

    private String bed;

    private String payerType;

    private String RUG;

    private String patientUnitShort;

    private String corporateName;

    private String patientID;

    private String lastStatus;

    private String referenceDate;

    private String facilityID;

    private String patientUnit;

    private String MRN;

    private String admitDate;

    private String fullName;

    private String payerName;

    private String room;

    public String getLOCDescription ()
    {
        return LOCDescription;
    }

    public void setLOCDescription (String LOCDescription)
    {
        this.LOCDescription = LOCDescription;
    }

    public String getBuilding ()
    {
        return building;
    }

    public void setBuilding (String building)
    {
        this.building = building;
    }

    public String getFacilityName ()
    {
        return facilityName;
    }

    public void setFacilityName (String facilityName)
    {
        this.facilityName = facilityName;
    }

    public String getBed ()
    {
        return bed;
    }

    public void setBed (String bed)
    {
        this.bed = bed;
    }

    public String getPayerType ()
    {
        return payerType;
    }

    public void setPayerType (String payerType)
    {
        this.payerType = payerType;
    }

    public String getRUG ()
    {
        return RUG;
    }

    public void setRUG (String RUG)
    {
        this.RUG = RUG;
    }

    public String getPatientUnitShort ()
    {
        return patientUnitShort;
    }

    public void setPatientUnitShort (String patientUnitShort)
    {
        this.patientUnitShort = patientUnitShort;
    }

    public String getCorporateName ()
    {
        return corporateName;
    }

    public void setCorporateName (String corporateName)
    {
        this.corporateName = corporateName;
    }

    public String getPatientID ()
    {
        return patientID;
    }

    public void setPatientID (String patientID)
    {
        this.patientID = patientID;
    }

    public String getLastStatus ()
    {
        return lastStatus;
    }

    public void setLastStatus (String lastStatus)
    {
        this.lastStatus = lastStatus;
    }

    public String getReferenceDate ()
    {
        return referenceDate;
    }

    public void setReferenceDate (String referenceDate)
    {
        this.referenceDate = referenceDate;
    }

    public String getFacilityID ()
    {
        return facilityID;
    }

    public void setFacilityID (String facilityID)
    {
        this.facilityID = facilityID;
    }

    public String getPatientUnit ()
    {
        return patientUnit;
    }

    public void setPatientUnit (String patientUnit)
    {
        this.patientUnit = patientUnit;
    }

    public String getMRN ()
    {
        return MRN;
    }

    public void setMRN (String MRN)
    {
        this.MRN = MRN;
    }

    public String getAdmitDate ()
    {
        return admitDate;
    }

    public void setAdmitDate (String admitDate)
    {
        this.admitDate = admitDate;
    }

    public String getFullName ()
    {
        return fullName;
    }

    public void setFullName (String fullName)
    {
        this.fullName = fullName;
    }

    public String getPayerName ()
    {
        return payerName;
    }

    public void setPayerName (String payerName)
    {
        this.payerName = payerName;
    }

    public String getRoom ()
    {
        return room;
    }

    public void setRoom (String room)
    {
        this.room = room;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [LOCDescription = "+LOCDescription+", building = "+building+", facilityName = "+facilityName+", bed = "+bed+", payerType = "+payerType+", RUG = "+RUG+", patientUnitShort = "+patientUnitShort+", corporateName = "+corporateName+", patientID = "+patientID+", lastStatus = "+lastStatus+", referenceDate = "+referenceDate+", facilityID = "+facilityID+", patientUnit = "+patientUnit+", MRN = "+MRN+", admitDate = "+admitDate+", fullName = "+fullName+", payerName = "+payerName+", room = "+room+"]";
    }
}
