package com.zsl.mc.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class RequestParams {

	private String FacilityOID;

    private String SnapshotDate;

    public String getFacilityOID ()
    {
        return FacilityOID;
    }

    public void setFacilityOID (String FacilityOID)
    {
        this.FacilityOID = FacilityOID;
    }

    public String getSnapshotDate ()
    {
        return SnapshotDate;
    }

    public void setSnapshotDate (String SnapshotDate)
    {
        this.SnapshotDate = SnapshotDate;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [FacilityOID = "+FacilityOID+", SnapshotDate = "+SnapshotDate+"]";
    }
}
