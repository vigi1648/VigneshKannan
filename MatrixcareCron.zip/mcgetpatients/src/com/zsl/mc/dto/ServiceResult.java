package com.zsl.mc.dto;

public class ServiceResult
{
    private String TransactionId;

    private String MessageTxt;

    public String getTransactionId ()
    {
        return TransactionId;
    }

    public void setTransactionId (String TransactionId)
    {
        this.TransactionId = TransactionId;
    }

    public String getMessageTxt ()
    {
        return MessageTxt;
    }

    public void setMessageTxt (String MessageTxt)
    {
        this.MessageTxt = MessageTxt;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [TransactionId = "+TransactionId+", MessageTxt = "+MessageTxt+"]";
    }
}
