package com.zsl.mc.dao;

import java.util.List;




import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.zsl.mc.dto.EMROperatorInfo;
import com.zsl.mc.dto.PatientDetails;

public interface PatientDAO {
	
	public List<FailedBatch> savePatients(List<PatientDetails> updatePatients);
	
	public void saveupdatedfacility(EMROperatorInfo emrList);
		
    public List<EMROperatorInfo> getfacility(String emrOperator);
	
	public List<PatientDetails> getPatient(String facility, String sendingApplication);
	
	public PatientDetails getPatientInfo(String nrPatientId);
}
