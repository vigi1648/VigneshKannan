package com.zsl.mc.controller;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.zsl.mc.service.PatientsService;
import com.zsl.mc.serviceimpl.PatientsServiceImpl;

/*public class RequestHandler {*/
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {
	static final Logger logger = LogManager.getLogger(LambdaFunctionHandler.class);

    @Override
    public Object handleRequest(Object input, Context context) {
    	System.out.println(" Enter Lambda Function Handler method");
    	logger.info("Info Message Logged !!!");
    	PatientsService patientsService = new PatientsServiceImpl();
    	String emrOperator = "MATRIXCARE";
    	
    	try {
			 patientsService.getPatients(emrOperator);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/* catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    
	return patientsService;

    }
	public static void main(String [] args){
		try {
			PatientsService patientsService = new PatientsServiceImpl();
			String emrOperator = "MATRIXCARE"; 
			patientsService.getPatients(emrOperator);
			//patientsService.getPatients("2.16.124.113611.6432.1.1.4225");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}