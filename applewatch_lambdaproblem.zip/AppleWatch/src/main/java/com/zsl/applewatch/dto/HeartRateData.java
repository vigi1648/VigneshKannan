package com.zsl.applewatch.dto;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
@DynamoDBTable(tableName="SAMPLE")
public class HeartRateData  {
	@DynamoDBAttribute(attributeName="HEARTVALUE")
public List<HeartRateData> heartValue;
	@DynamoDBAttribute(attributeName="HEARTTIME")
private List<HeartRateData> heartTime;
public List<HeartRateData> getHeartValue() {
	return heartValue;
}
public void setHeartValue(List<HeartRateData> heartValue) {
	this.heartValue = heartValue;
}
public List<HeartRateData> getHeartTime() {
	return heartTime;
}
public void setHeartTime(List<HeartRateData> heartTime) {
	this.heartTime = heartTime;
}


}
