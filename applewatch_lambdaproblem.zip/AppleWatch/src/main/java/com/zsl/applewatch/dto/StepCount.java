package com.zsl.applewatch.dto;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
@DynamoDBTable(tableName="SAMPLE")
public class StepCount  {
	@DynamoDBAttribute(attributeName="STEPSTATUS")
private String stepStatus;
	@DynamoDBAttribute(attributeName="TOTALSTEPS")
private String totalSteps;
	@DynamoDBAttribute(attributeName="TOTALDISTANCE")
private String totalDistance;
	@DynamoDBAttribute(attributeName="LIVESTEPSVALUE")
public List<StepCount> LiveStepsValue;
	@DynamoDBAttribute(attributeName="LIVESTEPSTIME")
public List<StepCount> getLiveStepsValue() {
	return LiveStepsValue;
}
public void setLiveStepsValue(List<StepCount> liveStepsValue) {
	LiveStepsValue = liveStepsValue;
}
public List<StepCount> getLiveStepsTime() {
	return LiveStepsTime;
}
public void setLiveStepsTime(List<StepCount> liveStepsTime) {
	LiveStepsTime = liveStepsTime;
}
public List<StepCount> LiveStepsTime;
public String getStepStatus() {
	return stepStatus;
}
public void setStepStatus(String stepStatus) {
	this.stepStatus = stepStatus;
}
public String getTotalSteps() {
	return totalSteps;
}
public void setTotalSteps(String totalSteps) {
	this.totalSteps = totalSteps;
}
public String getTotalDistance() {
	return totalDistance;
}
public void setTotalDistance(String totalDistance) {
	this.totalDistance = totalDistance;
}

}
