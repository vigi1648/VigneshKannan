package com.zsl.applewatch.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.zsl.applewatch.dao.FitnessDataDAO;
import com.zsl.applewatch.dao.FitnessDataDAOImpl;
import com.zsl.applewatch.dto.CalorieBurn;
import com.zsl.applewatch.dto.FitnessData;
import com.zsl.applewatch.dto.HeartRateData;
import com.zsl.applewatch.service.FitnessDataService;




/**
 * Created on 22/06/2018.
   sending vitals through medical device to LGCNS using SOAP web service  
 */
public class FitnessDataServiceImpl implements FitnessDataService {

	static final Logger logger = LogManager.getLogger(FitnessDataServiceImpl.class);
	 
	
	
public String updateFitnessData(List<Object> fitnessDataList) {
	//logger.info("inside service impl class");
		FitnessData fitnessdataObj = null;
		
		String status = null;
		Map<String, String> fitnessData = null;
		try {
		List<FitnessData> fitnessDataListObj = new ArrayList<FitnessData>();
		FitnessDataDAO fitnessDataDAO = new FitnessDataDAOImpl();
		for(Object object : fitnessDataList){
			fitnessData = (LinkedHashMap<String, String>) object;
			fitnessdataObj = new FitnessData();
			fitnessdataObj.setGivenName(fitnessData.get("givenName"));
			fitnessdataObj.setAdministrativeSex(fitnessData.get("Gender"));
			fitnessdataObj.setDob(fitnessData.get("Age"));
			fitnessdataObj.setLastModifiedOn(fitnessData.get("lastModifiedOn"));
			fitnessdataObj.setDateTimeOfObservation(fitnessData.get("dateTimeOfObservation") != null && !fitnessData.get("dateTimeOfObservation").equals("") ? fitnessData.get("dateTimeOfObservation") : null);
			fitnessdataObj.setNrPatientId(fitnessData.get("nrPatientId") != null && !fitnessData.get("nrPatientId").equals("") ? fitnessData.get("nrPatientId") : null);
			fitnessdataObj.setHeartTime(fitnessData.get("heartTime"));
			fitnessdataObj.setHeartValue(fitnessData.get("heartValue"));
			fitnessdataObj.setCaloriesBurned(fitnessData.get("caloriesBurned"));
			fitnessdataObj.setCaloriesTime(fitnessData.get("caloriesTime"));
			fitnessdataObj.setStepStatus(fitnessData.get("stepStatus"));
			fitnessdataObj.setTotalSteps(fitnessData.get("totalSteps"));
			fitnessdataObj.setTotalDistance(fitnessData.get("totalDistance"));
			fitnessdataObj.setLiveStepsValue(fitnessData.get("liveStepsValue"));
			fitnessdataObj.setLiveStepsTime(fitnessData.get("liveStepsTime"));
			
			//((CalorieBurn) calorieBurnDataListObj).setCaloriesTime(calorieburnobj.get("caloriesTime"));
			/*if(fitnessData.get("measurementIdentifier") != null && !fitnessData.get("measurementIdentifier").equals("") && fitnessData.get("measurementIdentifier").equals("3141-9")){
				fitnessdataObj.setMeasurementIdentifier("29463-7");
				}else{
					fitnessdataObj.setMeasurementIdentifier(fitnessData.get("measurementIdentifier") != null && !fitnessData.get("measurementIdentifier").equals("") ? fitnessData.get("measurementIdentifier") : null);
				}
			*/
			

			fitnessDataListObj.add(fitnessdataObj);
			
			//logger.info("[INFO] "+fitnessData.get("userId")+" "+vitalStat.get("nrPatientId")+" "+vitalStat.get("dateTimeOfObservation")+" "+vitalStat.get("customer")+" "+vitalStat.get("facility")+" "+vitalStat.get("macId")+" "+vitalStat.get("measurementText")+" RECEIVED SUCCESSFULLY FROM TABLET");
			
	      }
		status=fitnessDataDAO.updateFitnessData(fitnessDataListObj);
		} catch(Exception e){ 
			throw new RuntimeException(e.getMessage(),e);
		}
		
		return status;
}
		
}
