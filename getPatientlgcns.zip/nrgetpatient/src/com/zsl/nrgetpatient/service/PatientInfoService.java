package com.zsl.nrgetpatient.service;

import java.util.List;
import java.util.Map;

import com.zsl.nrgetpatient.dto.PatientInfo;
import com.zsl.nrgetpatient.dto.PatientsInfo;

public interface PatientInfoService {

	public PatientsInfo getPatients(String sendingApplication,String sendingFacility);
	
	//public PatientsInfo getPatients(String sendingApplication,String sendingFacility);
	
}
