package com.zsl.nrgetpatient;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.DynamodbEvent;
import com.zsl.nrgetpatient.dto.PatientInfo;
import com.zsl.nrgetpatient.dto.PatientsInfo;
import com.zsl.nrgetpatient.service.PatientInfoService;
import com.zsl.nrgetpatient.serviceimpl.PatientInfoServiceImpl;

public class LambdaFunctionHandler implements RequestHandler<Object, Object> {

    @Override
    public Object handleRequest(Object input, Context context) {
    	PatientInfoService patientInfoService = new PatientInfoServiceImpl();
        Map<String,String> patientInfo = (LinkedHashMap<String, String>)input;
        String sendingApplication = patientInfo.get("EMRoperator");
        String sendingFacility = patientInfo.get("SendingFacility");
        PatientsInfo patientMap = patientInfoService.getPatients(sendingApplication, sendingFacility);
       // PatientsInfo patientsInfo = patientInfoService.getPatients(sendingApplication, sendingFacility);
        return patientMap;
    }
public static void main(String args[]){
	PatientInfoService patientInfoService = new PatientInfoServiceImpl();
	String sendingApplication = "PCCApp";
    String sendingFacility = "12.1504955528";
    PatientsInfo patientMap = patientInfoService.getPatients(sendingApplication,sendingFacility);
    //PatientsInfo patientsInfo = patientInfoService.getPatients(sendingApplication, sendingFacility);
}
}
