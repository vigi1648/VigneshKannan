package com.zsl.nrgetpatient.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.zsl.nrgetpatient.dao.PatientInfoDAO;
import com.zsl.nrgetpatient.dto.PatientInfo;
import com.zsl.nrgetpatient.util.AWSAuthenticationUtil;
import com.zsl.nrgetpatient.util.DynamoDBUtil;


public class PatientInfoDAOImpl implements PatientInfoDAO{
	
	AWSCredentials awsCredentials = null;
	AmazonDynamoDBClient client = null;
	
/*public ItemCollection<QueryOutcome> getPatients(String sendingApplication,String sendingFacility){
	ItemCollection<QueryOutcome> items = null;
	
	 awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
	 client = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
	 
	DynamoDB dynamoDB = DynamoDBUtil.getAmazonDynamoDB(client);
		try {	
		Table table = dynamoDB.getTable("PATIENTS_INFO");
		Index index = table.getIndex("SENDINGAPPLICATION-SENDINGFACILITY-index");
		QuerySpec spec = new QuerySpec()
		    .withKeyConditionExpression("SENDINGAPPLICATION = :v_sendapp and SENDINGFACILITY = :v_facility")
		    .withFilterExpression("PATIENTSTATUS = :v_patientstatus")
		    .withValueMap(new ValueMap()
		    	.withString(":v_sendapp", sendingApplication)
		        .withString(":v_facility", sendingFacility)
				.withString(":v_patientstatus", "ACTIVE")
				);
		
		items = index.query(spec);
		
		return items;
		
		}   catch (AmazonServiceException ase) {
		
			throw new RuntimeException("Internal Server Error");
		} catch (AmazonClientException ace){
			throw new RuntimeException("Internal Server Error");
		} catch (Exception e){
			throw new RuntimeException(e.getMessage());
		} finally {
			client = null;
			awsCredentials = null;
		}

}
*/
	public List<PatientInfo>  getPatients(String sendingApplication,String sendingFacility){
		try {
			awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			client = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(client);
			
	//		String patientStatus = "ACTIVE";
			String outpatient = "false";
			Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
			attributeValues.put(":v1", new AttributeValue().withS(sendingApplication));
			attributeValues.put(":v2", new AttributeValue().withS(sendingFacility));
			attributeValues.put(":v3", new AttributeValue().withS(outpatient));
			
			DynamoDBQueryExpression<PatientInfo> queryExpression = new DynamoDBQueryExpression<PatientInfo>()
					   .withIndexName("SENDINGAPPLICATION-SENDINGFACILITY-index")
 	                   .withConsistentRead(false)
		               .withKeyConditionExpression("SENDINGAPPLICATION = :v1 and SENDINGFACILITY = :v2")
		               .withFilterExpression("OUTPATIENT = :v3")
		               .withExpressionAttributeValues(attributeValues);
	           
	           
	        List<PatientInfo> patientList =  dynamoDBMapper.query(PatientInfo.class, queryExpression);
	          
	        return patientList;
	           
		} catch (AmazonServiceException ase) {
			throw new RuntimeException("Internal Server Error");
		} catch (AmazonClientException ace){
			throw new RuntimeException("Internal Server Error");
		} catch (Exception e){
			throw new RuntimeException(e.getMessage());
		} finally {
			client = null;
			awsCredentials = null;
		}
		
	}// TODO Auto-generated method stub
		
}
