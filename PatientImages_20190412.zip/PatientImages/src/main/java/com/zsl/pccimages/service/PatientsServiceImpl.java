package com.zsl.pccimages.service;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.imageio.ImageIO;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.crypto.CryptoException;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.S3Link;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.zsl.pccimages.dto.Paging;
import com.zsl.pccimages.util.BouncyCastleEngine;
import com.zsl.pccimages.dao.PatientsDAO;
import com.zsl.pccimages.dao.PatientsDAOImpl;
import com.zsl.pccimages.dto.Data;
import com.zsl.pccimages.dto.EMROperatorInfo;
import com.zsl.pccimages.dto.Errors;
import com.zsl.pccimages.dto.PatientDetails;
import com.zsl.pccimages.dto.Patients;
import com.zsl.pccimages.dto.PatientsError;
import com.zsl.pccimages.util.AWSAuthenticationUtil;
import com.zsl.pccimages.util.CommonUtil;
import com.zsl.pccimages.util.DynamoDBUtil;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.transfer.TransferProgress;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;

public class PatientsServiceImpl implements PatientsService {
	
	static final Logger logger = LogManager.getLogger(PatientsServiceImpl.class);
	
	private String dataKey;
	
	AWSCredentials awsCredentials = null;
	AmazonDynamoDBClient amazonDynamoDBClient = null;
	DynamoDB dynamoDB = null;
	

	//AWSCredentialsProvider s3CredentialProvider = null;
//	@SuppressWarnings("unchecked")
	@Override


public Object getPatients(Map<String, String> userInfo) throws IOException, InterruptedException, CryptoException {
		
		logger.info("Entered into getPatient service");
		
		PatientsDAO patientsDAO = new PatientsDAOImpl();
		Data data = new Data();
		
		Patients patients = new Patients(); 
		
		EMROperatorInfo emrinfo = null;

		List<PatientDetails> patientDetailsList = null;
		List<PatientDetails> patientDetailsList1 = null;
		//List<PatientDetails> patientlist = null;
		Map<String, PatientDetails> patientInfo = null;
		Map<String, PatientDetails> pccpatientInfo = null;

		patientDetailsList = new ArrayList<PatientDetails>();
		patientInfo = new HashMap<String, PatientDetails>();
		pccpatientInfo = new HashMap<String, PatientDetails>();
		
//		PatientsDAO patientsDAO = new PatientsDAOImpl();
//		LoginInfo loginInfo = patientsDAO.getLoginInfo();
		
		String emrOperator = userInfo.get("emrOperator");
		String sendingFacility=userInfo.get("sendingFacility");
		List<EMROperatorInfo> emrOperatorList = patientsDAO.getfacility(emrOperator);
		

		
		for(EMROperatorInfo facilityList : emrOperatorList){
			String[] facilityArray = facilityList.getFacility().split("\\.");
			String nrfacility = facilityList.getFacility();
//          String facility = facilityList.getFacility();
			
			String facility = facilityArray[0];
            String sendingApplication = facilityList.getEmrOperator();
            String orgId = facilityList.getOrigin();
			String accessToken = facilityList.getAccessToken();
            String accessTokenExpiresIn = facilityList.getAccexpiresIn().replace(".", "");
            long accessTokenExpiresL = Long.parseLong(accessTokenExpiresIn);
            String refereshToken = facilityList.getRefreshToken();
            String refereshTokenExpiresIn = facilityList.getRefexpiresIn().replace(".", "");
            long refereshTokenExpiresL = Long.parseLong(refereshTokenExpiresIn);
            logger.info("Entered into EMROperatorInfo Iterator" + facility);
            
            DateFormat converter = null;
            converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
            converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
            String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
            long currenttime = Long.parseLong(formatedDate);
      
            String has = null;
            int page = 0;
           
            //(data1.getPatientId() != null && !data1.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data1.getPatientId(), dataKey) : null)
            List<PatientDetails>  patientList = patientsDAO.getPatient(nrfacility,sendingApplication);
            for(PatientDetails patientDetail : patientList)
            {
            	String imageUrl=patientDetail.getImageUrl();
            	if (imageUrl==null)
            	{
            	 //pccpatientInfo.put(patientDetail.getPatientId(), patientDetail);
            		dataKey = CommonUtil.getInstance().getDataKey();
            	 String patientId=patientDetail.getPatientId() != null && !patientDetail.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESDecryption(patientDetail.getPatientId(), dataKey) : null;
            	 String nrpatientId=patientDetail.getNrPatientId();
            	 String hasPhoto=patientDetail.getHasPhoto();
     			if(hasPhoto.equals("true"))
    			{ 
       
        if(accessTokenExpiresL >= currenttime)
        {
        	/*do
        	{*/

        int i = 1 + page;
		HttpURLConnection connection = null;
		System.out.println("Before Calling time of getPatient API:" + currenttime);
//    	final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+userInfo.get("orgId")+"/patients?facId="+userInfo.get("facilityId")+"";
		//final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients?facId="+facility+"&patientStatus=Current&pageSize=200&page="+i+"";
		final String urlString="https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients/"+patientId+"/photo";
		System.out.println("PCC getPatient API Call URL" + urlString);
		System.out.println("After Calling time of getPatient API:" + currenttime);
		//Thread.sleep(20);
		logger.info("URL String of GetPatient" + urlString);
    	String authorization = "Bearer "+accessToken;
    	
    try
    {
    	final URL url = new URL(urlString);
    	connection = (HttpURLConnection) url.openConnection();
    	//String content=connection.getContentType();
		connection.setRequestMethod(HttpMethod.GET);
		connection.setDoOutput(true);
		connection.setRequestProperty("Content-Type",MediaType.APPLICATION_OCTET_STREAM); //MediaType.APPLICATION_OCTET_STREAM image/jpeg;charset=UTF-8
		connection.setRequestProperty("Accept", "image/*");
		connection.setRequestProperty("Authorization", authorization);
		
		if (connection.getInputStream() != null) {

			logger.info("Comes to InputStream");
            final InputStream inputStream = connection.getInputStream();
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            BufferedImage image =null; 
			image = ImageIO.read(inputStream);
			ImageIO.write(image,"jpeg",new File("urlString"));
            
            String clientRegion="US_EAST_1";
            String file_path="urlString";
			String bucket_name="nrpatientimages";
			String fileObjKeyName ="PCC" +"/" +nrfacility +"/" +nrpatientId;
			System.out.format("Uploading %s to S3 bucket %s...\n", file_path, bucket_name);
			//BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAI2RPUWWJPV7WKI3Q", "4MYpKmViMaRcvvFy2OIvzt7Hj+9ktBfqFdFV3ljv");

            
                    
                 
		
			File file= new File(file_path);
			 awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			 AWSCredentialsProvider s3CredentialProvider=new ProfileCredentialsProvider();
/*			AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                    .withCredentials( AWSCredentialsProvider())
                    .withRegion(clientRegion)
                    .build();*/
			//DefaultAWSCredentialsProviderChain credentialProviderChain = new DefaultAWSCredentialsProviderChain();
			 s3CredentialProvider.getCredentials();
			TransferManager xfer_mgr = new TransferManager(s3CredentialProvider);
			//TransferManager xfer_mgr =TransferManagerBuilder.standard().withS3Client(AmazonS3ClientBuilder.standard().withCredentials(s3CredentialProvider).build()).build();
/*			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentLength(inputStream.read());
			metadata.setContentType("image/jpeg");*/
			    Upload xfer = xfer_mgr.upload(bucket_name, fileObjKeyName,new File(file_path));
/*			    xfer.addProgressListener(new ProgressListener() {
			        public void progressChanged(ProgressEvent e) {
			            double pct = e.getBytesTransferred() * 100.0 / e.getBytes();
			        }});*/
			    
			    if (xfer.isDone() == false) {
			        System.out.println("Transfer: " + xfer.getDescription());
			        System.out.println("  - State: " + xfer.getState());
			        xfer.waitForCompletion();
			        System.out.println("  - Progress: "
			                        + xfer.getProgress().getBytesTransferred());
			        System.out.println("  - State: " + xfer.getState());

				    
				    
			 }
			    
			    String decodedValue = null;
				try {
			   BouncyCastleEngine.AESEncryption(patientId, dataKey);
			   //String patientId=patientDetail.getPatientId() != null && !patientDetail.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESDecryption(patientDetail.getPatientId(), dataKey) : null;
				} catch(Exception e){
					throw new RuntimeException(e.getMessage(), e);
				}
				finally {
				decodedValue = null;
				dataKey = null;
				}
			   // xfer.addProgressListener(myProgressListener);
			    //xfer.waitForCompletion();
/*			    AmazonS3Client s3 = s3link.getAmazonS3Client();
			    TransferManager s3m = S3Link.getTransferManager();*/
			    
			    //s3CredentialProvider= new AWSStaticCredentials
			    // s3CredentialProvider=AWSAuthenticationUtil.getAWSCredentials() ;
				amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
				
				DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(amazonDynamoDBClient,s3CredentialProvider);
			    //S3Link s3link= dynamoDBMapper.createS3Link(bucket_name, fileObjKeyName);
			    //s3link.getUrl();
			    S3Link s3link= dynamoDBMapper.createS3Link(bucket_name, fileObjKeyName);
			      patientDetail.setImageUrl(s3link.getUrl().toString());
			    dynamoDBMapper.save(patientDetail);
			    xfer_mgr.shutdownNow();
			
        	   //PutObjectResult outputStream = null;outputStream =
        	    //s3Client.putObject(bucket_name, fileObjKeyName, new File(file_path));
/*               PutObjectRequest request = new PutObjectRequest(bucket_name, fileObjKeyName,new File(file_path));  //new File(file_path)
               ObjectMetadata metadata = new ObjectMetadata();
               metadata.setContentType("image/*");
               //metadata.addUserMetadata("x-amz-meta-title", "someTitle");
               request.setMetadata(metadata);
              // s3Client.putObject(request);
               byte[] buffer = new byte[2048];
               int length;*/
}
/*else
{
	logger.error("No images available at PCC");
}*/
		}  
		
    
            	
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info(e);
		}
/*    Paging paging = patients.getPaging();
	page = paging.getPage();
     has = paging.getHasMore();
     System.out.println("hasmore flag" + has);
     logger.info("hasmore flag" + has);
         }
        	while (has.equals("true"));*/
        		
        }
    			
        else if(refereshTokenExpiresL >= currenttime){
        	 emrinfo = AccessToken(refereshToken,refereshTokenExpiresIn);
             String newaccessToken = emrinfo.getAccess_token();
             String newaccessTokenExpiresIn = emrinfo.getExpires_in().replace(".","");
             long newaccessTokenExpiresL = Long.parseLong(newaccessTokenExpiresIn);
             String newrefereshTokenExpiresIn = emrinfo.getRefresh_expires_in().replace(".", "");
             long newrefereshTokenExpiresL = Long.parseLong(newrefereshTokenExpiresIn);
             EMROperatorInfo emrIn = updateemrInfo(emrinfo,facilityList);
             PatientsDAO patientDAO = new PatientsDAOImpl();
          // String updtdmsg = patientDAO.updateEmrInfo(emrIn);
      
             if(newaccessTokenExpiresL >= currenttime){
/*            	 do
             	{*/
            		 
             int i = 1 + page;
     		HttpURLConnection connection = null;
     		System.out.println("Before Calling time of getPatient API:" + currenttime);
//         	final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+userInfo.get("orgId")+"/patients?facId="+userInfo.get("facilityId")+"";
     		//final String urlString = "https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients?facId="+facility+"&patientStatus=Current&pageSize=200&page="+i+"";
     		final String urlString="https://connect.pointclickcare.com/api/public/preview1/orgs/"+orgId+"/patients/"+patientId+"/photo";
     		System.out.println("PCC getPatient API Call URL" + urlString);
    		System.out.println("After Calling time of API:" + currenttime);
    		//Thread.sleep(20);
     		logger.info("URL String of GetPatient" + urlString);
         	String authorization = "Bearer "+newaccessToken;
         	 try
             {
             	final URL url = new URL(urlString);
             	connection = (HttpURLConnection) url.openConnection();
         		connection.setRequestMethod(HttpMethod.GET);
         		connection.setDoOutput(true);
         		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_OCTET_STREAM);
         		connection.setRequestProperty("Accept", "image/*");
         		connection.setRequestProperty("Authorization", authorization);
         		
         		if (connection.getInputStream() != null) {
         			logger.info("Comes to InputStream");
                    final InputStream inputStream = connection.getInputStream();
                    final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    BufferedImage image =null; 
        			image = ImageIO.read(inputStream);
        			ImageIO.write(image,"jpeg",new File("urlString"));
                    
                    String clientRegion="US_EAST_1";
                    String file_path="urlString";
        			String bucket_name="nrpatientimages";
        			String fileObjKeyName ="PCC" +"/" +nrfacility +"/" +nrpatientId;
        			System.out.format("Uploading %s to S3 bucket %s...\n", file_path, bucket_name);
        			//BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAI2RPUWWJPV7WKI3Q", "4MYpKmViMaRcvvFy2OIvzt7Hj+9ktBfqFdFV3ljv");

                    
                            
                         
        		
        			File file= new File(file_path);
        			 awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
        			 AWSCredentialsProvider s3CredentialProvider=new ProfileCredentialsProvider();
        /*			AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                            .withCredentials( AWSCredentialsProvider())
                            .withRegion(clientRegion)
                            .build();*/
        			//DefaultAWSCredentialsProviderChain credentialProviderChain = new DefaultAWSCredentialsProviderChain();
        			 s3CredentialProvider.getCredentials();
        			TransferManager xfer_mgr = new TransferManager(s3CredentialProvider);
        			//TransferManager xfer_mgr =TransferManagerBuilder.standard().withS3Client(AmazonS3ClientBuilder.standard().withCredentials(s3CredentialProvider).build()).build();
        			
        			
        			    Upload xfer = xfer_mgr.upload(bucket_name, fileObjKeyName, file);

        			    if (xfer.isDone() == false) {
        			        System.out.println("Transfer: " + xfer.getDescription());
        			        System.out.println("  - State: " + xfer.getState());
        			        xfer.waitForCompletion();
        			        System.out.println("  - Progress: "
        			                        + xfer.getProgress().getBytesTransferred());
        			        System.out.println("  - State: " + xfer.getState());
        			 }
        			    String decodedValue = null;
        				try {
        			   BouncyCastleEngine.AESEncryption(patientId, dataKey);
        			   //String patientId=patientDetail.getPatientId() != null && !patientDetail.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESDecryption(patientDetail.getPatientId(), dataKey) : null;
        				} catch(Exception e){
        					throw new RuntimeException(e.getMessage(), e);
        				}
        				finally {
        				decodedValue = null;
        				dataKey = null;
        				}
        			   // xfer.addProgressListener(myProgressListener);
        			    //xfer.waitForCompletion();
        /*			    AmazonS3Client s3 = s3link.getAmazonS3Client();
        			    TransferManager s3m = S3Link.getTransferManager();*/
        			    
        			    //s3CredentialProvider= new AWSStaticCredentials
        			    // s3CredentialProvider=AWSAuthenticationUtil.getAWSCredentials() ;
        				amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
        				
        				DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(amazonDynamoDBClient,s3CredentialProvider);
        			    //S3Link s3link= dynamoDBMapper.createS3Link(bucket_name, fileObjKeyName);
        			    //s3link.getUrl();
        			    S3Link s3link= dynamoDBMapper.createS3Link(bucket_name, fileObjKeyName);
        			      patientDetail.setImageUrl(s3link.getUrl().toString());
        			    dynamoDBMapper.save(patientDetail);
        			    xfer_mgr.shutdownNow();
         		}
             }
             
         		catch(Exception e)
         		{
         			e.printStackTrace();
         		}
         /*    } while (has.equals("true")); */	
             	
     		} 
        
             else {
            	 logger.error("New Access token Expired");
             }
             
          
        }     
        else {
      			logger.error("Referesh token Expired");
      		}
           
                
        
		
		}
       
   
		}
		}
		}
		//return emrOperatorList;
		 return  patients;
	}
	
	
	
	
	public EMROperatorInfo AccessToken(String refereshToken,String refereshTokenExpiresIn) throws MalformedURLException
	{
		EMROperatorInfo emrOperatorInfo = null;
		StringBuilder response = null;
		HttpURLConnection connection = null;
		
		DateFormat converter = null;
        converter = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
        converter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        String formatedDate = converter.format(calendar.getTime()).toString().replace(".", "");            
        long currenttime = Long.parseLong(formatedDate);
        
		System.out.println("Before Calling newAccessToken API time:"+ currenttime );
	// Demo getAccessToken URL :	
	//	final String URLstr = "https://5zexw2gi20.execute-api.us-east-1.amazonaws.com/poc/pcc-developer/get-token?code=&refresh_token="+refereshToken+"";
	// Prod  getAccessToken URL : 	
		String URLstr = "https://pccdeveloperapi.rosieconnect2.com/api/get-token?code=&refresh_token="+refereshToken+"";
		System.out.println("Calling newAccessToken API"+ URLstr );
		System.out.println("After Calling newAccessToken API time:"+ currenttime );
        try {
        final URL url = new URL(URLstr);
    	connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(HttpMethod.GET);
		connection.setDoOutput(true);
//		connection.setRequestProperty("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
		connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
		
		if (connection.getInputStream() != null) {
			logger.info("Comes to InputStream");
            final InputStream inputStream = connection.getInputStream();
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            try {
                response = new StringBuilder();

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }
                JsonParser jsonParser = new JsonParser();
                String jsonObject = jsonParser.parse(response.toString()).toString();
                Gson gson = new Gson();
                emrOperatorInfo = gson.fromJson(jsonObject, EMROperatorInfo.class);
                
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
		}
    } catch (Exception e) {
    	InputStream errorstream = connection.getErrorStream();
    	if(errorstream != null)
    	{
    	BufferedReader br = null;
    	System.out.println("Comes to errorstream while try to get token");
        br = new BufferedReader(new InputStreamReader(errorstream));
        String response1 = "";
        String nachricht;
        try {
			while ((nachricht = br.readLine()) != null){
			    response1 += nachricht;
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        JsonParser jsonParserError = new JsonParser();
        String jsonObjectResError = jsonParserError.parse(response1.toString()).toString();
        Gson gsonError = new Gson();
        PatientsError patientsResponseError = gsonError.fromJson(jsonObjectResError, PatientsError.class);
        String errDetail = null;
        for(Errors errors : patientsResponseError.getErrors()){
        	System.out.println("response1" + errors.getTitle());
        	System.out.println("response2" + errors.getDetail());
        	logger.error(errors.getDetail());
        	errDetail = errors.getDetail();
        	break;
        	
        }
    	}
        
        e.printStackTrace();
    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    }
		
		return emrOperatorInfo;
	}
	
	public EMROperatorInfo updateemrInfo(EMROperatorInfo emrinfo,EMROperatorInfo facilityList){
		
		EMROperatorInfo facility = new EMROperatorInfo();
		
		String facility1 = facilityList.getFacility();
		String emroperator1 = facilityList.getEmrOperator();
		PatientsDAO patientDAO = new PatientsDAOImpl();
		EMROperatorInfo emrinf = patientDAO.getEMRInfo(facility1,emroperator1);
		emrinf.setAccessToken(emrinfo.getAccess_token());
		emrinf.setAccexpiresIn(emrinfo.getExpires_in());
		return emrinf;
	}
	
	private PatientDetails updateInactivePatient(PatientDetails dbPatient)
    {
           dbPatient.setPatientStatus("INACTIVE");
           String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
           dbPatient.setLastModifiedOn(timeStamp);
           return dbPatient;
    }
	
}