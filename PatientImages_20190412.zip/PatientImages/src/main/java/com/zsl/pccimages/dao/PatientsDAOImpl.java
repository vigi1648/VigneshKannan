package com.zsl.pccimages.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.zsl.pccimages.dto.EMROperatorInfo;
import com.zsl.pccimages.dto.LoginInfo;
import com.zsl.pccimages.dto.PatientDetails;
import com.zsl.pccimages.dto.Patients;
import com.zsl.pccimages.util.AWSAuthenticationUtil;
import com.zsl.pccimages.util.DynamoDBUtil;


public class PatientsDAOImpl implements PatientsDAO {
	
	static final Logger logger = LogManager.getLogger(PatientsDAOImpl.class);

	AWSCredentials awsCredentials = null;
	AmazonDynamoDBClient amazonDynamoDBClient = null;
	DynamoDB dynamoDB = null;
	
	@Override
	public Patients patientDetails(List<PatientDetails> updatePatients) {
		
		List<FailedBatch> failedBatchList = null;
		
//		if(((List<FailedBatch>) updatePatients).size() > 0) {
		awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
		amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
		
		DynamoDBMapper dynamoDBMapper =  DynamoDBUtil.getDynamoDBMapper(amazonDynamoDBClient);
		try {
			 failedBatchList = dynamoDBMapper.batchSave(updatePatients);
			if(failedBatchList.size() == 0){
				logger.info("ALL THE USERS HAS BEEN CREATED SUCCESFULLY");
			} else {
				for(FailedBatch failedBatch : failedBatchList){
					logger.error(failedBatch.getException());
				}
				logger.info("ERROR OCCURED IN USERS CREATION");
			}
			
		} catch (AmazonServiceException ase) {
			logger.error(ase.getMessage(), ase);
			throw new RuntimeException("Internal Server Error", ase);
		} catch (AmazonClientException ace) {
			logger.error(ace.getMessage(), ace);
			throw new RuntimeException("Internal Server Error", ace);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new RuntimeException("Internal Server Error", e);
		} finally {
			amazonDynamoDBClient = null;
			awsCredentials = null;
		}
//		} else {
//			log.error("No Patients");
//		}
		return (Patients) failedBatchList;
		
//		awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
//		amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
//		dynamoDB = new DynamoDB(amazonDynamoDBClient);
//
//			Table table = dynamoDB.getTable("PCCDEVELOPER");
//
//			Item item = table.getItem("ID", "1504955528");
//			
//			LoginInfo loginInfo = new LoginInfo();
//			loginInfo.setAccessToken(item.getString("ACCESSTOKEN"));
//			loginInfo.setRefreshToken(item.getString("REFRESHTOKEN"));
//			loginInfo.setExpiresIn(item.getString("EXPIRESIN"));
//			loginInfo.setOrgId(item.getString("ORGID"));
//			
//		return loginInfo;
	}
	
	public List<PatientDetails> getPatient(String sendingFacility, String sendingApplication) {
		// TODO Auto-generated method stub
			try {
				
				awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
				amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
				
				DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(amazonDynamoDBClient);
			
				String patientStatus = "ACTIVE";
				//String outpatient = "false";
				Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
				attributeValues.put(":v1", new AttributeValue().withS(sendingFacility));
				attributeValues.put(":v2", new AttributeValue().withS(sendingApplication));
				attributeValues.put(":v3", new AttributeValue().withS(patientStatus));
				//attributeValues.put(":v4", new AttributeValue().withS(outpatient));*/
				
				DynamoDBQueryExpression<PatientDetails> queryExpression = new DynamoDBQueryExpression<PatientDetails>()
						   .withIndexName("SENDINGFACILITY-SENDINGAPPLICATION-index")
	 	                   .withConsistentRead(false)
			               .withKeyConditionExpression("SENDINGFACILITY = :v1 and SENDINGAPPLICATION = :v2")
			               .withFilterExpression("PATIENTSTATUS= :v3 ")//and OUTPATIENT= :v4
			               .withExpressionAttributeValues(attributeValues);
		           
		           
		        List<PatientDetails> patientList =  dynamoDBMapper.query(PatientDetails.class, queryExpression);
		          
		        return patientList;
		           
			} catch (AmazonServiceException ase) {
				throw new RuntimeException("Internal Server Error");
			} catch (AmazonClientException ace){
				throw new RuntimeException("Internal Server Error");
			} catch (Exception e){
				throw new RuntimeException(e.getMessage());
			} finally {
				amazonDynamoDBClient = null;
				awsCredentials = null;
			}
			
		}
	
	
	public List<EMROperatorInfo> getfacility(String emrOperator) {
		// TODO Auto-generated method stub
			try {
				awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
				amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
				
				DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(amazonDynamoDBClient);
				
				
				String facilityStatus = "ACTIVE";
/*				String customer="494952549";
				String customer1="494952012";
				String customer2="80072";
				String customer3="5000079";
				String customer4="494954025";
				String customer5="80185";*/
				//String facility1="1.10060";
				String facility="1.494951069";
				//String facility="12.1504955528";
			   // String facility="159.80072";
				//String facility1="178.80072";
				//String facility2="56.80072";
				//String facility3="32.80072";*/
				String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			   
			        Date mDate = sdf.parse(timeStamp);
			        long timeInMilliseconds = mDate.getTime()-((60*5)*1000) ;
			        Date date = new Date(timeInMilliseconds);
			        DateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
			        String time = formatter.format(date); 
			        
				Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
				attributeValues.put(":v1", new AttributeValue().withS(emrOperator));
				attributeValues.put(":v2", new AttributeValue().withS(time));
				attributeValues.put(":v3", new AttributeValue().withS(facilityStatus));
				attributeValues.put(":v4", new AttributeValue().withS(facility));
				//attributeValues.put(":v4", new AttributeValue().withS(customer));
				//attributeValues.put(":v5", new AttributeValue().withS(customer1));
				//attributeValues.put(":v6", new AttributeValue().withS(customer2));
				//attributeValues.put(":v7", new AttributeValue().withS(customer3));
				//attributeValues.put(":v8", new AttributeValue().withS(customer4));
				//attributeValues.put(":v9", new AttributeValue().withS(customer5));
				//attributeValues.put(":v5", new AttributeValue().withS(facility1));
				DynamoDBQueryExpression<EMROperatorInfo> queryExpression = new DynamoDBQueryExpression<EMROperatorInfo>()
						   .withIndexName("EMROPERATOR-index")
						//.withIndexName("CUSTOMER-index")
						   .withConsistentRead(false)
			               .withKeyConditionExpression("EMROPERATOR = :v1 ")
						   //.withKeyConditionExpression("CUSTOMER = :v1 ")
						   //.withKeyConditionExpression("FACILITY = :v4")
			               .withFilterExpression("LASTUPDATEDPATIENT < :v2 and FACILITYSTATUS = :v3 and FACILITY = :v4 ") //and FACILITY = :v4,NOT CUSTOMER IN(:v4,:v5,:v6),NOT CUSTOMER IN(:v4, :v5, :v6, :v7, :v8 ,:v9),CUSTOMER = :v4
			               .withExpressionAttributeValues(attributeValues);
		           
		           
		        List<EMROperatorInfo> emrOperatorList =  dynamoDBMapper.query(EMROperatorInfo.class, queryExpression);
		          
		        return emrOperatorList;
		           
			} catch (AmazonServiceException ase) {
				throw new RuntimeException("Internal Server Error");
			} catch (AmazonClientException ace){
				throw new RuntimeException("Internal Server Error");
			} catch (Exception e){
				throw new RuntimeException(e.getMessage());
			} finally {
				amazonDynamoDBClient = null;
				awsCredentials = null;
			}
			
		}

	
public String updateEmrInfo(EMROperatorInfo emrIn){
	try {
		awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
		amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
		
		DynamoDBMapper dynamoDBMapper =  DynamoDBUtil.getDynamoDBMapper(amazonDynamoDBClient);
		dynamoDBMapper.save(emrIn);
		
		
		
	} catch (Exception e){
		throw new RuntimeException(e.getMessage());
	} finally {
		amazonDynamoDBClient = null;
		awsCredentials = null;
	}
	return "updated successfully";
}

/*public String saveImageUrl()
{
	awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
	amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
	
	DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(amazonDynamoDBClient);

	S3LINK s3link= dynamoDBMapper.createS3Link(US_EAST_1, nrpatientimages, key);
}*/
public EMROperatorInfo getEMRInfo(String facility1,String emroperator1){
	try {
		
		awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
		amazonDynamoDBClient = DynamoDBUtil.getAmazonDynamoDBClient(awsCredentials);
		
		DynamoDBMapper dynamoDBMapper = new DynamoDBMapper(amazonDynamoDBClient);
	
		Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
		attributeValues.put(":v1", new AttributeValue().withS(facility1));
		attributeValues.put(":v2", new AttributeValue().withS(emroperator1));
		
		
		DynamoDBQueryExpression<EMROperatorInfo> queryExpression = new DynamoDBQueryExpression<EMROperatorInfo>()
	               .withConsistentRead(false)
	               .withKeyConditionExpression("FACILITY = :v1 and EMROPERATOR  = :v2")
	               .withExpressionAttributeValues(attributeValues);
           
           
        List<EMROperatorInfo> patientList =  dynamoDBMapper.query(EMROperatorInfo.class, queryExpression);
          
        if(patientList.size()>0) {
      	  return patientList.get(0);
        }else {
      	  return null;
        }
        
           
	} catch (AmazonServiceException ase) {
		throw new RuntimeException("Internal Server Error");
	} catch (AmazonClientException ace){
		throw new RuntimeException("Internal Server Error");
	} catch (Exception e){
		throw new RuntimeException(e.getMessage());
	} finally {
		amazonDynamoDBClient = null;
		awsCredentials = null;
	}
}



}
