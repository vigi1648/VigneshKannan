package com.nik;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.google.gson.Gson;
@WebServlet("/CountryServlet")
public class CountryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CountryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("niiiii");
		/*String pattern=request.getParameter("pattern").toUpperCase();
		pattern="in".toUpperCase();*/
		List<Country> countriesList = new ArrayList<Country>();
		try {
			Configuration  cfg=new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf=cfg.buildSessionFactory();
			Session s1=sf.openSession();
			//SQLQuery query=s1.createSQLQuery("select * from country where  upper(name) like '%"+pattern+"%'");
			SQLQuery query=s1.createSQLQuery("select * from country");

			query.addEntity(Country.class);
			countriesList=query.list();
			System.out.println(countriesList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		/*Country c1=new Country();
		c1.setId(1);
		c1.setName("india");
		countriesList.add(c1);
		Country c2=new Country();
		c2.setId(2);
		c2.setName("nepal");
		countriesList.add(c2);
		System.out.println("nikkkk");*/

		String json = new Gson().toJson(countriesList);
		response.setContentType("application/json");
		response.getWriter().write(json);
	}

}
