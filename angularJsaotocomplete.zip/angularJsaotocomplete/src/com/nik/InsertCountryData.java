package com.nik;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertCountryData {
	public static void main(String[] a) throws Exception {
		Class.forName("org.h2.Driver");
		Connection conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "great123");
		Statement stmt=conn.createStatement();
		FileReader fr=new FileReader("F:\\ShoppingCart\\angularJsaotocomplete\\countries.txt");
		BufferedReader br=new BufferedReader(fr);
		String name=br.readLine();
		int i=1;
		String sql;
		while(name!=null){
			sql="insert into country values("+i+",'"+name+"')";
			stmt.executeUpdate(sql);
			name=br.readLine();
			i++;
		}
		stmt.close();
		conn.close();
		System.out.println("done");
	}
}
