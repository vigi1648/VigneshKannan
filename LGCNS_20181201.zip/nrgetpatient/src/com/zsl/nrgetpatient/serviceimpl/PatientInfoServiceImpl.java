package com.zsl.nrgetpatient.serviceimpl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.bouncycastle.crypto.CryptoException;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
import com.zsl.nrgetpatient.dao.PatientInfoDAO;
import com.zsl.nrgetpatient.daoimpl.PatientInfoDAOImpl;
import com.zsl.nrgetpatient.dto.PatientInfo;
import com.zsl.nrgetpatient.dto.PatientsInfo;
import com.zsl.nrgetpatient.service.PatientInfoService;
import com.zsl.nrgetpatient.util.BouncyCastleEngine;
import com.zsl.nrgetpatient.util.CommonUtil;

public class PatientInfoServiceImpl implements PatientInfoService{

	public PatientsInfo getPatients(Map<String, String> patientInfo) throws IOException,UnsupportedEncodingException,CryptoException{
		/*Map<String, PatientsInfo> patientMap = null;
		patientMap = new HashMap<String, PatientsInfo>();*/
		
		try{
		PatientInfoDAO patientInfoDAO = new PatientInfoDAOImpl();
	    List<PatientInfo> patientlist = null;
		//Map<String, PatientInfo> patientInfo = null;
		//patientInfo = new HashMap<String, PatientInfo>();
		String sendingApplication = patientInfo.get("sendingApplication");
		String sendingFacility = patientInfo.get("sendingFacility");
		//String data=null;
		//String dataKey=null;
		 patientlist = patientInfoDAO.getPatients(sendingApplication, sendingFacility);
		PatientsInfo patientsInfo = new PatientsInfo();
		//PatientInfo patient=new PatientInfo();
		patientsInfo.setLASTKEY(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
		patientsInfo.setPATIENTLIST(patientlist);
		/*	dataKey = CommonUtil.getInstance().getDataKey();
		patientInfo.setPatientId(data.getPatientId());// != null && !data.getPatientId().trim().isEmpty() ? BouncyCastleEngine.AESEncryption(data.getPatientId(), dataKey) : null);
		if(data.getDob() != null)
		{
		String dob = data.getDob().replaceAll("[^0-9\\+]", "");
		patientInfo.setDob(dob != null && !dob.trim().isEmpty() ? BouncyCastleEngine.AESEncryption(dob, dataKey) : null);
		}*/
		return patientsInfo;
		}catch(Exception e){
			throw new RuntimeException(e.getMessage(), e);
		}
		
		
}
}