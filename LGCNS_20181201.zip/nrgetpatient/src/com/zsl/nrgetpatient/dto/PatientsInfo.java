package com.zsl.nrgetpatient.dto;

import java.util.List;

public class PatientsInfo{

	public String LASTKEY;
	public List<PatientInfo> PATIENTLIST;
	
	public String getLASTKEY() {
		return LASTKEY;
	}
	public void setLASTKEY(String lASTKEY) {
		this.LASTKEY = lASTKEY;
	}
	public List<PatientInfo> getPATIENTLIST() {
		return PATIENTLIST;
	}
	public void setPATIENTLIST(List<PatientInfo> patientList) {
		this.PATIENTLIST = patientList;
	}
	
	
	
}
