package com.zsl.nrgetpatient.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import org.bouncycastle.crypto.CryptoException;

import com.zsl.nrgetpatient.dto.PatientInfo;
import com.zsl.nrgetpatient.dto.PatientsInfo;

public interface PatientInfoService {

	public PatientsInfo getPatients(Map<String, String> patientInfo)throws IOException,UnsupportedEncodingException, CryptoException;

	//public PatientsInfo getPatients(String sendingApplication, String sendingFacility);

	//public Object getPatients(Map<String, String> patientInfo);
	
	//public PatientsInfo getPatients(String sendingApplication,String sendingFacility);
	
}
